const fs=require('fs'),assert=require('assert'),{Engine}=require('../src/core.js'),data=JSON.parse(fs.readFileSync(__dirname+'/../data/game-data.json'));
const engine=()=>new Engine(data,{enemyAI:false,random:()=>.5});
function checkpoints(e){for(const ev of e.drain())if(ev.type==='autosave'){const c=engine();c.restore(ev.snapshot||e.snapshot());}}
function settle(e){let n=10000;while(n--){if(e.mode==='dialog'){e.tick(.01);e.dialog.revealed=999;e.dialog.hold=0;e.advance();}else if(e.sequence||e.mode==='cinematic'){e.tick(.1)}else{e.tick(0);if(!e.sequence&&['explore','question'].includes(e.mode)){checkpoints(e);return}}if(e.sequence)checkpoints(e);}throw Error('進行停止 '+e.map.id)}
function walk(e,x,y){settle(e);const m=e.map,q=[[e.state.x,e.state.y]],seen=new Set([q[0].join(',')]),prev={};let end;
 for(let i=0;i<q.length;i++){const [a,b]=q[i];if(a===x&&b===y){end=a+','+b;break}for(const [dir,dx,dy]of [['up',0,-1],['down',0,1],['left',-1,0],['right',1,0]]){const nx=a+dx,ny=b+dy,k=nx+','+ny;if(seen.has(k)||!e.canStand(m.id,nx,ny)||m.portals.some(p=>p.x===nx&&p.y===ny&&!(nx===x&&ny===y))||m.enemies.some(p=>e.visible(p)&&!e.state.defeated[p.id]&&p.x===nx&&p.y===ny&&!(nx===x&&ny===y)))continue;seen.add(k);prev[k]=[a,b,dir];q.push([nx,ny])}}
 assert(end,'経路なし '+m.id+':'+x+','+y);const dirs=[];for(let k=end;k!==q[0].join(',');){const p=prev[k];dirs.push(p[2]);k=p[0]+','+p[1]}for(const dir of dirs.reverse()){assert(e.move(dir));e.tick(.14)}if(e.mode!=='question')settle(e);
}
function win(e){assert.equal(e.mode,'question');let n=50;while(e.battle.hp>0&&n--){if(e.needsVow)e.chooseVow('noPotion');e.completeAnswer(true);e.nextQuestion()}assert(n>0);assert.equal(e.mode,'reward');e.finishBattle();settle(e);}
function talk(e,id){assert(e.runEvent(id));settle(e);}

module.exports={data,engine,settle,walk,win};
