"""Stage 9: canonical SCENE80–82, reunion and containment battle."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/'data'/n).read_text())
def write(n,v):(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
d=read('game-data.json');m=read('maps.json');canon=read('part2-canonical-scenes.json');seq=d['sequences'];ev={}
def flags(**v):return dict(type='flags',values=v)
def text(*p):return dict(type='dialogue',pages=list(p))
def speech(n,lo=0,hi=9999):return dict(type='dialogue',pages=[dict(speaker=p['speaker'],text=p['text'],sourceScene=n,sourceLine=p['sourceLine'],sourceDocument='part2')for p in canon['scenes'][str(n)]['entries']if p['speaker'] and lo<=p['sourceLine']<=hi])
def event(id,steps,when=None):
 seq[id]=steps+[dict(type='finish')];ev[id]=dict(pages=[],when=when or {},effects=[dict(type='sequence',id=id)])
def portal(id,x,y,target,sx,sy,label,requires=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='up'),kind='door',asset='gate_door',width=32,height=32,label=label,interactionLabel=label+'へ移動')
 if requires:p['requires']=requires
 return p
# Preserve old chapter-12 boundary sequence length, including saves mid-sequence.
for p in seq['p2_deep_complete']:
 if p['type']=='dialogue':p['pages']=['管理領域の扉に着いた。レンがいる場所は、この先だ。','四つの区画を抜けた。ここで保存でき、町へ戻って準備もできる。北の扉か「第13章へ進む」でレンに会いに行こう。']
s=m['p2_deep_silent'];door=next(o for o in s['objects']if o['id']=='p2-deep-management-door');door['events']=['p2_deep_complete','chapter13_departure'];door['interactionLabel']='管理領域へ進む'
event('chapter13_departure',[flags(chapter13Started=True),dict(type='chapter',value=13),dict(type='map',map='p2_management_approach',spawn=dict(x=12,y=17,dir='up')),text('管理領域の前室。奥にレンがいる。ここで準備を整えよう。')],{'chapter12Complete':True,'chapter13Started':False});ev['chapter13_departure']['requiresCores']=['name','promise','memory','tomorrow']
# Once chapter 13 has started, an object event re-enters without replaying the reunion.
ev['p2_management_return']=dict(pages=[],once=False,when={'chapter13Started':True},effects=[dict(type='travel',map='p2_management_approach',spawn=dict(x=12,y=17,dir='up'))]);door['events'].append('p2_management_return')
e12=read('chapter12-events.json');e12.pop('p2_deep_management_wait',None);write('chapter12-events.json',e12);d['events'].pop('p2_deep_management_wait',None)
for id,name in [('p2_management_approach','第13章・管理領域の前室'),('p2_management','第13章・管理領域中央')]:
 a=copy.deepcopy(m['ch8_final']);a.update(id=id,name=name,chapter=13,part2=True,stage9=True,objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=12,y=17,dir='up'),renArea=True)
 # A broad readable chamber; use the existing tiles and border walls, no hidden barriers.
 a['collision']=[int(x==0 or y==0 or x==a['width']-1 or y==a['height']-1)for y in range(a['height'])for x in range(a['width'])];m[id]=a
p=m['p2_management_approach'];p['portals']=[portal('p2-management-back',12,19,'p2_deep_silent',30,5,'深層4へ戻る'),portal('p2-management-central',12,3,'p2_management',12,17,'レンのいる中央へ')]
p['objects']=[dict(id='p2-management-cache',kind='chest',x=19,y=15,asset='chest',width=32,height=32,anchorX=16,anchorY=32,footprint=[dict(x=0,y=0,w=32,h=32)],loot=dict(gear=['W034'],items={'I001':4}),interactionLabel='準備の宝箱')]
for i,(x,y)in enumerate([(4,5),(8,7),(18,6),(21,9),(4,13),(8,15),(18,12),(22,16)]):p['enemies'].append(dict(id='p2-management-fragment-'+str(i),enemy='P2_REN_FRAGMENT',x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.65,chaseRadius=2,leash=3)))
a=m['p2_management'];a['portals']=[portal('p2-management-exit',12,19,'p2_management_approach',12,4,'前室へ戻る')];a['npcs']=[dict(id='ren',name='レン',asset='ren_pipoya_student',x=12,y=8,dir='down',footprint=[],pages=['……。'],events=['p2_ren_battle_start','p2_ren_wait']),dict(id='aoi',name='アオイ',asset='aoi_pipoya_student',x=11,y=13,dir='up',footprint=[],pages=['一人にしない。'])];a['entryEvents']=['p2_ren_reunion'];a['enemies']=[dict(id='p2-ren-runaway',enemy='P2_REN_RUNAWAY',x=12,y=9,when={'p2RenConfessed':True,'p2RenCalmed':False},introEvent='p2_ren_battle_start',afterEvent='p2_ren_release',respawn=False)]
event('p2_ren_reunion',[dict(type='actors',values={'hero':dict(x=12,y=14,dir='up'),'ren':dict(x=12,y=8,dir='down'),'aoi':dict(x=11,y=13,dir='up')}),dict(type='move',actor='hero',to=[12,11]),speech(80,0,318),dict(type='visual',kind='ren-cracks',duration=1.6),speech(80,320),flags(p2RenReunited=True),speech(81,0,353),dict(type='face',actor='ren',dir='down'),speech(81,355),dict(type='visual',kind='ren-cracks',duration=2),flags(p2RenConfessed=True),text('レンの中の吸収量を減らそう。中央へ近づくか、レンに話しかけると戦闘になる。四つの核はまだ使わない。')],{'p2RenReunited':False,'chapter13Started':True})
event('p2_ren_battle_start',[speech(82,0,366),flags(p2RenBattleReady=True)],{'p2RenConfessed':True,'p2RenCalmed':False});ev['p2_ren_battle_start']['once']=False
# Start through a sequence end, so autosaves stay in exploration before battle.
ev['p2_ren_battle_trigger']=dict(pages=[],once=False,when={'p2RenBattleReady':True,'p2RenCalmed':False},effects=[dict(type='flags',values={'p2RenBattleReady':False}),dict(type='battle',encounter='p2-ren-runaway')]);a['entryEvents'].append('p2_ren_battle_trigger')
event('p2_ren_release',[flags(p2RenCalmed=True),dict(type='visual',kind='ren-release',duration=2.4),speech(82,368),flags(chapter13Complete=True),text('レンは小さく笑った。ここで冒険の記録を保存できます。')],{'p2RenCalmed':False})
ev['p2_ren_wait']=dict(pages=['レンは静かに息を整えている。ここで記録を保存できる。'],when={'chapter13Complete':True},once=False,effects=[])
d['enemies']['P2_REN_FRAGMENT']=dict(id='P2_REN_FRAGMENT',name='抱え込まれた言葉の断片',asset='archive_wisp',fusionAssets=['archive_wisp','hound','bat'],hp=1650,attack=269,defense=172,guard=172,attackSeconds=22,gold=1250,exp=219,family='spirit',element='physical',questionCategories=d['enemies']['P2_DEEP_GUARD']['questionCategories'])
d['enemies']['P2_REN_RUNAWAY']=dict(id='P2_REN_RUNAWAY',name='レン・暴走体',asset='ren_pipoya_student',hp=6800,attack=284,defense=184,guard=184,attackSeconds=24,gold=3500,exp=1600,mechanic='ren-shadows',shadowAssets=['bat','hound','archive_wisp','archive_guardian'],shadowThresholds=[.75,.5,.25,0],family='guard',element='physical',questionCategories=d['enemies']['P2_DEEP_GUARD']['questionCategories'])
plan=read('part2-equipment-plan.json')
for t in plan['tiers']:
 if t['chapter']==13:
  t.update(implemented=True,effectImplemented=True,placement='p2-management-cache',note='Existing master equipment; correct answer damage bonus active.')
  d['equipment'][t['id']].update(attack=t['attack'],defense=t['defense'],HP=t['HP'],requiredLevel=t['requiredLevel'],effects={'correctDamage':.08},**{'攻撃':t['attack'],'防御':t['defense'],'買値':t['price']})
plan['activation']='Stage 9 equipment active through chapter 13; chapter 14 reserved.'
d['objectives']=[o for o in d['objectives']if not o.get('stage9')]
d['objectives'][:0]=[dict(stage9=True,part2=True,when=w,text=t)for w,t in [({'chapter13Complete':True},'レンの暴走を止めた。レンは小さく笑った。ここで記録を保存できる。'),({'p2RenConfessed':True,'chapter13Complete':False},'レンの暴走を止めよう。HPを減らすと抱えた旧敵の影が分離する。四つの核はまだ使わない。'),({'chapter13Started':True,'p2RenConfessed':False},'前室で準備を整え、北の扉から管理領域中央へ。レンに会おう。')]]
for o in d['objectives']:
 if o.get('stage8') and o['when'].get('chapter12Complete'):o['text']='管理領域の扉に到達。北の扉か「第13章へ進む」からレンに会おう。町へ戻って準備もできる。'
for c in d['chapters']:
 if c['id']==13:c.update(implemented=True,entry=dict(map='p2_management_approach',spawn=dict(x=12,y=17,dir='up')))
cont=read('continuation.json');cont.update(version='0.19.0',implementedScenes=list(range(65,83)));cont['chapters'][4].update(implemented=True,note='SCENE80–82; 8 optional fragments and 1 containment boss; no forced level correction.')
canon['activation']='SCENE61–82 implemented; SCENE83–92 reserved.'
for n,v in [('game-data.json',d),('maps.json',m),('chapter13-events.json',ev),('continuation.json',cont),('part2-equipment-plan.json',plan),('part2-canonical-scenes.json',canon)]:write(n,v)
print('Stage 9: SCENE80–82 and management area.')
