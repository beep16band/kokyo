"""Stage 6: SCENE71–72, additive maps and save-compatible four cores."""
from pathlib import Path
import copy,json
R=Path(__file__).resolve().parents[1]
def read(n): return json.loads((R/'data'/n).read_text())
def write(n,v): (R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
d=read('game-data.json'); m=read('maps.json'); ev=read('chapter10-events.json'); canon=read('part2-canonical-scenes.json'); seq=d['sequences']
def pages(s,lo=0,hi=999):
 return [dict(speaker=p['speaker'],text=p['text'],sourceScene=s,sourceLine=p['sourceLine'],sourceDocument='part2') for p in canon['scenes'][str(s)]['entries'] if p['speaker'] and lo<=p['sourceLine']<=hi]
def dialogue(s,lo=0,hi=999): return dict(type='dialogue',pages=pages(s,lo,hi))
def flags(**v): return dict(type='flags',values=v)
def event(id,steps,when=None,at=None):
 seq[id]=steps+[dict(type='finish')]; ev[id]=dict(pages=[],when=when or {},effects=[dict(type='sequence',id=id)])
 if at: ev[id]['at']=at
def clone(old,new,name,area=None):
 x=copy.deepcopy(m[old]); x.update(id=new,name=name,part2=True,chapter=10,stage6=True,npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[])
 for k in ['afterStory','epilogue','memory','school','night']: x.pop(k,None)
 x['objects']=[o for o in x['objects'] if o['kind'] not in ['chest','sign','vista']]
 for o in x['objects']:
  o['id']=new+':'+o['id']; o.pop('events',None); o.pop('when',None)
 if area: x['coreArea']=area
 m[new]=x; return x
def portal(id,x,y,target,sx,sy,label,requires=None,kind='path',asset='stone_arch'):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='up'),kind=kind,asset=asset,label=label,interactionLabel=label+'へ移動')
 if requires: p.update(requires=requires,lockedPages=['まだ進めない。現在の「目的」を確認しよう。'])
 return p
def mark(id,x,y,event,label,asset='old_book'):
 return dict(id=id,kind='sign',x=x,y=y,asset=asset,width=32,height=32,anchorX=16,anchorY=32,events=[event],interactionLabel=label)
def npc(id,name,x,y,asset='villager',**extra):
 return dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),events=[],pages=[],**extra)
def roam(x,prefix,count=8):
 positions=[(7,8),(11,8),(15,8),(19,8),(23,8),(9,10),(13,10),(17,10),(21,10),(7,12)]
 ids=['P2_RECORDBEAST','P2_LASTGUARD','P2_FUTUREWING','P2_GOLDMEMORY']
 x['enemies']=[dict(id=prefix+str(i),enemy=ids[i%4],x=a,y=b,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.55,chaseRadius=2,leash=3)) for i,(a,b) in enumerate(positions[:count])]
# Replace the old boundary with a real gate, preserving old event ids and flags.
c=m['p2_promise_court'];c['objects']=[o for o in c['objects'] if o['id']!='p2-memory-door'];c['portals'].append(portal('p2-memory-gate',22,4,'p2_memory_road',4,14,'記憶の書庫への街道',{'p2PromiseCore':True}))
ev['p2_memory_boundary']=dict(pages=['中庭の右上の石門から、記憶の書庫へ進もう。'],once=False,effects=[])
seq['p2_promise_release'][-2]['pages']=['「約束の核」を手に入れた。取り戻した核は、名前と約束の二つ。','次の目的：中庭の右上の石門から記憶の書庫へ。']
ev['chapter10_back_departure']=dict(pages=[],once=False,when={'chapter10HalfComplete':True,'p2MemoryHeard':False},effects=[flags(chapter10BackStarted=True),dict(type='travel',map='p2_memory_road',spawn=dict(x=4,y=14,dir='right'))])
event('p2_memory_arrival',[dialogue(71,191,192),dict(type='dialogue',pages=['書庫の右下にある国語ノートを調べよう。記録に残った言葉を、アオイと確かめる。']),flags(p2MemoryHeard=True,chapter10BackStarted=True)],{'p2MemoryHeard':False})
event('p2_memory_notebook',[dialogue(71,194,201),flags(p2MemoryNotebook=True),dict(type='dialogue',pages=['書庫の右上の階段が開いた。奥の広間へ進もう。'])],{'p2MemoryHeard':True,'p2MemoryNotebook':False})
event('p2_memoria_intro',[dict(type='dialogue',pages=['古い声が聞こえる。「そのノート、返さなくていい。」','アオイの言葉に似ている。でも、そんなことは言っていない。思い出を歪める偽物だ。']),dialogue(71,203,205),flags(p2MemoriaIntro=True)],{'p2MemoryNotebook':True,'p2MemoryCore':False},dict(map='p2_memory_hall',x=12,y=10))
ev['p2_memoria_battle']=dict(pages=[],once=False,at=dict(map='p2_memory_hall',x=12,y=10),when={'p2MemoriaIntro':True,'p2MemoryCore':False},effects=[dict(type='battle',encounter='p2-memoria')])
event('p2_memory_release',[dict(type='visual',kind='word-home',duration=2.2,word='思い出'),dict(type='core',id='memory'),flags(p2MemoryCore=True),dict(type='dialogue',pages=['「思い出の核」を手に入れた。言葉を読んだときの気持ちが戻ってくる。','次の目的：広間の北の扉→街道の東の石門から忘却の街へ。'])])
event('p2_tomorrow_arrival',[dialogue(72,211,218),flags(p2TomorrowHeard=True),dict(type='dialogue',pages=['この街では、未来を表す言葉が消えている。右上の石門の先で「明日」を取り戻そう。'])],{'p2TomorrowHeard':False})
event('p2_tomorrow_intro',[dialogue(72,220,222),dict(type='dialogue',pages=['トゥモロウの攻撃は、戦闘が長引くほど速くなる。20秒ごとに加速するが、速さには限界がある。','解答・解説を読む間は加速も止まる。正解後は、残っている攻撃時間から続く。装備と回復薬を用意して挑もう。']),flags(p2TomorrowIntro=True)],{'p2TomorrowHeard':True,'p2TomorrowCore':False},dict(map='p2_tomorrow_hall',x=12,y=10))
ev['p2_tomorrow_battle']=dict(pages=[],once=False,at=dict(map='p2_tomorrow_hall',x=12,y=10),when={'p2TomorrowIntro':True,'p2TomorrowCore':False},effects=[dict(type='battle',encounter='p2-tomorrow')])
event('p2_tomorrow_release',[dict(type='visual',kind='word-home',duration=2.2,word='明日'),dict(type='core',id='tomorrow'),flags(p2TomorrowCore=True,chapter10Complete=True),dialogue(72,224,228),dict(type='dialogue',pages=['名前・約束・思い出・明日。四つの核がそろった。','次の目的：最初の町へ戻ろう。広間の北の扉から帰還の道を使える。'])])
event('p2_core_return',[dict(type='dialogue',pages=['四つの核を持って、最初の町へ戻ってきた。レンを救うための準備をしよう。','ここで冒険の記録を保存できます。アオイのサポートと鍛冶屋の倉庫は、次の工程で使えるようになります。']),flags(p2CoresReturned=True)],{'chapter10Complete':True,'p2CoresReturned':False})
for key,word in [('memory','思い出'),('tomorrow','明日')]:
 d['cores'][key]=dict(name=word+'の核',itemId='CORE_'+key.upper());d['items']['CORE_'+key.upper()]=dict(id='CORE_'+key.upper(),name=word+'の核',type='key',icon='scroll',requiredLevel=1)
r=clone('p2_letter_road','p2_memory_road','第10章・思い出へ続く街道','memory');r['safeSpawn']=dict(x=4,y=14,dir='right');r['portals']=[portal('p2-memory-road-back',3,14,'p2_promise_court',22,5,'手紙の町の中庭'),portal('p2-memory-road-archive',26,14,'p2_memory_archive',14,19,'記憶の書庫')];roam(r,'p2-memory-roaming-',10)
a=clone('ch3_archive','p2_memory_archive','第10章・記憶の書庫','memory');a.update(safeSpawn=dict(x=14,y=19,dir='up'),entryEvents=['p2_memory_arrival']);a['portals']=[portal('p2-archive-back',14,20,'p2_memory_road',25,14,'街道へ戻る',kind='door',asset='gate_door'),portal('p2-archive-hall',27,5,'p2_memory_hall',12,15,'追憶の広間',{'p2MemoryNotebook':True},kind='stairs',asset='stairs_down')]
# Keep the original notebook/table footprint; attach interaction to its original usable rect.
for o in a['objects']:
 if o['id'].endswith('aoi_notebook_table'):o['events']=['p2_memory_notebook']
h=clone('ch6_king','p2_memory_hall','第10章・追憶の広間','memory');h.update(safeSpawn=dict(x=12,y=15,dir='up'),entryEvents=['p2_memoria_battle']);h['triggers']=[dict(x=12,y=10,event='p2_memoria_intro')];h['portals']=[portal('p2-memory-hall-back',12,17,'p2_memory_archive',27,6,'書庫へ戻る',kind='stairs',asset='stairs_up'),portal('p2-memory-hall-east',12,3,'p2_tomorrow_road',4,14,'忘却の街への街道',{'p2MemoryCore':True},kind='door',asset='gate_door')];h['enemies']=[dict(id='p2-memoria',enemy='P2_MEMORIA',x=12,y=8,respawn=False,when={'p2MemoryCore':False,'p2MemoriaIntro':True},afterEvent='p2_memory_release')]
r=clone('p2_letter_road','p2_tomorrow_road','第10章・明日へ続く街道','tomorrow');r['safeSpawn']=dict(x=4,y=14,dir='right');r['portals']=[portal('p2-tomorrow-road-back',3,14,'p2_memory_hall',12,4,'追憶の広間へ戻る'),portal('p2-tomorrow-road-town',26,14,'p2_future_town',3,22,'忘却の街')];roam(r,'p2-tomorrow-roaming-',10)
t=clone('ch6_town','p2_future_town','第10章・忘却の街','tomorrow');t.update(safeSpawn=dict(x=3,y=22,dir='up'),entryEvents=['p2_tomorrow_arrival']);t['portals']=[portal('p2-future-town-back',2,22,'p2_tomorrow_road',25,14,'街道へ戻る'),portal('p2-future-town-inn',25,8,'p2_future_inn',7,11,'宿屋',kind='door',asset='gate_door'),portal('p2-future-town-hall',32,4,'p2_tomorrow_hall',12,15,'明日を奪った獣')]
t['npcs']=[npc('future-resident','住民',16,17),npc('future-merchant','道具屋',16,10,asset='merchant',service='shop',serviceId='p2-future-shop')]
for n in t['npcs']:n['pages']=[dict(text='今日が終わったら……その先？　先のことは考えられない。',when={'p2TomorrowCore':False}),dict(text='明日はあの人に会いに行こう。明日のために、今日は準備をする。',when={'p2TomorrowCore':True})]
i=clone('p2_letter_inn','p2_future_inn','忘却の街の宿屋','tomorrow');i['safeSpawn']=dict(x=7,y=11,dir='up');i['portals']=[portal('p2-future-inn-back',7,12,'p2_future_town',25,9,'宿屋の外',kind='door',asset='gate_door')];i['npcs']=[npc('innkeeper','宿の主人',7,6,asset='merchant',service='inn',serviceId='p2-future-inn')];d['inns']['p2-future-inn']=dict(name='忘却の街の宿屋',price=130)
h=clone('ch6_king','p2_tomorrow_hall','第10章・明日を閉ざす広間','tomorrow');h.update(safeSpawn=dict(x=12,y=15,dir='up'),entryEvents=['p2_tomorrow_battle']);h['triggers']=[dict(x=12,y=10,event='p2_tomorrow_intro')];h['portals']=[portal('p2-tomorrow-hall-back',12,17,'p2_future_town',31,4,'忘却の街へ戻る',kind='door',asset='gate_door'),portal('p2-tomorrow-return',12,3,'p2_return_road',4,14,'最初の町への帰還路',{'chapter10Complete':True},kind='door',asset='gate_door')];h['enemies']=[dict(id='p2-tomorrow',enemy='P2_TOMORROW',x=12,y=8,respawn=False,when={'p2TomorrowCore':False,'p2TomorrowIntro':True},afterEvent='p2_tomorrow_release')]
r=clone('p2_letter_road','p2_return_road','第10章・四つの核の帰還路');r['safeSpawn']=dict(x=4,y=14,dir='right');r['portals']=[portal('p2-return-back',3,14,'p2_tomorrow_hall',12,4,'忘却の街へ戻る'),portal('p2-return-town',26,14,'p2_village',15,15,'最初の町')]
m['p2_village']['entryEvents'].append('p2_core_return')
# Stable map-side return path opens only after chapter completion; no one-way trap.
m['p2_village']['portals'].append(portal('p2-town-four-cores',24,9,'p2_return_road',25,14,'忘却の街への帰還路',{'chapter10Complete':True}))
cats=d['enemies']['P2_NOMEN']['questionCategories']
for id,name,asset,hp,atk,de,sec,gold,exp in [('P2_RECORDBEAST','記録だけの文字獣','context_beast',810,168,91,20,650,330),('P2_LASTGUARD','今日に縛られた守り手','archive_guardian',920,159,118,22,700,330),('P2_FUTUREWING','明日を隠す文字翼','bat',730,153,82,15,600,330),('P2_GOLDMEMORY','忘れられた金字','archive_wisp',940,159,93,22,880,330),('P2_MEMORIA','追憶喰らいメモリア','archive_wisp',3400,178,99,21,1850,1100),('P2_TOMORROW','明日喰らいトゥモロウ','archive_guardian',3900,195,118,24,2200,1100)]:
 d['enemies'][id]=dict(id=id,name=name,asset=asset,hp=hp,attack=atk,defense=de,guard=de,attackSeconds=sec,exp=exp,gold=gold,questionCategories=cats,role='章中ボス' if id in ['P2_MEMORIA','P2_TOMORROW'] else '通常敵')
d['enemies']['P2_MEMORIA'].update(mechanic='memoryEcho',echoes=['偽の再生「ノートは返さなくていい」──本当は、返す約束だった。','偽の再生「忘れたら、もう話さない」──主人公は、もう一回全部話すと約束した。','偽の再生「誰が言っても同じ」──アオイは、誰が言ったかで違うと言った。'])
d['enemies']['P2_TOMORROW'].update(mechanic='timeAcceleration',accelerationEvery=20,accelerationStep=.15,accelerationMax=1.6)
plan=read('part2-equipment-plan.json')
for g in plan['tiers']:
 if g['id'] in ['W030','A018']:
  g.update(implemented=True,placement='p2-future-shop',note='Base attack/defense/fixed HP only; special effects reserved for Stage 7.')
  d['equipment'][g['id']].update(attack=g['attack'],defense=g['defense'],HP=g['HP'],requiredLevel=g['requiredLevel'],**{'攻撃':g['attack'],'防御':g['defense'],'買値':g['price'],'特殊効果':'追加効果なし（能力値に反映）'})
plan['activation']='First six tiers active through Stage 6; later tiers and special effects reserved.'
d['shops']['p2-future-shop']=dict(name='明日への道具屋',products=[dict(id='I001',type='item',price=55)]+[dict(id=g['id'],type='gear',price=g['price'])for g in plan['tiers'] if g['implemented']])
# Recovery preparation before Memoria also offers the prior tier and herbs.
a['npcs']=[npc('archive-merchant','書庫の管理人',23,18,asset='merchant',service='shop',serviceId='p2-memory-shop')]
d['shops']['p2-memory-shop']=copy.deepcopy(d['shops']['p2-promise-shop'])
ev['p2_archive_rest']=dict(pages=['入口に置かれた寝具で休めます。宿代130GでHPを回復します。'],once=False,effects=[])
# Use a real inn service in the safe archive entrance for retreat and healing.
a['npcs'].append(npc('archive-inn','休憩所の係',18,18,asset='merchant',service='inn',serviceId='p2-future-inn'))
d['objectives']=[o for o in d['objectives'] if not o.get('stage6')]
for o in d['objectives']:
 if o.get('stage5') and o['when'].get('chapter10HalfComplete'):
  o['when']['p2MemoryHeard']=False;o['text']='中庭の右上の石門から、記憶の書庫へ進もう。'
d['objectives'][:0]=[dict(part2=True,stage6=True,when=w,text=t)for w,t in [({'p2CoresReturned':True},'四つの核を持って最初の町へ帰還。準備・保存ができる。レン救出の準備は次の工程。'),({'chapter10Complete':True},'四つの核がそろった。広間の北の扉→帰還路の東の石門から、最初の町へ戻ろう。'),({'p2TomorrowHeard':True,'p2TomorrowCore':False},'忘却の街の右上の石門へ。広間中央で、明日を奪った獣を止めよう。'),({'p2MemoryCore':True,'p2TomorrowHeard':False},'追憶の広間の北の扉→街道の東の石門から忘却の街へ。'),({'p2MemoryNotebook':True,'p2MemoryCore':False},'書庫の右上の階段→広間の中央へ。追憶喰らいメモリアを止めよう。'),({'p2MemoryHeard':True,'p2MemoryNotebook':False},'書庫の右下の机にある国語ノートを、下から調べよう。')]]
for ch in d['chapters']:
 if ch['id']==10:ch.update(partial=False,implementedScenes=[69,70,71,72])
cont=read('continuation.json');cont.update(version='0.16.0',implementedScenes=list(range(65,73)));cont['chapters'][1].update(partial=False,implementedScenes=[69,70,71,72],note='All four cores; return to first town. No forced level correction.',back=dict(startLevel=24,endLevel=28,normalBattles=20,majorBattles=2,normalExp=330,majorExp=1100))
canon['activation']='SCENE61–72 implemented; SCENE73–92 reserved for later stages'
for name,value in [('game-data.json',d),('maps.json',m),('chapter10-events.json',ev),('continuation.json',cont),('part2-equipment-plan.json',plan),('part2-canonical-scenes.json',canon)]:write(name,value)
print('Stage 6: memory and tomorrow, eight maps, return loop.')
