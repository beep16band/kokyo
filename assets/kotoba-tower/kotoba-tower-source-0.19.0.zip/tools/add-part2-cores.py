"""Stage 5: isolated SCENE69/70 maps; existing worlds remain intact."""
from pathlib import Path
import copy,json,shutil
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/'data'/n).read_text())
def write(n,v):(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
b=R/'reference/before_part2_cores'
if not b.exists():
 b.mkdir(parents=True)
 for name in ['data','src','index.html','build.py','package.json']:
  p=R/name
  if p.is_dir():shutil.copytree(p,b/name)
  else:shutil.copy2(p,b/name)
d=read('game-data.json');maps=read('maps.json');canon=read('part2-canonical-scenes.json');events={}
def pages(s,lo=0,hi=999):return [dict(speaker=p['speaker'],text=p['text'],sourceScene=s,sourceLine=p['sourceLine'],sourceDocument='part2') for p in canon['scenes'][str(s)]['entries'] if p['speaker'] and lo<=p['sourceLine']<=hi]
def dialogue(s,lo=0,hi=999):return dict(type='dialogue',pages=pages(s,lo,hi))
def flags(**v):return dict(type='flags',values=v)
def event(id,seq,when=None,at=None):
 events[id]=dict(pages=[],when=when or {},effects=[dict(type='sequence',id=seq)])
 if at:events[id]['at']=at
 return events[id]
def clone(old,new,name):
 m=copy.deepcopy(maps[old]);m.update(id=new,name=name,part2=True,chapter=10,npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[])
 for k in ['afterStory','epilogue','night']:m.pop(k,None)
 m['objects']=[o for o in m['objects'] if o['kind'] not in ['chest','sign','vista']]
 for o in m['objects']:o.pop('events',None);o.pop('when',None)
 maps[new]=m;return m
def portal(id,x,y,target,sx,sy,label,requires=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='down'),kind='path',asset='stone_arch',label=label,interactionLabel=label+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['まず、この土地の異変を解き、核を取り戻そう。「目的」で確認できます。'])
 return p
def npc(id,name,x,y,asset,ev=None,**extra):return dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),pages=['名前と約束を取り戻してくれて、ありがとう。'],events=ev or [],**extra)
def sign(id,x,y,ev,label,asset='scroll'):return dict(id=id,kind='sign',x=x,y=y,asset=asset,width=32,height=32,anchorX=16,anchorY=32,events=[ev],interactionLabel=label)
seq=d['sequences']
events['chapter10_departure']=dict(pages=['レンの足取りは、名前のない村へ続いている。まず「名前」の異変を確かめよう。'],when={'chapter9Complete':True},effects=[flags(chapter10Started=True),dict(type='travel',map='p2_name_village',spawn=dict(x=3,y=14,dir='right'))])
seq['p2_name_arrival']=[dialogue(69,165,167),flags(p2NameHeard=True),dict(type='finish')]
event('p2_name_arrival','p2_name_arrival',{'p2NameHeard':False})
seq['p2_nomen_intro']=[dialogue(69,169,173),dict(type='dialogue',pages=['盗んだ名前で姿と戦い方を変える敵だ。名前が変わってもATTACKゲージの残りは続く。']),flags(p2NomenIntro=True),dict(type='finish')]
event('p2_nomen_intro','p2_nomen_intro',{'p2NameHeard':True,'p2NameCore':False},dict(map='p2_name_hall',x=12,y=10))
events['p2_nomen_battle']=dict(pages=[],once=False,at=dict(map='p2_name_hall',x=12,y=10),when={'p2NomenIntro':True,'p2NameCore':False},effects=[dict(type='battle',encounter='p2-nomen')])
seq['p2_name_release']=[dict(type='visual',kind='word-home',duration=2.2,word='名前'),dict(type='core',id='name'),flags(p2NameCore=True),dict(type='dialogue',pages=['「名前の核」を手に入れた。村を覆う紫の霧が少し薄くなった。','次の目的：村の右上の石門から、手紙の町へ。']),dict(type='finish')]
event('p2_name_release','p2_name_release')
seq['p2_promise_arrival']=[dialogue(70,179,182),flags(p2PromiseHeard=True),dict(type='finish')]
event('p2_promise_arrival','p2_promise_arrival',{'p2PromiseHeard':False})
seq['p2_vow_intro']=[dialogue(70,184,185),dict(type='dialogue',pages=['ヴァウは、こちらが選んだ行動を「約束」にして縛る。3問ごとに約束を選ぼう。','約束を破ると次の敵攻撃が15％強くなる。回復は禁止されない。苦しいときは、約束より生き残ることを優先しよう。','約束を選んでいる間も敵の時間は進む。解答と解説を読む間だけ止まる。']),flags(p2VowIntro=True),dict(type='finish')]
event('p2_vow_intro','p2_vow_intro',{'p2PromiseHeard':True,'p2PromiseCore':False},dict(map='p2_promise_court',x=18,y=9))
events['p2_vow_battle']=dict(pages=[],once=False,at=dict(map='p2_promise_court',x=18,y=9),when={'p2VowIntro':True,'p2PromiseCore':False},effects=[dict(type='battle',encounter='p2-vow')])
seq['p2_promise_release']=[dict(type='visual',kind='word-home',duration=2.2,word='約束'),dict(type='core',id='promise'),flags(p2PromiseCore=True,chapter10HalfComplete=True),dict(type='dialogue',pages=['「約束の核」を手に入れた。取り戻した核は、名前と約束の二つ。','次の目的：記憶の書庫へ。第10章後半は次の更新で公開します。このままの記録から続けられます。']),dict(type='finish')]
event('p2_promise_release','p2_promise_release')
events['p2_memory_boundary']=dict(pages=['この道は記憶の書庫へ続いている。第10章後半は次の更新で公開します。今は探索を続けるか、冒険の記録を残そう。'],once=False,effects=[])
events['p2_name_remember']=dict(when={'p2NameCore':True},pages=['自分の名前で呼ばれる。それだけで、ここにいていいと思える。'],once=False,effects=[])
v=clone('ch1_village','p2_name_village','第10章・名前のない村');v.update(safeSpawn=dict(x=3,y=14,dir='right'),coreArea='name',entryEvents=['p2_name_arrival'])
v['npcs']=[npc('nameless','村人',16,11,'npc',['p2_name_remember'],maskedName=True),npc('neighbor','村人',11,16,'villager',maskedName=True),npc('smith','道具屋',16,9,'merchant',service='shop',serviceId='p2-name-shop',maskedName=True)]
v['portals']=[portal('p2-name-back',2,14,'p2_village',27,4,'紫の町へ戻る'),portal('p2-name-inn',7,9,'p2_name_inn',7,11,'宿屋'),portal('p2-name-hall',24,9,'p2_name_hall',12,15,'名前を奪った獣'),portal('p2-name-road',29,5,'p2_letter_road',4,14,'手紙の町への街道',{'p2NameCore':True})]
h=clone('ch6_king','p2_name_hall','第10章・盗まれた名前の広間');h.update(safeSpawn=dict(x=12,y=15,dir='up'),coreArea='name',entryEvents=['p2_nomen_battle'])
h['portals']=[portal('p2-name-hall-back',12,17,'p2_name_village',24,10,'村へ戻る')]
h['triggers']=[dict(x=12,y=10,event='p2_nomen_intro')];h['objects'].append(sign('p2-nomen-mark',12,9,'p2_nomen_hint','盗まれた名前の気配'))
events['p2_nomen_hint']=dict(pages=['この印の南側に立つと、盗まれた名前が姿を現す。'],once=False,effects=[])
h['enemies']=[dict(id='p2-nomen',enemy='P2_NOMEN',x=12,y=8,respawn=False,when={'p2NameCore':False,'p2NomenIntro':True},afterEvent='p2_name_release')]
r=clone('ch1_meadow','p2_letter_road','第10章・約束へ続く街道');r['safeSpawn']=dict(x=4,y=14,dir='right');r['portals']=[portal('p2-letter-road-back',3,14,'p2_name_village',28,5,'名前のない村'),portal('p2-letter-road-town',26,14,'p2_letter_town',3,18,'手紙の町')]
for n,x,y,enemy in [(1,10,12,'P2_NAMETHIEF'),(2,16,14,'P2_IRONGUARD'),(3,19,16,'P2_QUICKWORD'),(4,12,16,'P2_COINWORD')]:r['enemies'].append(dict(id='p2-core-roaming-'+str(n),enemy=enemy,x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.5,chaseRadius=2,leash=3)))
t=clone('ch5_town','p2_letter_town','第10章・手紙の町');t.update(safeSpawn=dict(x=3,y=18,dir='right'),coreArea='promise',entryEvents=['p2_promise_arrival'])
t['npcs']=[npc('resident','住民',16,11,'villager'),npc('merchant','道具屋',16,9,'merchant',service='shop',serviceId='p2-promise-shop')]
t['portals']=[portal('p2-letter-town-back',2,18,'p2_letter_road',25,14,'街道へ戻る'),portal('p2-letter-town-court',28,4,'p2_promise_court',3,14,'約束を奪った騎士'),portal('p2-letter-town-inn',22,7,'p2_letter_inn',7,11,'宿屋')]
t['objects'].append(sign('p2-delivery-note',9,7,'p2_promise_note','昨日の配達の約束','old_book'))
events['p2_promise_note']=dict(pages=['昨日届けるはずだった手紙が、まだ束のまま置かれている。約束した事実は覚えているのに、だれも動こうとしない。'],once=False,effects=[])
c=clone('ch5_courtyard','p2_promise_court','第10章・破られた約束の中庭');c.update(safeSpawn=dict(x=3,y=14,dir='up'),coreArea='promise',entryEvents=['p2_vow_battle'])
c['portals']=[portal('p2-promise-court-back',2,14,'p2_letter_town',27,4,'手紙の町')];c['objects'].append(sign('p2-memory-door',22,4,'p2_memory_boundary','記憶の書庫へ続く道','gate_door'));c['triggers']=[dict(x=18,y=9,event='p2_vow_intro')];c['enemies']=[dict(id='p2-vow',enemy='P2_VOW',x=18,y=7,respawn=False,when={'p2PromiseCore':False,'p2VowIntro':True},afterEvent='p2_promise_release')]
for old,new,name,target,px,py in [('ch1_inn','p2_name_inn','名前のない村の宿屋','p2_name_village',7,10),('ch5_inn','p2_letter_inn','手紙の町の宿屋','p2_letter_town',22,8)]:
 i=clone(old,new,name);i['safeSpawn']=dict(x=7,y=11,dir='up');i['portals']=[portal(new+'-back',7,12,target,px,py,name+'の外')];i['npcs']=[npc('innkeeper','宿の主人',7,6,'merchant',service='inn',serviceId=new)];d['inns'][new]=dict(name=name,price=100)
# Visible north road on existing chapter 9 town; retain school/outskirts entrances.
p=maps['p2_village'];p['objects']=[o for o in p['objects'] if o['id']!='p2-next-road'];p['portals']=[q for q in p['portals'] if q['id']!='p2-town-name'];p['portals'].append({**portal('p2-town-name',28,4,'p2_name_village',3,14,'名前のない村',{'chapter9Complete':True}),'entryEvent':'chapter10_departure'})
# The previously published sign event still works for old callers.
events['p2_next']={**copy.deepcopy(events['chapter10_departure']),'once':False}
cats=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語','文法']
for id,name,asset,hp,atk,de,sec,gold,role in [('P2_NAMETHIEF','名前を盗む文字獣','hound',530,133,57,18,245,'攻撃型'),('P2_IRONGUARD','紫霧の守り手','goblin',620,123,94,21,265,'防御型'),('P2_QUICKWORD','飛び散る文字翼','bat',470,116,51,13,230,'速攻型'),('P2_COINWORD','金字の獣','context_beast',670,123,62,21,380,'G報酬型'),('P2_NOMEN','千名獣ノーメン','context_beast',2420,142,66,19,1250,'章中ボス'),('P2_VOW','破約騎士ヴァウ','paraphrase_knight',2900,149,82,19,1550,'章中ボス')]:
 d['enemies'][id]=dict(id=id,name=name,asset=asset,hp=hp,attack=atk,defense=de,guard=de,attackSeconds=sec,exp=800 if id in ['P2_NOMEN','P2_VOW'] else 228,gold=gold,role=role,questionCategories=cats)
d['enemies']['P2_NOMEN']['forms']=[dict(at=1,label='レン',asset='context_beast',attack=142,defense=66,attackSeconds=19,hint='借りた名「レン」：攻撃型'),dict(at=.67,label='アオイ',asset='archive_wisp',attack=130,defense=59,attackSeconds=14,hint='借りた名「アオイ」：素早い攻撃'),dict(at=.34,label='村人',asset='archive_guardian',attack=151,defense=105,attackSeconds=20,hint='借りた名「村人」：厚い守り')]
d['enemies']['P2_VOW'].update(mechanic='vow',vowLength=3,vowPenalty=1.15,enrageAt=.5,enrageAttack=1.05,enrageSpeed=.9)
d['cores']={k:dict(name=n,itemId='CORE_'+k.upper()) for k,n in [('name','名前の核'),('promise','約束の核')]}
for k,v in d['cores'].items():d['items'][v['itemId']]=dict(id=v['itemId'],name=v['name'],type='key',icon='scroll',requiredLevel=1)
plan=read('part2-equipment-plan.json');active=['W027','A016','W028','A017'];plan['implemented']=True;plan['activation']='Only first four tiers active in Stage 5; later tiers remain planned.'
for g in plan['tiers']:
 if g['id'] in active:
  g.update(implemented=True,placement='p2-name-shop' if g['id'] in ['W027','A016'] else 'p2-promise-shop',note='Base attack / defense / fixed HP only. Listed master-bank special effects remain inactive.')
  q=d['equipment'][g['id']];q.update(attack=g['attack'],defense=g['defense'],HP=g['HP'],requiredLevel=g['requiredLevel'],**{'攻撃':g['attack'],'防御':g['defense'],'買値':g['price'],'特殊効果':'追加効果なし（能力値に反映）'})
for id,gear in [('p2-name-shop',['W027','A016']),('p2-promise-shop',['W028','A017'])]:d['shops'][id]=dict(name='核の旅の道具屋',products=[dict(id='I001',type='item',price=55)]+[dict(id=k,type='gear',price=next(g['price'] for g in plan['tiers'] if g['id']==k)) for k in gear])
d['objectives']=[o for o in d['objectives'] if not o.get('stage5')]
for o in d['objectives']:
 if o.get('part2') and o['when'].get('chapter9Complete') is True:o['when']['chapter10Started']=False;o['text']='第9章CLEAR。町の右上の石門から、名前のない村へ進もう。'
d['objectives'][:0]=[dict(part2=True,stage5=True,when=w,text=t) for w,t in [({'chapter10Started':True,'p2NameHeard':False},'名前のない村で、住民の名前が消えた異変を確かめよう。'),({'p2NameHeard':True,'p2NameCore':False},'村の右側の建物の扉へ。広間の中央の印に近づき、名前を奪った獣を止めよう。'),({'p2NameCore':True,'p2PromiseHeard':False},'村の右上の石門→街道の東の石門から、手紙の町へ。'),({'p2PromiseHeard':True,'p2PromiseCore':False},'手紙の町の右上の石門へ。中庭の東にいる破約騎士を止めよう。'),({'chapter10HalfComplete':True},'名前・約束の核を獲得。次は記憶の書庫へ。第10章後半は次の更新です。記録を残そう。')]]
for ch in d['chapters']:
 if ch['id']==10:ch.update(implemented=True,partial=True,implementedScenes=[69,70],entry=dict(map='p2_name_village',spawn=dict(x=3,y=14,dir='right')))
cont=read('continuation.json');cont.update(version='0.15.0',implementedScenes=list(range(65,71)));cont['chapters'][1].update(implemented=True,partial=True,implementedScenes=[69,70],half=dict(startLevel=20,endLevel=24,normalBattles=22,majorBattles=2,requiredExp=6330,normalExp=228,majorExp=800),note='Chapter 10 first half only. Actual Lv inherited; no forced level correction.')
canon['activation']='SCENE61–70 implemented; SCENE71–92 reserved for later stages'
for n in maps['p2_name_village']['npcs']:n['pages']=[dict(text='自分の名前が言えない。東の建物に、名前を使う獣がいる。',when={'p2NameCore':False}),dict(text='自分の名前で呼ばれる。この村に戻ってこられた。',when={'p2NameCore':True})]
for n in maps['p2_letter_town']['npcs']:n['pages']=[dict(text='約束したのは覚えている。守る必要は……あるのか？',when={'p2PromiseCore':False}),dict(text='昨日の約束を、今日果たそう。届ける手紙を持っていく。',when={'p2PromiseCore':True})]
for n,v in [('maps.json',maps),('game-data.json',d),('chapter10-events.json',events),('continuation.json',cont),('part2-equipment-plan.json',plan),('part2-canonical-scenes.json',canon)]:write(n,v)
# Final approach route and spaced encounters use the same verified meadow footprint.
exec((R/'tools/finish-part2-cores-routes.py').read_text())
print('Stage 5: eight reused-material maps; name/promise missions and two distinct bosses.')
