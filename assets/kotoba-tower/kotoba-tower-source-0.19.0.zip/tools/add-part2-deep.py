"""Stage 8: SCENE75–79, four explorable memory areas and reported collision fixes.
Run after add-part2-support.py when reconstructing all part-2 data.
"""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/'data'/n).read_text())
def write(n,v):(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
d=read('game-data.json');m=read('maps.json');canon=read('part2-canonical-scenes.json');ev={};seq=d['sequences']
def flags(**v):return dict(type='flags',values=v)
def speech(n):return dict(type='dialogue',pages=[dict(speaker=p['speaker'],text=p['text'],sourceScene=n,sourceLine=p['sourceLine'],sourceDocument='part2')for p in canon['scenes'][str(n)]['entries'] if p['speaker']])
def event(id,steps,when=None):
 seq[id]=steps+[dict(type='finish')];ev[id]=dict(pages=[],when=when or {},effects=[dict(type='sequence',id=id)])
def text(*pages):return dict(type='dialogue',pages=list(pages))
def portal(id,x,y,target,sx,sy,label,requires=None,kind='stairs'):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='up'),kind=kind,asset='stairs_down' if kind=='stairs' else 'gate_door',width=32,height=32,label=label,interactionLabel=label+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['この区画の記録を確かめてから進もう。「目的」で確認できます。'])
 return p
def object(id,x,y,asset='old_book',events=None,label=None):return dict(id=id,kind='sign',x=x,y=y,asset=asset,width=32,height=32,anchorX=16,anchorY=32,footprint=[dict(x=0,y=0,w=32,h=32)],events=events or [],interactionLabel=label or '記録を調べる')
def chest(id,x,y,loot):return {**object(id,x,y,'chest'), 'kind':'chest','loot':loot}
def clone(old,new,name,area,sx,sy):
 a=copy.deepcopy(m[old]);a.update(id=new,name=name,part2=True,chapter=12,stage8=True,deepArea=area,safeSpawn=dict(x=sx,y=sy,dir='up'),npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[],objects=[])
 for k in ['school','epilogue','night','memory','afterStory','stage6','stage7','coreArea','wordStream']:a.pop(k,None)
 m[new]=a;return a
# Visible facade shares a real entrance with the existing portal. 3x3 tiles, no overlap.
v=m['p2_village'];v['objects']=[o for o in v['objects'] if o['id']!='p2-warehouse-facade'];v['objects'].append(dict(id='p2-warehouse-facade',kind='building',x=22,y=14,asset='stone_house',width=96,height=96,anchorX=48,anchorY=96,footprint=[dict(x=0,y=0,w=96,h=64),dict(x=0,y=64,w=32,h=32),dict(x=64,y=64,w=32,h=32)],entrance=dict(x=32,y=64,w=32,h=32)))
for o in m['ch8_refuge']['objects']:
 if o['id']=='ch8-rest-record':o['footprint']=[dict(x=0,y=0,w=32,h=32)]
# A gate checks the actual four core values, not a derived completion flag.
a=m['p2_deep_ante'];a['objects']=[o for o in a['objects'] if o['id']!='p2-deep-wait-door'];a['portals']=[p for p in a['portals'] if p['id']!='p2-deep-entry'];p=portal('p2-deep-entry',12,3,'p2_deep_garden',4,16,'四つの核の扉',{'p2WarehouseOpen':True},'door');p.update(requiresCores=['name','promise','memory','tomorrow'],entryEvent='chapter12_departure',lockedPages=['名前・約束・思い出・明日。四つの核をそろえ、鍛冶屋の倉庫で準備してから戻ろう。']);a['portals'].append(p)
event('chapter12_departure',[flags(chapter12Started=True),dict(type='chapter',value=12),dict(type='map',map='p2_deep_ante',spawn=dict(x=12,y=4,dir='up')),text('名前・約束・思い出・明日。四つの核が共鳴して、見たことのない扉が開く。'),dict(type='visual',kind='core-resonance',duration=2.0),dict(type='map',map='p2_deep_garden',spawn=dict(x=4,y=16,dir='up')),speech(75),flags(p2DeepEntered=True),text('壁に流れるのは、以前戦った敵の名前だ。塔の残った仕組みと、レンの中の世界がつながっている。')],{'p2WarehouseOpen':True,'chapter12Started':False});ev['chapter12_departure']['requiresCores']=['name','promise','memory','tomorrow']
# Chapter-11 completion stays reviewable while offering the new route.
seq['p2_deep_ready']=[flags(chapter11Complete=True),text('塔の地下手前に着いた。扉の奥から、レンが抱えた言葉の気配がする。','アオイのサポートと倉庫の装備を使い、ここまで来た。ここで冒険の記録を保存できる。','四つの核で北の扉を開こう。「第12章へ進む」からも続けられる。'),dict(type='finish')]
# A restored save in the middle of the old chapter-11 boundary sequence remains valid.
d['events'].pop('p2_deep_boundary',None)
g=clone('ch1_meadow','p2_deep_garden','第12章・深層1 言い回しの庭・反転','garden',4,16)
g['objects']=[{**copy.deepcopy(o),'id':'deep-'+o['id']}for o in m['ch1_meadow']['objects'] if o['kind']=='tree']
g['objects'].append(chest('p2-deep-garden-cache',8,14,dict(items={'I001':3},gold=1400)))
g['portals']=[portal('p2-deep-garden-back',3,16,'p2_deep_ante',12,4,'塔地下へ戻る',kind='door'),portal('p2-deep-garden-next',26,10,'p2_deep_archive',14,19,'深層2・崩壊の書庫',{'p2DeepGardenGuard':True})];g['entryEvents']=['p2_deep_garden_scene']
event('p2_deep_garden_scene',[speech(76),flags(p2DeepGardenHeard=True),text('紫の文字でできた植物の奥に、昔の魔物の断片が重なっている。東の階段を守る強敵を倒し、次の区画へ進もう。')],{'p2DeepEntered':True,'p2DeepGardenHeard':False})
event('p2_deep_garden_reward',[dict(type='gear',id='W014'),flags(p2DeepGardenGuard=True),text('雷鳴の槍を手に入れた。Lv32から装備でき、会心率が4％上がる。','東の階段が開いた。レンの記憶をたどって、深層2へ進もう。')])
g['enemies'].append(dict(id='p2-deep-garden-guard',enemy='P2_DEEP_GUARD',x=24,y=10,respawn=False,afterEvent='p2_deep_garden_reward'))
a=clone('p2_memory_archive','p2_deep_archive','第12章・深層2 記憶の書庫・崩壊','archive',14,19)
a['objects']=[{**copy.deepcopy(o),'id':'deep-'+o['id']}for o in m['p2_memory_archive']['objects'] if o['asset']=='school_shelf']
a['objects'] += [object('p2-deep-memory-note',24,14,events=['p2_deep_memory_read'],label='レンが残した記録'),chest('p2-deep-archive-cache',20,16,dict(gear=['A020'],items={'I001':2}))]
a['portals']=[portal('p2-deep-archive-back',14,20,'p2_deep_garden',25,10,'深層1へ戻る',kind='door'),portal('p2-deep-archive-next',27,5,'p2_deep_letter',3,14,'深層3・黒い手紙',{'p2DeepMemoryRead':True})];a['entryEvents']=['p2_deep_archive_scene']
event('p2_deep_archive_scene',[speech(77),flags(p2DeepArchiveHeard=True),text('本棚は浮かび、ページが紫の渦へ吸われている。右下の記録を調べて、レンが手放せないものを確かめよう。')],{'p2DeepArchiveHeard':False})
event('p2_deep_memory_read',[text('記録には、何度も同じ言葉が残る。「忘れたくない。もう、なくしたくない。」','抱えた言葉を返せなくなった記憶だ。右上の階段が、届かなかった手紙へつながっている。'),flags(p2DeepMemoryRead=True)],{'p2DeepMemoryRead':False})
l=clone('ch5_courtyard','p2_deep_letter','第12章・深層3 届かなかった手紙・黒化','letter',3,14)
l['objects']=[object('p2-deep-named-letter',13,8,'scroll',events=['p2_deep_letter_scene'],label='自分の名前のある手紙'),chest('p2-deep-letter-cache',8,13,dict(items={'I001':3},gold=1800))]
l['portals']=[portal('p2-deep-letter-back',2,14,'p2_deep_archive',26,5,'深層2へ戻る',kind='door'),portal('p2-deep-letter-next',23,4,'p2_deep_silent',3,22,'深層4・無音の街',{'p2DeepLetterRead':True})];l['entryEvents']=['p2_deep_letter_arrival']
event('p2_deep_letter_arrival',[text('宛先のない手紙が浮いている。一枚だけ自分の名前がある。中央の手紙を調べよう。'),flags(p2DeepLetterArrived=True)],{'p2DeepLetterArrived':False})
event('p2_deep_letter_scene',[speech(78),flags(p2DeepLetterRead=True),text('自分の名前だけが書かれ、本文は白紙だった。返せなかった約束を残して、レンは一人で待っていた。','右上の階段から、深層4へ。まだ間に合う。')],{'p2DeepLetterRead':False})
s=clone('p2_future_town','p2_deep_silent','第12章・深層4 忘却の街・無音','silent',3,22)
s['objects']=[{**copy.deepcopy(o),'id':'deep-'+o['id']}for o in m['p2_future_town']['objects'] if o['kind']=='building']
s['objects']+=[object('p2-deep-management-door',30,4,'gate_door',events=['p2_deep_complete'],label='管理領域の扉'),chest('p2-deep-silent-cache',14,17,dict(items={'I001':3},gold=2000))]
s['portals']=[portal('p2-deep-silent-back',2,22,'p2_deep_letter',22,4,'深層3へ戻る',kind='door')];s['entryEvents']=['p2_deep_silent_scene'];s['shadowPositions']=[[10,10],[17,15],[24,18]];s['nameWall']=dict(x=28,y=5)
event('p2_deep_silent_scene',[text('音楽も、人の言葉も消えている。影は口を動かすが、文字にならない。','壁の「レン」の文字が、歩くたびに欠けていく。名前まで失われる前に、右上の管理領域の扉へ急ごう。'),speech(79),flags(p2DeepSilentHeard=True)],{'p2DeepSilentHeard':False})
event('p2_deep_complete',[flags(chapter12Complete=True),text('管理領域の扉に着いた。レンがいる場所は、この先だ。','四つの区画を抜けた。ここで保存でき、町へ戻って準備もできる。レンとの再会は次の工程で続く。')],{'p2DeepSilentHeard':True,'chapter12Complete':False})
ev['p2_deep_management_wait']=dict(pages=['管理領域まで到達した。レンとの再会は次の更新で続く。ここで記録を保存できる。'],once=False,when={'chapter12Complete':True},effects=[]);s['objects'][-2]['events'].append('p2_deep_management_wait')
# Four normal encounters per area, plus one compulsory guardian; 6120 EXP total.
positions=[[(9,7),(13,10),(18,12),(23,14)],[(3,8),(12,8),(21,8),(27,17)],[(6,5),(19,5),(7,11),(19,12)],[(8,18),(16,12),(23,14),(28,9)]]
ids=['P2_DEEP_BEAST','P2_DEEP_WISP','P2_DEEP_LETTER','P2_DEEP_SHADOW']
for area,points in zip([g,a,l,s],positions):
 for i,(x,y) in enumerate(points):area['enemies'].append(dict(id=area['id']+'-normal-'+str(i),enemy=ids[i],x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.60,chaseRadius=2,leash=3)))
cats=d['enemies']['P2_MEMORIA']['questionCategories']
for id,name,asset,hp,atk,de,sec,gold,exp,family,element,fusion in [
 ('P2_DEEP_BEAST','言い回しの断片獣','context_beast',1580,251,161,21,1100,270,'beast','physical',['bat','hound']),
 ('P2_DEEP_WISP','浮遊する記憶片','archive_wisp',1380,248,149,20,1150,270,'spirit','fire',['goblin','bat']),
 ('P2_DEEP_LETTER','宛先のない文字兵','archive_guardian',1650,256,175,23,1200,270,'guard','physical',['archive_wisp','hound']),
 ('P2_DEEP_SHADOW','失われかけた影','bat',1340,244,142,18,1050,270,'beast','lightning',['hound','archive_wisp']),
 ('P2_DEEP_GUARD','庭を抱える残響','archive_guardian',5250,264,180,23,3200,1800,'guard','lightning',['context_beast','bat'])]:
 d['enemies'][id]=dict(id=id,name=name,asset=asset,hp=hp,attack=atk,defense=de,guard=de,attackSeconds=sec,gold=gold,exp=exp,family=family,element=element,fusionAssets=[asset]+fusion,questionCategories=cats,role='深層の強敵' if id=='P2_DEEP_GUARD' else '融合した旧敵の断片')
plan=read('part2-equipment-plan.json')
for t in plan['tiers']:
 if t['chapter']==12:
  t.update(implemented=True,effectImplemented=True,placement='p2-deep-garden-guard' if t['id']=='W014' else 'p2-deep-archive-cache',note='Existing unused master gear released in chapter 12; no forced level adjustment.')
  d['equipment'][t['id']].update(attack=t['attack'],defense=t['defense'],HP=t['HP'],requiredLevel=t['requiredLevel'],**{'攻撃':t['attack'],'防御':t['defense'],'買値':t['price']})
d['enemies']['P2_DEEP_WISP']['weakElements']=['lightning']
d['equipment']['W014']['effects']=dict(critical=.04,element='lightning');d['equipment']['A020']['effects']=dict(evasion=.08)
for t in plan['tiers']:
 if t['chapter']==12 and not any(p['id']==t['id']for p in d['shops']['p2-warehouse-shop']['products']):d['shops']['p2-warehouse-shop']['products'].append(dict(id=t['id'],type='gear',price=t['price']))
plan['activation']='First ten tiers active through Stage 8. Future chapter 13/14 gear remains reserved.'
d['objectives']=[o for o in d['objectives'] if not o.get('stage8')]
d['objectives'][:0]=[dict(stage8=True,part2=True,when=w,text=t) for w,t in [({'chapter12Complete':True},'管理領域の扉に到達。ここで記録を保存できる。レンとの再会は次の工程。町へ戻って準備もできる。'),({'p2DeepSilentHeard':True,'chapter12Complete':False},'深層4：右上の管理領域の扉へ。影の住民には言葉が戻らず、レンの名前が欠けている。'),({'p2DeepLetterRead':True,'p2DeepSilentHeard':False},'深層3：自分宛ての手紙を確かめた。右上の階段から深層4・無音の街へ。'),({'p2DeepLetterArrived':True,'p2DeepLetterRead':False},'深層3：中央の、自分の名前が書かれた白紙の手紙を調べよう。'),({'p2DeepMemoryRead':True,'p2DeepLetterArrived':False},'深層2：レンの記録を確かめた。右上の階段から深層3へ。'),({'p2DeepArchiveHeard':True,'p2DeepMemoryRead':False},'深層2：右下の記録を調べよう。本棚の間を通り、宝箱の装備も確認できる。'),({'p2DeepGardenGuard':True,'p2DeepArchiveHeard':False},'深層1：強敵を倒した。東の階段から深層2へ。雷鳴の槍はLv32から装備できる。'),({'p2DeepEntered':True,'p2DeepGardenGuard':False},'深層1：東の階段を守る強敵を倒そう。町へ戻って倉庫・宿屋で準備できる。')]]
for o in d['objectives']:
 if o.get('stage7') and o['when'].get('chapter11Complete'):o['text']='四つの核で塔地下の北の扉を開こう。「第12章へ進む」からも続けられる。'
for ch in d['chapters']:
 if ch['id']==12:ch.update(implemented=True,entry=dict(map='p2_deep_ante',spawn=dict(x=12,y=4,dir='up')))
cont=read('continuation.json');cont.update(version='0.18.0',implementedScenes=list(range(65,80)));cont['chapters'][3].update(implemented=True,note='Four explorable deep areas, 16 normal encounters and one guardian; level inherited.')
canon['activation']='SCENE61–79 implemented; SCENE80–92 reserved.'
for name,val in [('game-data.json',d),('maps.json',m),('chapter12-events.json',ev),('continuation.json',cont),('part2-equipment-plan.json',plan),('part2-canonical-scenes.json',canon)]:write(name,val)
print('Stage 8: warehouse/rest fixes, four core gate, four deep areas, SCENE75–79.')
