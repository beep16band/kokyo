"""Chapter 3 scenes 20–25. Reusable data only; no newly authored battle questions."""
from pathlib import Path
import json
R = Path(__file__).resolve().parents[1]
maps = json.loads((R/'data/maps.json').read_text())
d = json.loads((R/'data/game-data.json').read_text())
events = {}

def event(id, pages, flags=None, when=None, effects=None, once=True):
    events[id] = dict(id=id, pages=[dict(speaker=s, text=t) for s,t in pages],
        when=when or {}, effects=([dict(type='flags', values=flags)] if flags else [])+(effects or []), once=once)
def travel(id,x,y,direction='up'):
    return dict(type='travel',map=id,spawn=dict(x=x,y=y,dir=direction))
def room(id,name,w,h,inside=False):
    m=dict(id=id,name=name,chapter=3,width=w,height=h,
        tiles=['floor' if inside else 'grass']*(w*h),
        collision=[int(x==0 or y==0 or x==w-1 or y==h-1) for y in range(h) for x in range(w)],
        wallAsset='wall' if inside else 'rock_wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[])
    maps[id]=m
    return m
def object(m,id,x,y,asset,w=32,h=32,solid=True,events=None,kind='decor'):
    o=dict(id=id,x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,kind=kind,
           footprint=[dict(x=0,y=0,w=w,h=h)] if solid else [])
    if events:o.update(events=events,interactionRect=dict(x=x*32+16-w//2,y=y*32+32-h,w=w,h=h),interactionLabel='記録を調べる')
    m['objects'].append(o)
    return o
def npc(m,id,name,x,y,asset,ev=None,pages=None,service=None):
    n=dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),events=ev or [],pages=pages or ['書庫の記録も、人の話も、どちらも確かめておいで。'])
    if service:n.update(service=service[0],serviceId=service[1])
    m['npcs'].append(n)
def portal(m,id,x,y,target,sx,sy,kind='door',requires=None,direction='up',asset=None):
    p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir=direction),kind=kind,asset=asset or ('stone_arch' if kind=='path' else 'gate_door'))
    if requires:p.update(requires=requires,lockedPages=['今は奥へ進めない。町の記録と、人が覚えていることを確かめよう。'])
    m['portals'].append(p)
    return p
def road(m,points):
    for x,y in points:
        for dx,dy in [(0,0),(-1,0),(1,0),(0,-1),(0,1)]:
            a,b=x+dx,y+dy
            if 0<a<m['width']-1 and 0<b<m['height']-1:m['tiles'][b*m['width']+a]='path'
def chest(m,id,x,y,gold=0,items=None,gear=None):
    o=object(m,id,x,y,'chest',kind='chest');o['loot']=dict(gold=gold,items=items or {},gear=gear or [])
def house(m,id,x,y):
    o=object(m,id,x,y,'stone_house',128,128,kind='building')
    o['footprint']=[dict(x=0,y=0,w=128,h=96),dict(x=0,y=96,w=48,h=32),dict(x=80,y=96,w=48,h=32)]
    o['entrance']=dict(x=48,y=96,w=32,h=32)

# Connect the already-completed chapter, preserving old return portals and saves.
g=maps['ch2_gate']
g['objects']=[o for o in g['objects'] if o['id']!='future_archive_gate']
g['portals']=[p for p in g['portals'] if p['id']!='gate-chapter3']
portal(g,'gate-chapter3',10,4,'ch3_approach',3,14,'path',{'chapter2Complete':True})
t=room('ch3_approach','第3章・書庫へ続く石畳',24,18)
t['entryEvents']=['ch3_approach_intro']
road(t,[(x,14) for x in range(2,22)]+[(21,y) for y in range(4,15)])
portal(t,'ch3-road-back',2,14,'ch2_gate',10,5,'path',direction='down')
portal(t,'ch3-road-town',21,4,'ch3_town',3,18,'path')
for i,(x,y) in enumerate([(4,5),(8,6),(12,4),(17,6),(4,10),(7,16),(17,16)]):
    o=object(t,'ch3-tree-'+str(i),x,y,'tree',64,64);o['footprint']=[dict(x=26,y=48,w=12,h=16)]
t['enemies']=[dict(id='ch3-road-wisp',enemy='S3_WISP',x=12,y=14,respawn=True)]
chest(t,'ch3-road-cache',9,10,60,{'I001':2})

v=room('ch3_town','第3章・古い書庫の町',34,24)
v['entryEvents']=['ch3_town_intro'];v['safeSpawn']=dict(x=16,y=19,dir='up')
road(v,[(x,18) for x in range(2,32)]+[(16,y) for y in range(9,20)]+[(7,y) for y in range(10,19)])
house(v,'ch3-archive-house',16,9);house(v,'ch3-inn-house',7,10)
portal(v,'ch3-town-road',2,18,'ch3_approach',20,4,'path',direction='left')
portal(v,'ch3-town-archive',16,9,'ch3_archive',14,19,requires={'diaryCompared':True,'letterCompared':True,'blankPaperCompared':True})
portal(v,'ch3-town-inn',7,10,'ch3_inn',7,11)
npc(v,'diary_owner','日記を持つ住民',7,15,'elderwoman',['ch3_diary','ch3_diary_repeat'])
npc(v,'letter_owner','手紙を持つ住民',20,15,'merchant',['ch3_letter','ch3_letter_repeat'])
npc(v,'blank_owner','白い紙を持つ住民',27,18,'villager',['ch3_blank','ch3_blank_repeat'])
npc(v,'ch3_merchant','書庫の町の道具屋',16,20,'merchant',service=('shop','archive-shop'))
chest(v,'ch3-town-cache',30,20,50,{'I001':1})

i=room('ch3_inn','第3章・書庫の町の宿',18,15,True)
i['safeSpawn']=dict(x=7,y=11,dir='up')
portal(i,'ch3-inn-back',7,12,'ch3_town',7,11,direction='down')
npc(i,'ch3_innkeeper','宿の人',7,7,'elderwoman',service=('inn','archive-inn'))

a=room('ch3_archive','第3章・記憶の書庫',32,22,True)
a['entryEvents']=['ch3_archive_intro'];a['safeSpawn']=dict(x=14,y=19,dir='up')
portal(a,'ch3-archive-back',14,20,'ch3_town',16,10,direction='down')
portal(a,'ch3-archive-vault',27,5,'ch3_vault',3,16,'stairs',{'aoiHandwritingRead':True},asset='stairs_down')
for j,(x,y) in enumerate([(5,5),(9,5),(14,5),(19,5),(5,11),(9,11),(14,11),(19,11),(5,16),(9,16)]):
    object(a,'ch3-shelf-'+str(j),x,y,'school_shelf',64,64)
object(a,'ren_record_ticket',14,8,'scroll',events=['ch3_ren_ticket','ch3_ren_ticket_repeat'])
object(a,'aoi_notebook_table',24,14,'old_book',events=['ch3_notebook','ch3_notebook_wait','ch3_notebook_repeat'])
npc(a,'archive_keeper','書庫の世話人',24,9,'npc',pages=['中央の机に、名前の消えた記録票がある。右の閲覧席でノートを読んだら、右上の階段から保存庫へ行ける。'])
chest(a,'ch3-archive-cache',28,17,80,{'I001':2},['A002'])

s=room('ch3_vault','第3章・地下保存庫',30,20,True)
s['entryEvents']=['ch3_vault_intro'];s['safeSpawn']=dict(x=3,y=16,dir='up')
portal(s,'ch3-vault-back',2,16,'ch3_archive',27,6,'stairs',direction='down',asset='stairs_up')
portal(s,'ch3-vault-guardian',25,4,'ch3_guardian',12,15,requires={'storageCompared':True})
for j,(x,y) in enumerate([(7,5),(12,5),(17,5),(7,10),(12,10),(17,10)]):object(s,'vault-shelf-'+str(j),x,y,'school_shelf',64,64)
object(s,'preserved_register',9,14,'scroll',events=['ch3_preserved_record','ch3_preserved_repeat'])
object(s,'preservation_wall',23,10,'stone_gate',64,64,events=['ch3_storage_compare','ch3_storage_wait','ch3_storage_repeat'])
s['enemies']=[dict(id='ch3-vault-wisp',enemy='S3_WISP',x=20,y=14,respawn=True)]
# Reading tables sit beneath the small book/scroll sprites and share their collision bounds.
for m,id,x,y in [(a,'ticket-table',14,8),(a,'notebook-table',24,14),(s,'register-table',9,14)]:
    table=object(m,id,x,y,'school_reading_table',64,64)
    table['depthOffset']=-1

chest(s,'ch3-vault-cache',25,16,100,{'I001':3})

b=room('ch3_guardian','第3章・守護者の記録室',26,20,True)
b['entryEvents']=['ch3_guardian_room'];portal(b,'ch3-guardian-back',12,17,'ch3_vault',25,5,direction='down')
portal(b,'ch3-guardian-terrace',12,3,'ch3_terrace',10,12,requires={'archiveGuardianFreed':True})
for y in [8]:
    for x in range(1,25):
        if x!=12:b['collision'][y*26+x]=1
b['enemies']=[dict(id='archive-guardian',enemy='S3_GUARDIAN',x=12,y=9,introEvent='ch3_guardian_appears',afterEvent='ch3_guardian_freed')]
chest(b,'ch3-guardian-cache',20,13,120,{'I001':2})

c=room('ch3_terrace','第3章・書庫の外廊',22,16)
c['entryEvents']=['chapter3_clear'];road(c,[(10,y) for y in range(4,14)])
portal(c,'ch3-terrace-back',10,13,'ch3_guardian',12,4,direction='down')
object(c,'chapter4_route',10,4,'stone_arch',solid=False,events=['chapter4_not_ready'])

event('chapter3_departure',[('レン','門の先に、古い書庫の町がある。あそこなら、残っている記録を読めるかもしれない。'),('主人公','ノートの字が消えなかった理由も……。行こう。')],{'chapter3Started':True},{'chapter2Complete':True},[dict(type='chapter',value=3),travel('ch3_approach',3,14)])
event('ch3_approach_intro',[('','第3章　記憶の書庫'),('レン','この道の石にも、地下の扉と似た紋章がある。'),('主人公','塔へ続く道なのか。まず、北東の門から町に入ろう。')],{'chapter3Started':True},effects=[dict(type='chapter',value=3)])
event('ch3_town_intro',[('','町の家々には、古い日記や手紙が残されている。人々は、それを読みながら自分の過去を確かめていた。'),('主人公','記録が残ってれば、思い出せる……？'),('レン','でも、白い紙を握っている子もいる。何が残って、何が消えたのか、話を聞こう。'),('','西の広場の日記、中央の手紙、東の白い紙。三人の話を聞いたら、北の大きな書庫へ。')],{'ch3TownVisited':True})
event('ch3_diary',[('日記を持つ住民','昨日、誰と庭にいたのか思い出せなかったの。でも、ここに「孫と花を植えた」って。'),('','日記には、花の色も、孫の小さな失敗も書かれている。'),('日記を持つ住民','読んでいたら、笑った顔を思い出した。まだ、全部ではないけれど。'),('主人公','忘れていても、書いたことが手掛かりになるんだ。')],{'diaryCompared':True})
event('ch3_diary_repeat',[('日記を持つ住民','紙が覚えていることを、もう一度読んでみるわ。')],when={'diaryCompared':True},once=False)
event('ch3_letter',[('手紙を持つ住民','この手紙は、私が友人に宛てたものらしい。でも、友人の顔がどうしても浮かばない。'),('','封筒には、送り先の名前と、一緒に旅をした日付が残っている。'),('主人公','字はあるのに、それだけじゃ、顔までは戻らないんですね。'),('レン','記録と記憶は、同じものじゃない。')],{'letterCompared':True})
event('ch3_letter_repeat',[('手紙を持つ住民','名前を声に出してみる。誰かが覚えているかもしれないから。')],when={'letterCompared':True},once=False)
event('ch3_blank',[('白い紙を持つ住民','ここに、母さんが「遅くなるから先に食べてね」って書いたの。今は白いけど。'),('主人公','読めなくなったのに、内容は覚えてる？'),('白い紙を持つ住民','うん。その日は、母さんを待っていたから。帰ってきた声も覚えてる。'),('レン','文字が消えても、人の中に残ることがあるんだな。'),('主人公','記録が残れば記憶も残る……だけじゃ、説明できない。書庫も調べよう。')],{'blankPaperCompared':True})
event('ch3_blank_repeat',[('白い紙を持つ住民','白くなっても、あの日のことまでなくなったわけじゃない。')],when={'blankPaperCompared':True},once=False)
event('ch3_archive_intro',[('','古い書庫。棚には、欠けた文字と、残った文字が混じっている。'),('レン','……あの机の記録票。俺の留め具と、同じ形がある。'),('主人公','中央の机だな。近くで見よう。')],{'ch3ArchiveEntered':True})
event('ch3_ren_ticket',[('','記録票の上に、見覚えのある紋章が押されている。地下の石扉と、レンの留め具にあったものだ。'),('主人公','名前の欄だけ、消えてる。番号は残ってるのに。'),('レン','俺の……記録なのか？'),('主人公','塔の関係者だったのかもしれない。でも、これだけじゃ断定できない。'),('レン','俺には、昨日がないから。……その番号を見ても、何も思い出せない。'),('主人公','ほかの記録も探そう。右の閲覧席で、ノートも確かめたい。')],{'renTicketFound':True})
event('ch3_ren_ticket_repeat',[('','名前欄は白い。記録番号と、地下の扉・レンの留め具と同じ紋章が残る。')],when={'renTicketFound':True},once=False)
event('ch3_notebook_wait',[('主人公','先に、中央の机の記録票を見よう。レンが気にしている。')],when={'renTicketFound':False},once=False)
event('ch3_notebook',[('','アオイの国語ノートを開く。授業の要点の横に、小さく「先生、ここ三回目」と書いてある。'),('主人公','……こんなこと、書いてたのか。'),('','字は少し右に傾いている。花の落書き、書き直した一行。声を思い出す。'),('アオイ','返すとき、ちゃんと授業受けてたかテストするから。'),('主人公','会いたい。……返すためだけじゃなくて。'),('','その言葉を、初めて心の中で認めた。ノートを閉じ、鞄へ戻す。'),('レン','右上の階段が、地下保存庫へ続いてる。行こう。')],{'aoiHandwritingRead':True},{'renTicketFound':True})
event('ch3_notebook_repeat',[('主人公','この字を読むと、アオイの声が聞こえる気がする。……ちゃんと返しに行こう。')],when={'aoiHandwritingRead':True},once=False)
event('ch3_vault_intro',[('','地下保存庫。町の本とは違い、ここの文字はほとんど欠けていない。'),('レン','壁の組み方も、紋章も、塔と同じだ。'),('主人公','塔と同じ技術で作った保存庫……。左奥の記録と、右側の壁を比べよう。')],{'ch3VaultEntered':True})
event('ch3_preserved_record',[('','保存台帳には、町の人が忘れていた名前や日付が、欠けずに残っている。'),('主人公','上の書庫では消えてた名前が、ここでは読める。'),('レン','残してある。少なくとも、この保存庫では。')],{'preservedRecordRead':True})
event('ch3_preserved_repeat',[('','町の文字が薄れる中、地下保存庫の台帳はほぼ完全に読める。')],when={'preservedRecordRead':True},once=False)
event('ch3_storage_wait',[('レン','西側の通路にある保存台帳を先に読もう。文字の残り方を比べたい。')],when={'preservedRecordRead':False},once=False)
event('ch3_storage_compare',[('','壁には、地下の石扉と同じ紋章と、「記録されたものは、失われない。」の一文がある。'),('主人公','塔が奪ってるなら、なんで塔と同じ場所の文字は残る？'),('レン','……分からない。ここに残っているのは、確かだ。'),('主人公','集めてるように見えた光も、奪うためとは限らないのか。'),('レン','まだ答えは出ない。奥の記録室で、守護者に聞こう。'),('','北東の扉が開いた。')],{'storageCompared':True},{'preservedRecordRead':True})
event('ch3_storage_repeat',[('主人公','塔と同じ施設ほど、文字が残ってる。犯人だと決めつけるには、矛盾がある。')],when={'storageCompared':True},once=False)
event('ch3_guardian_room',[('','奥の記録室。通路の中央に、書庫の守護者が立っている。')],{'guardianRoomEntered':True})
event('ch3_guardian_appears',[('書庫の守護者','記録だけ残せば心は不要。読む者が消えても、保存は続く。'),('主人公','人が何を覚えてるかなんて、どうでもいいのか？'),('書庫の守護者','乱れを生むのは、人の心。消えない記録だけでよい。'),('レン','通してもらえそうにない。言葉を取り戻そう。')],{'guardianBattleStarted':True},effects=[dict(type='battle',encounter='archive-guardian')])
event('ch3_guardian_freed',[('','守護者を覆っていた固い文字がほどける。棚の記録は、そこに残っている。'),('主人公','残ってるだけじゃだめだ。読む人がいて、思い出す人がいる。'),('レン','白い紙の言葉を覚えていた子もいた。記録の外にも、言葉は残る。'),('書庫の守護者','読む……人。思い出す……人。'),('主人公','どっちかだけじゃ、足りないんだ。'),('','北の扉が開いた。外廊へ進もう。')],{'archiveGuardianFreed':True})
event('chapter3_clear',[('','書庫を出ると、遠い塔が夕暮れの中に立っていた。塔が何をしているのか、まだ答えは出ない。'),('レン','アオイに何を言う？'),('主人公','まだ分からない。でも、会ったらちゃんと話す。'),('レン','……うん。'),('','ノートを持ち直し、次の道へ向かう。\n第3章　記憶の書庫　CLEAR')],{'chapter3Complete':True},{'archiveGuardianFreed':True})
event('chapter4_not_ready',[('レン','この先が、次の町への道だ。'),('','第4章「選べなかった言葉」は次工程で実装します。今は書庫の町へ戻って、記録や装備を確かめられます。')],once=False)

d['chapters'][3]=dict(id=3,name='記憶の書庫',implemented=True,scenes=list(range(20,26)))
d['enemies']['S3_WISP']=dict(id='S3_WISP',name='忘却の灯',hp=90,attack=9,attackSeconds=13,exp=38,gold=45,asset='archive_wisp',questionCategories=['熟語の読み方','故事成語'])
d['enemies']['S3_GUARDIAN']=dict(id='S3_GUARDIAN',name='書庫の守護者',hp=260,attack=13,attackSeconds=14,exp=145,gold=200,asset='archive_guardian',questionCategories=['故事成語','熟語の読み方'])
d['shops']['archive-shop']=dict(name='書庫の町の道具屋',products=[dict(id='I001',type='item',price=35),dict(id='A002',type='gear',price=180),dict(id='W005',type='gear',price=600)])
d['inns']['archive-inn']=dict(name='書庫の町の宿',price=18)
new_objectives=[
    ({'chapter3Complete':True},'第3章CLEAR。書庫の町へ戻って準備できる。第4章は次工程。'),
    ({'archiveGuardianFreed':True},'守護者の奥、北の扉から書庫の外廊へ。'),
    ({'guardianRoomEntered':True},'中央の書庫の守護者を倒し、北の扉へ。'),
    ({'storageCompared':True},'地下保存庫の北東の扉から、守護者の記録室へ。'),
    ({'preservedRecordRead':True},'地下保存庫の東側、紋章のある壁を調べよう。'),
    ({'ch3VaultEntered':True},'地下保存庫の西側通路にある保存台帳を読もう。'),
    ({'aoiHandwritingRead':True},'書庫の右上の階段から、地下保存庫へ。'),
    ({'renTicketFound':True},'書庫の右側の閲覧席で、アオイのノートを開こう。'),
    ({'ch3ArchiveEntered':True},'書庫の中央の机にある、名前の消えた記録票を調べよう。'),
    ({'diaryCompared':True,'letterCompared':True,'blankPaperCompared':True},'町の北側、大きな書庫の正面入口へ。'),
    ({'ch3TownVisited':True},'町の三人に話そう。西の日記、中央の手紙、東の白い紙。'),
    ({'chapter3Started':True},'石畳を北東へ進み、古い書庫の町へ。'),
]
d['objectives']=[dict(when=when,text=text) for when,text in new_objectives]+[o for o in d['objectives'] if not any(k.startswith('ch3') or k in ['chapter3Started','chapter3Complete','archiveGuardianFreed','guardianRoomEntered','storageCompared','preservedRecordRead','aoiHandwritingRead','renTicketFound','diaryCompared','letterCompared','blankPaperCompared'] for k in o.get('when',{}))]
for o in d['objectives']:
    if o.get('when')=={'chapter2Complete':True}:o['text']='第2章CLEAR。北の門から第3章「記憶の書庫」へ。'

# Door nameplates are concise; approach hints give an exact destination and action.
short_names={'school_class':'教室','school_hall':'廊下','school_library':'図書室','ch1_village':'名前のない村','ch1_garden':'言い回しの庭','ch1_bloom':'ブルームの庭','ch1_lookout':'塔への道','ch2_settlement':'声を失った集落','ch2_archive':'古文書室','ch2_ruins':'空文の遺構','ch3_town':'書庫の町','ch3_archive':'記憶の書庫','ch3_vault':'地下保存庫','ch3_guardian':'守護者の記録室','ch3_terrace':'書庫の外廊'}
for m in maps.values():
    for p in m['portals']:
        name=short_names.get(p['target'],maps[p['target']]['name'].split('・')[-1])
        p['label']=name+'へ';p['interactionLabel']=name+'へ移動'
        if p['kind']=='path' and p['asset']=='path':p['asset']='stone_arch'
    for o in m['objects']:
        if o['id']=='mystery_stair':o['label']='地下への階段';o['interactionLabel']='地下の階段に入る'

(R/'data/maps.json').write_text(json.dumps(maps,ensure_ascii=False,indent=2))
(R/'data/game-data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
(R/'data/chapter3-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
