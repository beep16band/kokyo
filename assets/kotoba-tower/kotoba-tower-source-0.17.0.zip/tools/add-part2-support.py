"""Stage 7: canonical SCENE73–74, existing equipment and additive preparation maps."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/'data'/n).read_text())
def write(n,v):(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
d=read('game-data.json');m=read('maps.json');canon=read('part2-canonical-scenes.json');ev={};seq=d['sequences']
def flags(**v):return dict(type='flags',values=v)
def speech(s):return dict(type='dialogue',pages=[dict(speaker=p['speaker'],text=p['text'],sourceScene=s,sourceLine=p['sourceLine'],sourceDocument='part2',**({'pause':.7} if p['sourceLine']==249 else {}))for p in canon['scenes'][str(s)]['entries'] if p['speaker']])
def event(id,steps,when=None,at=None):
 seq[id]=steps+[dict(type='finish')];ev[id]=dict(pages=[],when=when or {},effects=[dict(type='sequence',id=id)])
 if at:ev[id]['at']=at
def portal(id,x,y,target,sx,sy,label,requires=None,kind='path'):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='up'),kind=kind,asset='gate_door' if kind=='door' else 'stone_arch',label=label,interactionLabel=label+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['まだ閉じている。「目的」で準備を確認しよう。'])
 return p
def clone(old,new,name):
 x=copy.deepcopy(m[old]);x.update(id=new,name=name,part2=True,chapter=11,stage7=True,npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[])
 for k in ['afterStory','epilogue','memory','school','night','stage6','coreArea']:x.pop(k,None)
 x['objects']=[o for o in x['objects'] if o['kind'] not in ['chest','sign','vista']]
 for o in x['objects']:o['id']=new+':'+o['id'];o.pop('events',None);o.pop('when',None)
 m[new]=x;return x
def npc(id,name,x,y,**kw):return {**dict(id=id,name=name,x=x,y=y,asset='merchant',dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),pages=[],events=[]),**kw}
def chest(id,x,y,loot,when=None):
 c=dict(id=id,kind='chest',x=x,y=y,asset='chest',width=32,height=32,anchorX=16,anchorY=32,footprint=[dict(x=0,y=0,w=32,h=32)],loot=loot)
 if when:c['when']=when
 return c
event('chapter11_departure',[dict(type='map',map='p2_village',spawn=dict(x=15,y=15,dir='up')),dict(type='visual',kind='purple-lightning',duration=1.6),speech(73),flags(chapter11Started=True,p2AoiSupport=True),dict(type='chapter',value=11),dict(type='dialogue',pages=['アオイのサポートが使えるようになった。戦闘ごとに5種類を各1回。戦闘中の「アオイサポート」から選べる。','ヒント、攻撃遅延、誤答への備え、回復、会心補助。選んでいる間も敵の時間は進む。解説中は停止する。','塔へ向かう前に装備を整えよう。町の右下、鍛冶屋に話しかけると倉庫へ入れる。'])],{'p2CoresReturned':True,'chapter11Started':False})
event('p2_warehouse_open',[speech(74),flags(p2WarehouseOpen=True,p2EquipmentEffects=True),dict(type='refresh-stats'),dict(type='dialogue',pages=['鍛冶屋の倉庫が開いた。持っている第2部装備にも特殊効果が働く。装備の効果は「所持品」で確認できる。','倉庫の棚には、時間を守る指輪も眠っている。町の右下の道を進めば、準備用の敵と塔の地下手前へ行ける。'])],{'p2AoiSupport':True,'p2WarehouseOpen':False})
event('p2_prepare_arrival',[dict(type='dialogue',pages=['紫の光が、塔の地下へつながっている。ここで装備とアオイのサポートを試せる。','道の東にある石門から、深層の扉の手前へ進もう。町へ戻って買い物や休息もできる。']),flags(p2PrepareHeard=True)],{'p2PrepareHeard':False})
event('p2_supply_guard_reward',[dict(type='gear',id='A019'),flags(p2SupplyGuardDefeated=True),dict(type='dialogue',pages=['守人の鎧・7を手に入れた。Lv29から装備でき、受けるダメージを5％減らす。','戦う理由は、一人で全部抱えるためではない。町に戻って装備を整え、二人でレンのもとへ向かおう。'])])
event('p2_deep_ready',[flags(chapter11Complete=True),dict(type='dialogue',pages=['塔の地下手前に着いた。扉の奥から、レンが抱えた言葉の気配がする。','アオイのサポートと倉庫の装備を使い、ここまで来た。冒険の記録を保存しよう。','深層探索は次の工程で開く。町へ戻って準備と戦闘を続けられます。'])],{'p2WarehouseOpen':True,'chapter11Complete':False})
ev['p2_deep_boundary']=dict(pages=['扉の奥の深層探索は、次の更新で開きます。現在の記録から続けられるように準備しています。'],once=False,effects=[])
ev['p2_lexicon_reward']=dict(pages=['コトバ図鑑の登録を確認しよう。全問題の半分以上を登録していたら、言霊の指輪を渡します。'],when={'p2WarehouseOpen':True,'p2LexiconRing':False},effects=[dict(type='lexicon-reward',id='C006',ratio=.5,flag='p2LexiconRing')],once=False)
v=m['p2_village'];v['entryEvents']=[x for x in v['entryEvents'] if x!='chapter11_departure'];v['objects']=[o for o in v['objects'] if o['id']!='p2-aoi-meeting'];v['objects'].append(dict(id='p2-aoi-meeting',kind='sign',x=18,y=15,asset='old_book',width=32,height=32,anchorX=16,anchorY=32,events=['chapter11_departure'],when={'p2CoresReturned':True,'chapter11Started':False},interactionLabel='アオイと救出の相談'))
v['npcs']=[n for n in v['npcs'] if n['id']!='p2-smith'];v['npcs'].append(npc('p2-smith','鍛冶屋',20,14,events=['p2_warehouse_open'],when={'p2AoiSupport':True},pages=['右下の道は、塔の地下手前へ続く。倉庫で装備を整えよう。']))
v['portals']=[p for p in v['portals'] if p['id'] not in ['p2-town-warehouse','p2-town-prepare']]+[portal('p2-town-warehouse',22,14,'p2_warehouse',7,11,'鍛冶屋の倉庫',{'p2WarehouseOpen':True},kind='door'),portal('p2-town-prepare',29,20,'p2_prepare_road',4,14,'塔への準備道',{'p2WarehouseOpen':True})]
w=clone('p2_inn','p2_warehouse','第11章・鍛冶屋の倉庫');w['safeSpawn']=dict(x=7,y=11,dir='up');w['npcs']=[npc('warehouse-smith','鍛冶屋',7,6,service='shop',serviceId='p2-warehouse-shop'),npc('warehouse-reader','倉庫の記録係',11,6,events=['p2_lexicon_reward'],pages=['コトバ図鑑の登録が全問題の半分に達したら、言霊の指輪を渡します。同じ問題を繰り返しても登録数は増えません。'])];w['portals']=[portal('p2-warehouse-back',7,12,'p2_village',22,15,'町へ戻る',kind='door')];w['objects'].append(chest('p2-warehouse-hidden-ring',3,3,dict(gear=['C005'])))
r=clone('p2_letter_road','p2_prepare_road','第11章・塔への準備道');r.update(safeSpawn=dict(x=4,y=14,dir='right'),entryEvents=['p2_prepare_arrival']);r['portals']=[portal('p2-prepare-back',3,14,'p2_village',28,20,'最初の町'),portal('p2-prepare-tower',26,14,'p2_deep_ante',12,15,'塔の地下手前')]
pos=[(7,8),(11,8),(15,8),(19,8),(23,8),(9,10),(13,10),(17,10),(21,10),(7,12),(11,12),(17,12)]
ids=['P2_PREP_BEAST','P2_PREP_FLAME','P2_PREP_THUNDER','P2_PREP_GUARD'];r['enemies']=[dict(id='p2-preparation-'+str(i),enemy=ids[i%4],x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.55,chaseRadius=2,leash=3))for i,(x,y) in enumerate(pos)]
r['enemies'].append(dict(id='p2-supply-guard',enemy='P2_SUPPLY_GUARD',x=23,y=5,respawn=False,afterEvent='p2_supply_guard_reward'))
r['objects'].append(chest('p2-prepare-supply',24,5,dict(items={'I001':3},gold=1200),{'p2SupplyGuardDefeated':True}))
a=clone('ch6_king','p2_deep_ante','第11章・塔の地下手前');a.update(safeSpawn=dict(x=12,y=15,dir='up'),entryEvents=['p2_deep_ready']);a['portals']=[portal('p2-deep-ante-back',12,17,'p2_prepare_road',25,14,'準備道へ戻る',kind='door')];a['objects'].append(dict(id='p2-deep-wait-door',kind='sign',x=12,y=3,asset='gate_door',width=32,height=32,anchorX=16,anchorY=32,events=['p2_deep_boundary'],interactionLabel='深層の扉'))
d['aoiSupport']={k:dict(label=label,description=desc)for k,label,desc in [('hint','ヒント','今の問題の考え方'),('delay','攻撃遅延','ATTACKゲージを20％分戻す'),('shield','誤答への備え','次の誤答ダメージを1回防ぐ'),('heal','回復','最大HPの25％回復'),('critical','会心補助','次の正解ダメージ1.5倍')]}
cats=d['enemies']['P2_MEMORIA']['questionCategories']
for id,name,asset,hp,atk,de,sec,gold,exp,family,element in [('P2_PREP_BEAST','抱え込みの文字獣','context_beast',1200,225,133,21,900,348,'beast','physical'),('P2_PREP_FLAME','紫炎の文字片','archive_wisp',1050,222,125,20,950,348,'spirit','fire'),('P2_PREP_THUNDER','紫電の文字翼','bat',1020,217,115,17,850,348,'beast','lightning'),('P2_PREP_GUARD','残された倉庫兵','archive_guardian',1380,235,160,23,1000,348,'guard','physical'),('P2_SUPPLY_GUARD','古い物資の守衛','archive_guardian',4600,244,159,23,2200,1200,'guard','lightning')]:
 d['enemies'][id]=dict(id=id,name=name,asset=asset,hp=hp,attack=atk,defense=de,guard=de,attackSeconds=sec,gold=gold,exp=exp,family=family,element=element,questionCategories=cats,role='任意の強敵' if id=='P2_SUPPLY_GUARD' else '通常敵')
for enemy in d['enemies'].values():
 if enemy['id'].startswith('P2_') and enemy.get('asset') in ['context_beast','bat','hound']:enemy.setdefault('family','beast')
plan=read('part2-equipment-plan.json')
effects={'W027':dict(critical=.05),'A016':dict(maxHPRatio=.15),'W028':dict(correctDamage=.08),'A017':dict(wrongReduction=.10),'W030':dict(beastDamage=.12),'A018':dict(elementReduction=.15,elements=['fire','lightning']),'W013':dict(openingDamage=.25,openingSeconds=10),'A019':dict(damageReduction=.05),'C005':dict(gaugeSlow=.15),'C006':dict(correctDamage=.15,expBonus=.10),'C007':dict(streakStep=.05,streakMax=.25),'C011':dict(expBonus=.10),'C012':dict(gaugeSlow=.07),'C014':dict(newWordExp=.20)}
for g in plan['tiers']:
 if g['chapter']<=11:
  g.update(implemented=True,effectImplemented=True,note='Special effects unlock at SCENE74. Shared Lv and existing saves are preserved.')
  if g['chapter']==11:
   g['placement']='p2-warehouse-shop' if g['id']=='W013' else 'p2-warehouse-shop / p2-supply-guard'
   d['equipment'][g['id']].update(attack=g['attack'],defense=g['defense'],HP=g['HP'],requiredLevel=g['requiredLevel'],**{'攻撃':g['attack'],'防御':g['defense'],'買値':g['price']})
  d['equipment'][g['id']]['特殊効果']=g['specialEffect']
for id,effect in effects.items():d['equipment'][id]['effects']=effect
plan['activation']='First eight tiers and six accessories active through Stage 7; effects unlock at SCENE74. Future Lv32+ equipment remains reserved.'
plan['accessoryPlacements']={'C005':'hidden warehouse chest','C006':'50% lexicon reward','C007':'Lv30 warehouse shop','C011':'warehouse shop','C012':'warehouse shop','C014':'warehouse shop','C016':'reserved Lv34'}
d['shops']['p2-warehouse-shop']=dict(name='鍛冶屋の倉庫',requires={'p2WarehouseOpen':True},products=[dict(id='I001',type='item',price=55)]+[dict(id=g['id'],type='gear',price=g['price'])for g in plan['tiers'] if g['implemented']]+[dict(id=id,type='gear',price=d['equipment'][id]['買値'])for id in ['C007','C011','C012','C014']])
d['objectives']=[o for o in d['objectives'] if not o.get('stage7')]
d['objectives'][:0]=[dict(part2=True,stage7=True,when=w,text=t)for w,t in [({'chapter11Complete':True},'アオイのサポートと装備を準備した。深層探索は次の工程。ここで保存でき、町と準備道へ戻れる。'),({'p2WarehouseOpen':True,'chapter11Complete':False},'町の右下の石門→準備道の東の石門から、塔の地下手前へ。倉庫と宿屋で準備できる。'),({'p2AoiSupport':True,'p2WarehouseOpen':False},'町の右下にいる鍛冶屋へ。正面から話しかけ、古い倉庫を開けてもらおう。')]]
for ch in d['chapters']:
 if ch['id']==11:ch.update(implemented=True,entry=dict(map='p2_village',spawn=dict(x=15,y=15,dir='up')))
cont=read('continuation.json');cont.update(version='0.17.0',implementedScenes=list(range(65,75)));cont['chapters'][2].update(implemented=True,note='Optional preparation road: 12 normal battles and one supply guardian; no forced Lv adjustment.')
canon['activation']='SCENE61–74 implemented; SCENE75–92 reserved.'
for name,value in [('game-data.json',d),('maps.json',m),('chapter11-events.json',ev),('continuation.json',cont),('part2-equipment-plan.json',plan),('part2-canonical-scenes.json',canon)]:write(name,value)
print('Stage 7: support, warehouse, preparation road, tower antechamber.')
