const fs=require('fs'),assert=require('assert'),{Engine}=require('../src/core.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/../data/game-data.json'));const results=[];
const check=(name,f)=>{try{f();results.push({name,ok:true})}catch(e){results.push({name,ok:false,error:e.message})}};
function finish(e){let n=1000;while(['dialog','cinematic'].includes(e.mode)&&n--){if(e.mode==='cinematic')e.tick(.1);else (e.mode==='dialog'&&e.tick(1),e.advance())}assert(n>0)}
function departure(){const e=new Engine(data,{enemyAI:false});e.start('prologue');finish(e);e.interact();finish(e);e.interact();while(e.mode==='dialog')(e.mode==='dialog'&&e.tick(1),e.advance());return e}
check('学校の4人と同行レンが同じ32×32ぴぽやシリーズ',()=>{
 assert.equal(data.maps.school_class.npcs[0].asset,'aoi_pipoya_student');assert.equal(data.maps.school_hall.npcs[0].asset,'friend_pipoya_student');
 assert.equal(data.maps.school_library.npcs[0].asset,'librarian_pipoya');assert.equal(data.maps.school_class.npcs[1].asset,'teacher_pipoya');
 assert.equal(data.maps.ch1_inn.npcs.find(n=>n.name==='レン').asset,'ren_pipoya_student');
});
check('レンの初期倒れ姿と立ち姿は同じキャラから作成',()=>{const n=data.maps.ch1_underground.npcs.find(n=>n.id==='ren_lost');assert.equal(n.asset,'ren_pipoya_prone');assert.equal(n.awakeAsset,'ren_pipoya_student');assert.equal(n.standDuring.page,4)});
check('会話後にアオイは消えず、机を避けて扉へ歩く',()=>{
 const e=departure(),n=e.map.npcs.find(n=>n.id==='aoi');assert.equal(e.mode,'cinematic');assert(e.visible(n));assert(!e.state.flags.aoiLeft);
 const p=e.npcPosition(n);e.tick(.09);const middle=e.npcPosition(n);assert(middle.x>p.x&&middle.x<p.x+32);assert.equal(middle.dir,'right');
 assert(middle.walking);assert(!e.move('left'));assert.throws(()=>e.snapshot());(e.mode==='dialog'&&e.tick(1),e.advance());assert.equal(e.mode,'cinematic');
 const path=e.cinematic.route;assert.deepEqual(path.at(-1),[21,12]);for(const [x,y]of path)assert(e.canStand(e.map.id,x,y));
 e.tick(3);assert(!e.visible(n));assert(e.state.flags.aoiLeft);assert.equal(e.dialog.eventId,'aoi_after_exit');finish(e);
 assert.equal(e.state.flags.phase,'anomaly');e.restore(e.snapshot());assert(!e.runEvent('aoi_departure'));assert(!e.cinematic);
});
check('庭の全6撃破順で台詞が変化し、最後に石門へ案内する',()=>{
 const orders=[[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]],ids=['garden_west','garden_east','garden_north'];
 for(const order of orders){const e=new Engine(data,{enemyAI:false});e.state.map='ch1_garden';const texts=[];
  for(const [index,id]of order.entries()){assert(e.runEvent(ids[id]));const text=e.dialog.pages.join('');texts.push(text);assert((index===0?/(残りの二つ|ほかの道|まだ欠けている)/.test(text):text.includes(index===1?'あと一つ':'北東の石門')));finish(e)}
  assert.equal(new Set(texts).size,3);assert(e.state.flags.gardenWest&&e.state.flags.gardenEast&&e.state.flags.gardenNorth);
 }
});
check('全出入口に行き先があり、近くで入口を認識できる',()=>{
 for(const m of Object.values(data.maps))for(const p of m.portals){assert(p.label&&p.interactionLabel);const e=new Engine(data,{enemyAI:false});e.state.map=m.id;Object.assign(e.state.flags,p.when||{});e.state.x=p.x;e.state.y=p.y;assert(e.nearbyExit());assert(data.maps[p.target])}
});
fs.writeFileSync(__dirname+'/../docs/character-action-test-results.json',JSON.stringify(results,null,2));for(const r of results)console.log((r.ok?'PASS ':'FAIL ')+r.name+(r.error?' '+r.error:''));process.exit(results.some(r=>!r.ok)?1:0);
