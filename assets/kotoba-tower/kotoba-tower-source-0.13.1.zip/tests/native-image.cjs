/* The installed native decoder rejects this generated PNG when passed as a Buffer
 * or data URL, but accepts exactly the same bytes through its file-path loader.
 * Materialize test-only bytes; browser production still uses native Image/data URLs. */
const fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto'),canvas=require('@napi-rs/canvas');
async function loadImage(source){if(!Buffer.isBuffer(source))return canvas.loadImage(source);const cache=path.join(os.tmpdir(),'kotoba-native-image-tests');fs.mkdirSync(cache,{recursive:true});const filename=path.join(cache,crypto.createHash('sha256').update(source).digest('hex')+'.png');if(!fs.existsSync(filename))fs.writeFileSync(filename,source);return canvas.loadImage(filename)}
module.exports={loadImage};
