const fs=require('fs'),assert=require('assert'),crypto=require('crypto'),{Engine}=require('../src/core.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/../data/game-data.json'));
const review=data.questionReview,e=new Engine(data,{enemyAI:false}),pool=e.questionPool();
const pairs=new Set();for(const p of review.pairs){pairs.add([p.category,p.word,p.target].join('|'));pairs.add([p.category,p.target,p.word].join('|'));}
const relations=pool.filter(q=>['類義語','対義語'].includes(q.category));
assert.equal(pool.length,1267);assert.equal(relations.length,249);
assert.equal(relations.filter(q=>q.category==='類義語').length,113);
assert.equal(relations.filter(q=>q.category==='対義語').length,136);
for(const q of relations){assert(/^[一-龯]{2}$/.test(q.word),q.id);assert(q.choices.every(w=>/^[一-龯]{2}$/.test(w)),q.id);assert.equal(q.choices[q.answer],q.correctAnswer);assert(pairs.has([q.category,q.word,q.correctAnswer].join('|')),q.id);assert(q.reviewSource.verified);assert.equal(q.reviewSource.pdfPage,4);assert.equal(new Set(q.choices).size,4);for(let i=0;i<4;i++)if(i!==q.answer)assert(!pairs.has([q.category,q.word,q.choices[i]].join('|')),q.id);}
assert.equal(Object.keys(review.excluded).length,76);
assert(!relations.some(q=>q.word==='赤'||q.word==='白'));
assert(relations.filter(q=>q.word==='実直').every(q=>q.correctAnswer==='律儀'));
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(__dirname+'/../data/questions.json')).digest('hex'),'7e98f5e1b5d7b4b0702510b259f4451b488c66164b3019820261eb400132f9bf');
for(const enemy of Object.values(data.enemies)){const eligible=e.eligibleQuestions(enemy);assert(eligible.length);assert(eligible.every(q=>!review.excluded[q.id]));}
console.log('PASS スキャン236–237頁の組み合わせ・二字熟語249問・対象外76問・原本保存・全敵出題候補');
e.state.name='テスト太郎';e.say('主人公',['主人公の名前']);assert.equal(e.dialog.speakers[0],'テスト太郎');assert.equal(e.dialog.pages[0],'テスト太郎の名前');e.dialog=null;e.mode='explore';
e.say('NPC',[{speaker:'主人公・心の声',text:'主人公'}]);assert.equal(e.dialog.speakers[0],'テスト太郎（心の声）');e.dialog=null;e.mode='explore';
const enemy={...data.maps.yard.enemies[0]};const strong={...data,enemies:{...data.enemies,[enemy.enemy]:{...data.enemies[enemy.enemy],hp:10000}}};const b=new Engine(strong,{enemyAI:false});b.startBattle(enemy);b.tick(2);const gauge=b.battle.attack;b.answer(b.battle.correct);const hp=b.battle.hp;assert.equal(b.battle.attack,gauge);b.nextQuestion();assert.equal(b.battle.attack,gauge);b.answer((b.battle.correct+1)%4);assert.equal(b.battle.hp,hp);assert.equal(b.battle.hitAge,10);assert.equal(b.battle.enemyDamageText,'');assert.equal(b.displays.enemyHP,hp);b.tick(100);assert.equal(b.battle.attack,gauge);
console.log('PASS 主人公名・不正解の敵HP不変／残った攻撃表示の消去・正解残量保持・解説中停止');
const html=fs.readFileSync(__dirname+'/../kotoba_tower_stage6.html','utf8');assert(!/firebase|firestore|KotobaRanking|rankingSubmit|rankSubmit/.test(html));
console.log('PASS 単体HTMLにFirebase通信・ランキング実行コードなし');
