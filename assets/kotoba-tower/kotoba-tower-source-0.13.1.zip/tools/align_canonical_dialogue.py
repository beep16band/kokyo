"""Keep canonical dialogue verbatim; retain quest flags, battles and practical navigation."""
from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
lines=(R/'reference/latest-dialogue-canon.txt').read_text().splitlines()
scenes={};current=None
for number,line in enumerate(lines,1):
    match=re.match(r'SCENE (\d+)\s',line)
    if match:
        current=int(match[1]);scenes[current]=[];continue
    if line.startswith('実装用付録'):current=None
    if current is None:continue
    if line.startswith(('【場面の役割】','▶','第')) or line=='任意調査・追加反応':continue
    if line.startswith('【演出】'):
        scenes[current].append(dict(speaker='',text=line.removeprefix('【演出】'),sourceScene=current,sourceLine=number))
    elif (match:=re.match(r'^(.+?)「(.*)」$',line)):
        text=match[2];pause=.8 if text in ['俺には、昨日がないから。','……そっか。','……そうだな。','……会いたい。'] else .5 if text.startswith('……') else 0
        scenes[current].append(dict(speaker=match[1],text=text,sourceScene=current,sourceLine=number,pause=pause))
def split(scene,needle):
    values=scenes[scene];i=next(i for i,p in enumerate(values) if needle in p['text']);return values[:i],values[i:]
def assign(data,id,pages):data[id]['pages']=pages
p=json.loads((R/'data/prologue-events.json').read_text())
assign(p,'prologue_intro',scenes[1][:1]);assign(p,'borrow_notebook',scenes[1][1:])
before,after=split(2,'戸が閉まる');assign(p,'aoi_departure',before);assign(p,'aoi_after_exit',after)
v=scenes[3]
assign(p,'poster_missing',v[:2]);assign(p,'forgot_word',v[2:6])
assign(p,'books_missing',v[6:10]);assign(p,'impossible_stairs',v[10:])
(R/'data/prologue-events.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))

p=json.loads((R/'data/chapter1-events.json').read_text())
assign(p,'underground_intro',scenes[4][:1]);v=scenes[4];i=next(i for i,x in enumerate(v) if '欠けた碑文' in x['text']);assign(p,'meet_ren',v[1:i]);assign(p,'broken_inscription',v[i:])
before,after=split(5,'戦闘後');assign(p,'bakro_appears',before);assign(p,'bakro_freed',after)
assign(p,'stone_gate',scenes[6]);assign(p,'notebook_survives',scenes[7])
before,after=split(8,'老夫婦の家');assign(p,'village_arrival',before)
i=next(i for i,x in enumerate(after) if '塔に近い古い石碑' in x['text']);assign(p,'old_couple',after[:i]);assign(p,'village_stone',after[i:])
assign(p,'former_teacher',scenes[9]);assign(p,'inn_night',scenes[10]+scenes[11])
before,after=split(12,'問題を解くたび');assign(p,'garden_intro',before)
# Supplemental restoration notices differ by location/order. Canonical tower dialogue follows the last restoration.
ids=['garden_west','garden_east','garden_north'];flags=['gardenWest','gardenEast','gardenNorth']
flavors=['西の通路が開いた。残りの二つも取り戻そう。','橋の形が戻った。ほかの道も確かめよう。','像が元の姿に戻った。まだ欠けている言葉を探そう。']
for i,id in enumerate(ids):
    other=[f for j,f in enumerate(flags) if j!=i];pages=[p[id]['pages'][0]]
    for a,b in [(False,False),(True,False),(False,True),(True,True)]:
        when={other[0]:a,other[1]:b};count=int(a)+int(b)
        text=flavors[i] if count==0 else '二つ目の道も戻った。あと一つだ。' if count==1 else '三つとも戻った。北東の石門が開いた。'
        pages.append(dict(speaker='主人公',text=text,when=when))
        if count==2:pages.extend([{**x,'when':when} for x in after])
    assign(p,id,pages)
before,after=split(13,'戦闘後');cut=next(i for i,x in enumerate(before) if x['speaker']=='レン')
assign(p,'bloom_intro',before[:cut]);assign(p,'bloom_challenge',before[cut:]);assign(p,'bloom_answer',after)
assign(p,'chapter1_clear',scenes[14]);(R/'data/chapter1-events.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))

p=json.loads((R/'data/chapter2-events.json').read_text());v=scenes[15]
cut=next(i for i,x in enumerate(v) if '文脈問題を解いて' in x['text']);end=next(i for i,x in enumerate(v) if '古文書を発見' in x['text'])
assign(p,'ch2_arrival',v[:cut]);assign(p,'ancient_idea',v[end:]);assign(p,'memory_A_again',scenes[16])
before,after=split(17,'試すが何も');assign(p,'notebook_margin',before);assign(p,'ordinary_paper',after)
assign(p,'family_reply',scenes[18]);before,after=split(19,'戦闘後');assign(p,'hollow_beast_appears',before);assign(p,'hollow_beast_freed',after)
assign(p,'chapter2_clear',[dict(speaker='',text='書庫へ続く門へ到着した。\n第2章　声にならない文　CLEAR')])
(R/'data/chapter2-events.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
d=json.loads((R/'data/game-data.json').read_text());q=d['interactions']['help_family'];q['choices'][q['answer']]='心配してる';q['successPages']=v[cut+1:end];q['meaning']='心配してる';q['explanation']='前後の話と、相手に届けたい気持ちを考える。';q['example']='心配してる。';q['prompt']='出かけた娘が、まだ帰ってこない。「あの子に、私が……って」と伝えたい。後ろには「無事に帰ってきてね」の言葉が残っている。';p['help_family']['pages'][0]['text']='出かけた娘が、まだ帰ってこない。「あの子に、私が……って」と伝えたいのに。「無事に帰ってきてね」までは言えるんです。';(R/'data/chapter2-events.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
# The result reads canonical speaker objects instead of flattening them.
(R/'data/game-data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))

p=json.loads((R/'data/chapter3-events.json').read_text());before,after=split(20,'別の住民')
assign(p,'ch3_diary',before);assign(p,'ch3_blank',after)
assign(p,'ch3_ren_ticket',scenes[21]);assign(p,'ch3_notebook',scenes[22]);assign(p,'ch3_storage_compare',scenes[23])
before,after=split(24,'戦闘後');assign(p,'ch3_guardian_appears',before);assign(p,'ch3_guardian_freed',after);assign(p,'chapter3_clear',scenes[25])
(R/'data/chapter3-events.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
m=json.loads((R/'data/maps.json').read_text());m['ch1_underground']['npcs'][0]['standDuring']['page']=4;m['ch3_town']['npcs'][0]['name']='司書'
(R/'data/maps.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
(R/'data/canonical-scenes.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
print('Canonical scenes extracted:',len(scenes),'through scene25 aligned')
