"""Original 32px pixel props, no edits to downloaded assets. Optional Pillow tool."""
from PIL import Image,ImageDraw
from pathlib import Path
R=Path(__file__).resolve().parents[1]/'assets'
im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im)
d.rectangle((2,17,29,21),fill='#3c2530');d.rectangle((3,16,28,18),fill='#9b7559');d.rectangle((5,22,8,31),fill='#614738');d.rectangle((23,22,26,31),fill='#614738')
d.rectangle((11,4,21,14),fill='#badbd5');d.rectangle((12,5,20,13),fill='#253444');d.rectangle((13,8,19,12),fill='#5d9ba8');d.line((11,4,21,4),fill='#f4ecd1');d.line((12,5,12,12),fill='#d7e9df');d.line((13,13,20,13),fill='#bedacb');d.point((18,6),fill='#f4ecd1')
im.save(R/'afterstory_cup_table.png')
im=Image.new('RGBA',(64,64));d=ImageDraw.Draw(im)
d.rectangle((5,3,58,61),fill='#29202c');d.rectangle((8,6,55,56),fill='#6c493d');d.rectangle((11,9,52,52),fill='#101e35')
# A night street behind the glass; amber town lights remain warm.
for x,y in [(14,33),(27,38),(39,31)]:
 d.polygon([(x-3,y),(x+5,y-6),(x+13,y)],fill='#334155');d.rectangle((x,y,x+10,49),fill='#273344');d.rectangle((x+3,y+3,x+6,y+7),fill='#dfb878')
d.rectangle((30,8,33,54),fill='#845c49');d.rectangle((10,29,53,32),fill='#845c49');d.rectangle((3,55,60,59),fill='#ac7d58');d.line((11,10,28,10),fill='#afbdc1');d.point((47,15),fill='#e6dfca')
im.save(R/'afterstory_window.png')
print('Original cup/table 32×32, night window 64×64; integer pixel drawing.')
