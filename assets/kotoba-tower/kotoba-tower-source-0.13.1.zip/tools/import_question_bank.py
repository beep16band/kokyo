"""Import the confirmed workbook without rewriting its educational contents.

Requires openpyxl only when reimporting. The offline game/build needs no package.
"""
from pathlib import Path
import collections, hashlib, json, re
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'reference/高校入試対策_国語ゲーム問題バンク.xlsx'

def convert():
    workbook = openpyxl.load_workbook(SOURCE, data_only=True)
    masters = list(workbook['語句マスター'].values)[1:]
    questions = []
    for row_number, row in enumerate(list(workbook['問題バンク'].values)[1:], 2):
        if not row[0]:
            continue
        raw = dict(zip(next(workbook['問題バンク'].values), row))
        choices = list(row[6:10])
        answer = 'ABCD'.index(row[10])
        assert choices[answer] == row[11], (row_number, '正答不一致')
        assert all(isinstance(value, str) and value for value in choices)
        quoted = re.search('「([^」]+)」', row[5])
        term = quoted[1].split('（')[0] if quoted else ''
        if row[4] == '適語選択':
            term = row[11]
        master = next((m for m in masters if m[0] == row[1] and m[1] == term), None)
        assert master is not None, (row[0], term, '語句マスターなし')
        questions.append(dict(
            id=row[0], category=row[1], subcategory=row[2], difficulty=row[3],
            format=row[4], prompt=row[5], choices=choices, answer=answer,
            correctAnswer=row[11], explanation=row[12], hints=list(row[13:15]),
            recommendedExp=row[15], word=master[1], meaning=master[2],
            example=master[3] or '',
            exampleLabel='由来' if row[1] == '故事成語' else '用例',
            source=SOURCE.name, sourceSheet='問題バンク', sourceRow=row_number,
            sourceRecord=raw, preserveChoiceOrder=True,
        ))
    assert len(questions) == 398
    assert len({q['id'] for q in questions}) == len(questions)
    return questions

if __name__ == '__main__':
    questions = convert()
    (ROOT / 'data/questions.json').write_text(json.dumps(questions, ensure_ascii=False, indent=2))
    manifest = dict(source=SOURCE.name, sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                    count=len(questions), categories=dict(collections.Counter(q['category'] for q in questions)),
                    textUnchanged=True, choiceOrderUnchanged=True)
    (ROOT / 'docs/question-bank-import.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(json.dumps(manifest, ensure_ascii=False))
