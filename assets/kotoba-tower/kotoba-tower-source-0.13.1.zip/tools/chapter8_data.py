"""Part 1 finale: SCENE47–60; stable existing data, automatic dialogue-led ending."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
d=read('game-data.json');maps=read('maps.json');sc=read('canonical-scenes.json');events={};sequences={}
def text(s,t):return {'speaker':s,'text':t}
def pages(n):
 out=[copy.deepcopy(p) for p in sc[str(n)] if p['speaker']]
 for p in out:
  if p['text'] in ['ごめん。どこかで会った？','明日にする？','しない。']:p['pause']=.9
 return out
def event(id,p,fx=None,when=None,once=True):events[id]=dict(id=id,pages=p,effects=fx or [],when=when or {},once=once)
def flags(**v):return dict(type='flags',values=v)
def travel(mid,x,y,dir='up'):return dict(type='travel',map=mid,spawn=dict(x=x,y=y,dir=dir))
def room(id,name,w=26,h=20,school=False):
 m=dict(id=id,name=name,chapter=8,width=w,height=h,tiles=[('school_hall_floor'if school else 'floor')]*(w*h),collision=[int(x==0 or y==0 or x==w-1 or y==h-1)for y in range(h)for x in range(w)],wallAsset='school_wall'if school else 'wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=w//2,y=h-3,dir='up'));maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,solid=False,when=None):
 o=dict(id=id,kind='decor',x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,footprint=[dict(x=0,y=max(0,h-32),w=w,h=min(32,h))]if solid else [])
 if when:o['when']=when
 m['objects'].append(o);return o
def npc(m,id,name,x,y,asset):m['npcs'].append(dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',footprint=[],pages=[]))
def portal(m,id,x,y,target,sx,sy,kind='stairs',requires=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='down'if 'back'in id else'up'),kind=kind,asset='stairs_down'if'back'in id else'stairs_up'if kind=='stairs'else'stone_arch',label=maps[target]['name'],interactionLabel=maps[target]['name']+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['北の階段へ向かおう。「目的」で進む場所を確認できます。'])
 m['portals'].append(p);return p
st=room('ch8_ascent','第8章・最後の階段',26,32);st['entryEvents']=['ch8_entry']
r=room('ch8_refuge','第8章・最後の休憩室',20,16)
f=room('ch8_final','第8章・最終管理層',26,22);f['safeSpawn']=dict(x=12,y=17,dir='up')
for y in [10,15,20,25]:
 for x in [5,20]:obj(st,f'ch8-pillar-{x}-{y}',x,y,'stone_tablet_v2',64,64,True)
obj(st,'ch8-guide',16,28,'old_book',solid=True).update(events=['ch8_guide'],interactionRect=dict(x=16*32,y=28*32,w=32,h=32),interactionLabel='最終階の案内を読む')
obj(r,'ch8-rest-record',10,6,'old_book');npc(r,'ch8-inn','記録を守る係',4,6,'elderwoman');r['npcs'][-1].update(service='inn',serviceId='final-refuge');npc(r,'ch8-shop','継承者の道具係',14,6,'merchant');r['npcs'][-1].update(service='shop',serviceId='final-shop')
for x in [4,20]:
 for y in [7,12]:obj(f,f'ch8-archive-{x}-{y}',x,y,'old_book',64,64,True)
obj(f,'ch8-logos-body',12,6,'logos_final',128,128,False,{'ch8LogosDefeated':False})
obj(f,'ch8-return-light',16,9,'stone_arch',64,64,False,{'ch8TowerReleased':True})
npc(f,'ren','レン',11,15,'ren_pipoya_student');f['npcs'][-1]['when']={'ch8EndingStarted':True}
old=maps['ch7_final_door'];old['objects']=[o for o in old['objects']if o['id']!='chapter8_route'];old['portals']=[p for p in old['portals']if p['id']!='gate-chapter8'];portal(old,'gate-chapter8',12,4,'ch8_ascent',12,28,'path',{'chapter7Complete':True})
portal(st,'ch8-back-ch7',12,29,'ch7_final_door',12,5,'path');portal(st,'ch8-refuge-door',4,28,'ch8_refuge',9,12,'path');portal(r,'ch8-refuge-back',9,13,'ch8_ascent',4,29,'path')
p=portal(st,'ch8-last-stair',12,4,'ch8_final',12,17);p['entryEvent']='ch8_ascent_scene'
portal(f,'ch8-final-back',12,18,'ch8_ascent',12,5)
f['enemies']=[dict(id='ch8-logos',enemy='S8_LOGOS',x=12,y=10,introEvent='ch8_logos_appears',afterEvent='ch8_logos_freed',phaseSequence='ch8_phase')]
# Old saves remain valid; ordinary optional battles permit levels 16–18 without waiting for respawn.
for i,(x,y) in enumerate([(8,26),(18,26),(8,23),(18,23),(8,20),(18,20),(8,17),(18,17),(8,14),(18,14),(8,11),(18,11)]):st['enemies'].append(dict(id=f'ch8-fragment-{i}',enemy='S8_FAST'if i%3==0 else'S8_FRAGMENT',x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',chaseRadius=3,leash=3,stepSeconds=.45)))
# Finale maps are independent copies: opening maps and their collision/events are preserved.
for key,source in [('ep_library','school_library'),('ep_hall','school_hall'),('ep_class','school_class')]:
 m=copy.deepcopy(maps[source]);m.update(id=key,name={'ep_library':'冬の学校・図書室','ep_hall':'冬の学校・廊下','ep_class':'冬の学校・教室'}[key],chapter=8,epilogue=True,memory=True,school=True,portals=[],enemies=[],npcs=[],triggers=[],entryEvents=[],safeSpawn=dict(x=12,y=12,dir='down'))
 if key=='ep_hall':m['safeSpawn']=dict(x=12,y=7,dir='left')
 m['objects']=[{k:v for k,v in o.items() if k not in ['events','when','interactionLabel','interactionRect']} for o in m['objects'] if o['id']!='mystery_stair'];maps[key]=m
obj(maps['ep_library'],'returned-clock',15,2,'school_clock_final')
obj(maps['ep_class'],'class-clock',20,2,'school_clock_final')
npc(maps['ep_class'],'aoi','アオイ',8,9,'aoi_pipoya_student')
shoe=room('ep_entrance','冬の学校・昇降口',24,16,True);shoe.update(epilogue=True,memory=True,school=True,safeSpawn=dict(x=10,y=11,dir='right'))
for x in [3,5,7,15,17,19]:
 for y in [3,5]:obj(shoe,f'shoe-{x}-{y}',x,y,'school_lockers',solid=True)
obj(shoe,'school-exit',12,14,'school_door',32,64);obj(shoe,'school-notice',20,9,'school_poster',64,64,True);npc(shoe,'aoi','アオイ',14,10,'aoi_pipoya_student')
obj(shoe,'returned-note',14,10,'notebook_final',32,32,False,{'ch8NoteReturned':True})
# Dialogue / action sequences: all movement after victory is automatic.
def dialog(n,subset=None):return dict(type='dialogue',pages=subset if subset is not None else pages(n))
def move(actor,x,y):return dict(type='move',actor=actor,to=[x,y],seconds=.13)
def mapstep(mid,x,y,dir='up'):return dict(type='map',map=mid,spawn=dict(x=x,y=y,dir=dir))
def cast(**v):return dict(type='actors',values=v)
def visual(kind,duration=1,**v):return dict(type='visual',kind=kind,duration=duration,**v)
def face(actor,dir):return dict(type='face',actor=actor,dir=dir)
sequences['ch8_ascent']=[flags(chapter8Started=True),cast(hero=dict(x=12,y=5,dir='up')),dialog(47,pages(47)[:3]),move('hero',12,3),dialog(47,pages(47)[3:]),visual('fade',.8),mapstep('ch8_final',12,17),flags(ch8AscentKnown=True)]
sequences['ch8_phase']=[dialog(49),visual('phase',1.2)]
sequences['ch8_ending']=[flags(ch8EndingStarted=True,renSeparated=True),cast(hero=dict(x=12,y=10,dir='up'),ren=dict(x=11,y=11,dir='up')),visual('logos-break',4.2),flags(ch8LogosDefeated=True),dialog(50),visual('release',5.0),flags(ch8TowerReleased=True),face('hero','left'),face('ren','right'),dialog(51),move('hero',16,9),visual('fade',1.2),mapstep('ep_library',16,6,'down'),dialog(52,pages(52)[:2]),move('hero',16,12),visual('fade',.7),mapstep('ep_hall',20,7,'left'),move('hero',12,7),mapstep('ep_class',10,12,'up'),move('hero',10,9),dialog(52,pages(52)[2:]),move('hero',18,9),visual('fade',.7),mapstep('ep_entrance',8,10,'right'),cast(aoi=dict(x=14,y=10,dir='down')),move('hero',12,10),face('aoi','left'),dialog(53),visual('notebook',1.5),flags(ch8NoteReturned=True),dialog(54)]
for n in [55,56,57,58]:sequences['ch8_ending'] += [visual('memory',.8,scene=n),dialog(n)]
sequences['ch8_ending'] += [dialog(59),move('hero',13,10),visual('fade',1.5),mapstep('ep_class',10,9,'left'),cast(aoi=dict(x=8,y=9,dir='right')),dialog(60,pages(60)[:5]),visual('fade',1),mapstep('ep_entrance',12,11,'right'),cast(aoi=dict(x=14,y=11,dir='left')),dialog(60,pages(60)[5:]),move('aoi',14,13),move('hero',12,13),visual('end',3),flags(chapter8Complete=True,part1Complete=True),dict(type='finish')]
event('chapter8_departure',[text('','第8章　最終階 ― 言葉とは何だ ―'),text('レン','最後の階段だ。西の休憩室で準備してから、北の最終階へ進もう。')],[flags(chapter8Started=True),dict(type='chapter',value=8),travel('ch8_ascent',12,28)],{'chapter7Complete':True})
event('ch8_entry',[text('レン','北へ上がるとロゴスの管理層だ。西の入口には最後の休憩室がある。')],[flags(chapter8Started=True),dict(type='chapter',value=8)])
event('ch8_guide',[text('記録','北：最終管理層。南西：休憩室・道具係。'),text('レン','武器と防具を見直そう。やくそうも持っていけ。帰り道は閉じていない。')],once=False)
event('ch8_ascent_scene',[],[dict(type='sequence',id='ch8_ascent')])
event('ch8_logos_appears',pages(48),[dict(type='battle',encounter='ch8-logos')])
event('ch8_logos_freed',[],[dict(type='sequence',id='ch8_ending')])
d['enemies']['S8_LOGOS']=dict(id='S8_LOGOS',name='ロゴス',hp=2650,attack=70,guard=34,defense=34,attackSeconds=20,exp=620,gold=1400,asset='logos_final',role='章ボス',enrageAt=.5,enrageAttack=1.06,enrageSpeed=.90,questionCategories=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語','文法'])
for id,name,hp,atk,df,sec,xp,g in [('S8_FRAGMENT','保存領域の影',600,70,30,14,115,340),('S8_FAST','再生する文字片',430,66,18,10,105,320)]:d['enemies'][id]=dict(id=id,name=name,hp=hp,attack=atk,guard=df,defense=df,attackSeconds=sec,exp=xp,gold=g,asset='archive_wisp',questionCategories=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語'])
d['shops']['final-shop']=dict(name='最後の道具係',products=[dict(id='I001',type='item',price=55),dict(id='W010',type='gear',price=2800),dict(id='A008',type='gear',price=2400),dict(id='W009',type='gear',price=2050),dict(id='A007',type='gear',price=1750)])
d['inns']['final-refuge']=dict(name='最後の休憩室',price=45)
d['chapters'][8]=dict(id=8,implemented=True,name='最終階 ― 言葉とは何だ ―',scenes=list(range(47,61)),entry=dict(map='ch8_ascent',spawn=dict(x=12,y=28,dir='up')))
for o in d['objectives']:
 if o.get('when',{}).get('chapter7Complete'):o['when']['chapter8Started']=False
objs=[({'chapter8Started':True,'ch8AscentKnown':False},'北の階段から最終管理層へ。西の休憩室で装備・回復を準備できる。'),({'ch8AscentKnown':True,'ch8EndingStarted':False},'中央のロゴスと対峙する。南の階段から休憩室へ戻れる。'),({'ch8EndingStarted':True,'part1Complete':False},'物語を見届けよう。移動は自動。Space・クリック・タップで会話を進める。'),({'part1Complete':True},'第1部完結。記録ファイルを保存してください。第2部は次工程です。')]
d['objectives']=[o for o in d['objectives']if not any(k.startswith('ch8')or k=='part1Complete'for k in o.get('when',{})) and o.get('when',{}).get('chapter8Started') is not True]
d['objectives'][:0]=[dict(when=w,text=t)for w,t in objs];d['sequences']=sequences
cps=[dict(id='C8',label='第8章・最後の階段',chapter=8,map='ch8_ascent',x=12,y=28),dict(id='C8E',label='第1部END',chapter=8,map='ep_entrance',x=12,y=13)]
d['recovery']['checkpoints']=[c for c in d['recovery']['checkpoints']if c['chapter']!=8]+cps
d['recovery']['completedFlags']['8']={**d['recovery']['completedFlags']['7'],'chapter8Started':True,'ch8AscentKnown':True,'ch8EndingStarted':True,'ch8LogosDefeated':True,'ch8TowerReleased':True,'ch8NoteReturned':True,'chapter8Complete':True,'part1Complete':True,'renSeparated':True}
d['maps']=maps
for n,v in [('maps.json',maps),('game-data.json',d),('chapter8-events.json',events)]:(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
b=read('balance.json');b['version']='0.11.0';c=b['chapters'][7];c.update(implemented=True,normalExp=115,bossExp=620);(R/'data/balance.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print('Chapter8: 7 new maps, SCENE47–60, Logos, resumable automatic finale')
