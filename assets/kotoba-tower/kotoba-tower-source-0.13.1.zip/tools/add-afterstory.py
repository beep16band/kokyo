"""Add SCENE61–64 without changing any existing Part 1 maps or dialogue."""
from pathlib import Path
import copy,json
R=Path(__file__).resolve().parents[1]
def read(name):return json.loads((R/'data'/name).read_text())
def write(name,value):(R/'data'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))
d=read('game-data.json');maps=read('maps.json');canon=read('part2-canonical-scenes.json')['scenes']
def pages(scene,lo=0,hi=999):
 return [dict(speaker=e['speaker'],text=e['text'],sourceScene=scene,sourceLine=e['sourceLine'],sourceDocument='part2',pause=.6 if e['text'] in ['全部、俺が持ってればいいのか。','塔の力……まだ残ってるのか。'] else 0) for e in canon[str(scene)]['entries'] if e['speaker'] and lo<=e['sourceLine']<=hi]
def event(scene,lo,hi,flags=None,sequence=None,when=None):
 return dict(name='',pages=pages(scene,lo,hi),once=False if flags else True,when=when or {},effects=([dict(type='flags',values=flags)] if flags else [])+([dict(type='sequence',id=sequence)] if sequence else []))
events={
 'as_arrival':dict(name='',pages=pages(61,20,20),when={'asTownStarted':False},effects=[dict(type='flags',values={'asTownStarted':True})]),
 'as_oldman':event(61,22,29,{'asOldmanHeard':True}),
 'as_child':dict(name='',pages=[],effects=[dict(type='sequence',id='as_child_walk')]),
 'as_child_repeat':event(61,31,38,{'asChildHeard':True}),
 'as_couple':event(61,40,46,{'asCoupleHeard':True}),
 'as_first_absorb':dict(name='',pages=[],effects=[dict(type='sequence',id='as_absorb_first')]),
 'as_days':dict(name='',pages=[],when={'asFirstAbsorbed':True,'asMoreMonsters':False},effects=[dict(type='sequence',id='as_days_pass')]),
 'as_absorb_2':dict(name='',pages=[],effects=[dict(type='sequence',id='as_absorb_2')]),
 'as_absorb_3':dict(name='',pages=[],effects=[dict(type='sequence',id='as_absorb_3')]),
 'as_absorb_4':dict(name='',pages=[],effects=[dict(type='sequence',id='as_absorb_4')]),
 'as_clear':dict(name='',pages=[],when={'absorbed:as-more-2':True,'absorbed:as-more-3':True,'absorbed:as-more-4':True,'asStreetClear':False},effects=[dict(type='sequence',id='as_street_insight')]),
 'as_inn_end':dict(name='',pages=[],effects=[dict(type='sequence',id='as_inn_decision')]),
}
def dialogue(scene,lo=0,hi=999):return dict(type='dialogue',pages=pages(scene,lo,hi))
def visual(kind,duration,**kw):return dict(type='visual',kind=kind,duration=duration,**kw)
seq=d.setdefault('sequences',{})
seq['as_child_walk']=[dict(type='actors',values={'child':dict(x=11,y=16,dir='left')}),dict(type='move',actor='child',to=[12,14],seconds=.12),dialogue(61,31,38),dict(type='flags',values={'asChildHeard':True}),dict(type='finish')]
seq['as_absorb_first']=[visual('absorb',2.6,enemy='slime',count=1),dialogue(62,51,51),dict(type='absorb',id='as-first'),visual('absorb-ring',1.4),dialogue(62,53,53),visual('absorb-glyph',1.2),dialogue(62,55,55),dict(type='flags',values={'asFirstAbsorbed':True}),dict(type='finish')]
seq['as_days_pass']=[visual('fade',.8),visual('days',1.8),dict(type='flags',values={'asMoreMonsters':True}),dialogue(63,60,63),dict(type='finish')]
for n,asset in [(2,'bat'),(3,'goblin'),(4,'hound')]:
 seq['as_absorb_'+str(n)]=[visual('absorb',2.3,enemy=asset,count=n),dict(type='absorb',id='as-more-'+str(n)),visual('absorb-ring',.8),dict(type='finish')]
seq['as_street_insight']=[dialogue(63,65,65),dialogue(63,67,67),dict(type='flags',values={'asStreetClear':True}),dict(type='finish')]
seq['as_inn_decision']=[dict(type='actors',values={'hero':dict(x=7,y=11,dir='up')}),dict(type='move',actor='hero',to=[9,4],seconds=.18),dialogue(64,72,75),dict(type='face',actor='hero',dir='down'),visual('night-window',1.2),dict(type='face',actor='hero',dir='up'),dialogue(64,77,78),visual('water-ripple',2),dialogue(64,80,81),visual('fade',1.6),dict(type='afterstory-end')]
def clone_map(old,new,name):
 m=copy.deepcopy(maps[old]);m.update(id=new,name=name,afterStory=True,chapter=8,npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[])
 m['objects']=[o for o in m['objects'] if o['kind'] not in ['chest','sign','vista']]
 for o in m['objects']:o.pop('events',None)
 maps[new]=m;return m
def npc(id,name,x,y,asset,ev):return dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),pages=[],events=ev)
def portal(id,x,y,target,sx,sy,label,requires=None):
 p=dict(id=id,kind='door' if 'inn' in id else 'path',asset='gate_door' if 'inn' in id else 'stone_arch',x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='down'),label=label,interactionLabel=label+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['町の人々に話を聞き、外の魔物を確かめよう。' if 'asStreetClear' not in requires else '街道の三体を倒してから、宿屋へ戻ろう。'])
 return p
v=clone_map('ch1_village','as_village','AFTER STORY・平和になった町')
v['npcs']=[npc('oldman','老人',16,11,'npc',['as_oldman']),npc('child','子ども',11,16,'villager',['as_child','as_child_repeat']),npc('couple','老夫婦',24,11,'elderwoman',['as_couple'])]
v['npcs'].append(npc('couple_partner','老人',25,11,'npc',['as_couple']))
v['npcs'][1]['when']={'asChildHeard':False}
v['npcs'].append(npc('child','子ども',12,14,'villager',['as_child_repeat']))
v['npcs'][-1]['when']={'asChildHeard':True}
v['portals']=[portal('as-town-out',2,14,'as_outskirts',25,14,'町外れの街道',{'asOldmanHeard':True,'asChildHeard':True,'asCoupleHeard':True}),portal('as-town-inn',7,9,'as_inn',7,11,'宿屋',{'asStreetClear':True})]
v['entryEvents']=['as_arrival','as_days'];v['safeSpawn']=dict(x=15,y=15,dir='up')
o=clone_map('ch1_meadow','as_outskirts','AFTER STORY・町外れの街道')
o['entryEvents']=['as_clear']
o['safeSpawn']=dict(x=25,y=14,dir='left');o['portals']=[portal('as-road-town',26,14,'as_village',3,14,'町へ戻る')]
for n,x,y,eid,asset in [(1,21,14,'AS_SLIME','slime'),(2,18,12,'AS_BAT','bat'),(3,12,13,'AS_GOBLIN','goblin'),(4,20,15,'AS_HOUND','hound')]:
 d['enemies'][eid]=dict(id=eid,name=['','町外れの魔物','街道のコウモリ','街道の小鬼','街道の魔犬'][n],asset=asset,hp=42+n*3,attack=19+n,defense=7+n,guard=7+n,attackSeconds=14,exp=0,gold=0,rank='normal',role='afterstory',questionCategories=['慣用句','ことわざ'])
 o['enemies'].append(dict(id='as-enemy-'+str(n),enemy=eid,x=x,y=y,respawn=False,when={'asMoreMonsters':False} if n==1 else {'asMoreMonsters':True},afterEvent='as_first_absorb' if n==1 else 'as_absorb_'+str(n),behavior=dict(type='patrol_chase',stepSeconds=.5,chaseRadius=3,leash=4)))
i=clone_map('ch1_inn','as_inn','AFTER STORY・夜の宿屋');i['night']=True
i['objects']=[o for o in i['objects'] if o['id'] not in ['table13']]
def prop(id,x,y,asset,w=32,h=32):return dict(id=id,kind='prop',x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h)
i['objects'] += [prop('as-window',9,3,'afterstory_window',64,64),prop('as-cup',11,5,'afterstory_cup_table')]
i['objects'][-1]['collider']=dict(x=352,y=172,w=32,h=20)
i['entryEvents']=['as_inn_end'];i['safeSpawn']=dict(x=7,y=11,dir='up')
i['portals']=[portal('as-inn-town',7,12,'as_village',7,10,'町へ戻る')]
# New objectives take precedence; old objective entries stay verbatim.
d['objectives']=[x for x in d['objectives'] if not x.get('afterStory')]
d['objectives'][:0]=[
 dict(afterStory=True,when={'asTownStarted':True,'asFirstAbsorbed':False},text='老人・子ども・老夫婦に話を聞こう。西の石門から町外れの魔物を確認する。'),
 dict(afterStory=True,when={'asFirstAbsorbed':True,'asMoreMonsters':False},text='東の石門から町へ戻ろう。'),
 dict(afterStory=True,when={'asMoreMonsters':True,'asStreetClear':False},text='西の石門から街道へ。三体の魔物を倒して町を守ろう。'),
 dict(afterStory=True,when={'asStreetClear':True,'asComplete':False},text='町へ戻り、左上の建物の扉から宿屋へ。'),
]
c=read('continuation.json');c['version']='0.13.1';c['afterStory'].update(implemented=True,entryMap='as_village',entry=dict(map='as_village',spawn=dict(x=3,y=14,dir='right')))
c['defaults']['afterStory'].update(potions=3,heroReturn=None)
write('continuation.json',c);write('maps.json',maps);write('game-data.json',d);write('afterstory-events.json',events)
print('SCENE61–64: 3 maps, 4 encounters, canonical dialogue; existing maps preserved.')
