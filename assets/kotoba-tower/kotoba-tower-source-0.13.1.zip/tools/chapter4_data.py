"""Chapter4 scenes26–30; canonical dialogue and existing question bank/assets."""
from pathlib import Path
import json,copy,shutil
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
maps=read('maps.json');d=read('game-data.json');sc=read('canonical-scenes.json');events={}
def event(id,pages,flags=None,when=None,effects=None,once=True):
 events[id]=dict(id=id,pages=pages,when=when or {},effects=([dict(type='flags',values=flags)] if flags else [])+(effects or []),once=once)
def text(s,t):return dict(speaker=s,text=t)
def travel(id,x,y,dir='up'):return dict(type='travel',map=id,spawn=dict(x=x,y=y,dir=dir))
def room(id,name,w=26,h=18,inside=False):
 m=dict(id=id,name='第4章・'+name,chapter=4,width=w,height=h,tiles=['floor' if inside else 'grass']*(w*h),collision=[int(x==0 or y==0 or x==w-1 or y==h-1) for y in range(h) for x in range(w)],wallAsset='wall' if inside else 'rock_wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=3,y=h-4,dir='up'));maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,solid=True,ev=None):
 o=dict(id=id,x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,kind='decor',footprint=[dict(x=0,y=0,w=w,h=h)] if solid else [])
 if ev:o.update(events=ev,interactionRect=dict(x=x*32+16-w//2,y=y*32+32-h,w=w,h=h),interactionLabel='記憶を調べる')
 m['objects'].append(o);return o
def portal(m,id,x,y,target,sx,sy,requires=None,kind='path',dir='up'):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir=dir),kind=kind,asset={'path':'stone_arch','door':'gate_door','stairs':'stairs_down'}[kind]);m['portals'].append(p)
 if requires:p.update(requires=requires,lockedPages=['先に、この場所に残る記憶と言葉を確かめよう。'])
 return p
def road(m):
 for y in range(2,m['height']-2):
  for x in range(2,m['width']-2):
   if y in [4,m['height']-4] or x in [3,m['width']-4]:m['tiles'][y*m['width']+x]='path'
def npc(m,id,name,x,y,asset,ev=None,pages=None,when=None,service=None):
 n=dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),events=ev or [],pages=pages or ['相手の話も、自分の気持ちも、ゆっくり考えてみよう。'])
 if when:n['when']=when
 if service:n.update(service=service[0],serviceId=service[1])
 m['npcs'].append(n);return n

g=maps['ch3_terrace'];g['objects']=[o for o in g['objects'] if o['id']!='chapter4_route'];g['portals']=[p for p in g['portals'] if p['id']!='gate-chapter4'];portal(g,'gate-chapter4',10,4,'ch4_road',3,14,{'chapter3Complete':True})
r=room('ch4_road','分岐する町への道');road(r);r['entryEvents']=['ch4_road_intro'];portal(r,'ch4-road-back',2,14,'ch3_terrace',10,5,dir='down');portal(r,'ch4-road-town',22,4,'ch4_town',3,16)
for k,(x,y) in enumerate([(7,6),(12,6),(17,8),(7,11)]):
 o=obj(r,'ch4-tree-'+str(k),x,y,'tree',64,64);o['footprint']=[dict(x=26,y=48,w=12,h=16)]
r['enemies']=[dict(id='ch4-road-wisp',enemy='S4_WISP',x=16,y=14,respawn=True)]
t=room('ch4_town','分岐する町',30,20);road(t);t['entryEvents']=['ch4_town_intro'];portal(t,'ch4-town-back',2,16,'ch4_road',21,4,dir='left');portal(t,'ch4-town-memory',26,4,'ch4_memory_garden',3,14,{'wordsNeighbor':True,'wordsTraveler':True})
npc(t,'neighbor','町人',8,10,'villager',['ch4_neighbor','ch4_neighbor_repeat']);npc(t,'traveler','旅人',18,12,'merchant',['ch4_traveler','ch4_traveler_repeat'])
npc(t,'ch4_shop','分岐する町の道具屋',21,16,'merchant',service=('shop','branch-shop'))
o=obj(t,'ch4-inn-house',10,6,'stone_house',128,128);o['kind']='building';o['footprint']=[dict(x=0,y=0,w=128,h=96),dict(x=0,y=96,w=48,h=32),dict(x=80,y=96,w=48,h=32)];o['entrance']=dict(x=48,y=96,w=32,h=32)
portal(t,'ch4-town-inn',10,6,'ch4_inn',7,11,kind='door')
i=room('ch4_inn','分岐する町の宿',18,15,True);i['safeSpawn']=dict(x=7,y=11,dir='up');portal(i,'ch4-inn-back',7,12,'ch4_town',10,7,kind='door',dir='down');npc(i,'ch4_innkeeper','宿の人',7,7,'elderwoman',service=('inn','branch-inn'))
a=room('ch4_memory_garden','選べなかった言葉の庭');road(a);a['entryEvents']=['ch4_memory_arrival'];portal(a,'ch4-memory-back',2,14,'ch4_town',25,4,dir='left');portal(a,'ch4-memory-crossroad',22,4,'ch4_crossroad',3,14,{'memoryCRead':True})
obj(a,'memory_b',8,8,'old_book',ev=['ch4_memory_b','ch4_memory_b_repeat']);obj(a,'memory_c',18,11,'scroll',ev=['ch4_memory_c','ch4_memory_c_wait','ch4_memory_c_repeat'])
for id,title,entry in [('ch4_school_b','回想・夕焼けの教室','ch4_memory_b_scene'),('ch4_school_c','回想・転校の知らせ','ch4_memory_c_scene')]:
 school=copy.deepcopy(maps['school_class']);school.update(id=id,name=title,chapter=4,school=False,memory=True,portals=[],enemies=[],triggers=[],entryEvents=[entry],npcs=[],safeSpawn=dict(x=9,y=9,dir='left'))
 # Existing classroom decor remains; remove story objects/events from the original school.
 for o in school['objects']:o.pop('events',None);o.pop('when',None)
 npc(school,'memory-aoi','アオイ',8,9,'aoi_pipoya_student');maps[id]=school
c=room('ch4_crossroad','レンとの分かれ道');road(c);c['entryEvents']=['ch4_argument'];portal(c,'ch4-crossroad-back',2,14,'ch4_memory_garden',21,4,dir='left');portal(c,'ch4-crossroad-passage',22,4,'ch4_passage',3,14,{'renArgumentFinished':True})
p=room('ch4_passage','途切れた石畳');road(p);p['entryEvents']=['ch4_passage_intro'];portal(p,'ch4-passage-back',2,14,'ch4_crossroad',21,4,dir='left');portal(p,'ch4-passage-knight',22,4,'ch4_knight',12,14,{'renReconciled':True})
npc(p,'ren-ahead','レン',12,8,'ren_pipoya_student',pages=['レンは魔物の向こうにいる。中央の通路から近づこう。'],when={'renSeparated':True})
p['enemies']=[dict(id='ch4-rescue-shadow',enemy='S4_SHADOW',x=12,y=11,introEvent='ch4_rescue_start',afterEvent='ch4_reunion')]
# Prevent walking around the rescue encounter without entering battle.
for y in [10]:
 for x in range(1,25):
  if x!=12:p['collision'][y*26+x]=1
b=room('ch4_knight','言換の騎士の間',26,20,True);b['safeSpawn']=dict(x=12,y=14,dir='up');b['entryEvents']=['ch4_knight_room'];portal(b,'ch4-knight-back',12,16,'ch4_passage',21,4,kind='door',dir='down');portal(b,'ch4-knight-terrace',12,3,'ch4_terrace',10,12,{'paraphraseKnightFreed':True},kind='door')
for x in range(1,25):
 if x!=12:b['collision'][8*26+x]=1
b['enemies']=[dict(id='paraphrase-knight',enemy='S4_KNIGHT',x=12,y=9,introEvent='ch4_knight_appears',afterEvent='ch4_knight_freed')]
z=room('ch4_terrace','自分の言葉への道',22,16);road(z);z['entryEvents']=['chapter4_clear'];portal(z,'ch4-terrace-back',10,13,'ch4_knight',12,4,dir='down');obj(z,'chapter5_route',10,4,'stone_arch',solid=False,ev=['chapter5_not_ready'])

event('chapter4_departure',[text('','第4章　選べなかった言葉'),text('レン','次の町へ行こう。ノートに残っていることも、まだあるはずだ。')],{'chapter4Started':True},{'chapter3Complete':True},[dict(type='chapter',value=4),travel('ch4_road',3,14)])
event('ch4_road_intro',[text('','第4章　選べなかった言葉'),text('','北東の門から、分岐する町へ。')],{'chapter4Started':True},effects=[dict(type='chapter',value=4)])
event('ch4_town_intro',sc['26']+[text('','西の町人と東の旅人の話を聞こう。相手に届けたい言葉は、一つに決まるとは限らない。')],{'ch4TownVisited':True})
event('ch4_neighbor',[text('町人','忙しい友人に、会えなくて寂しいと伝えたい。でも、責めていると思われたくない。')],when={'wordsNeighbor':False},effects=[dict(type='choice',id='words_neighbor')],once=False)
event('ch4_traveler',[text('旅人','待ち合わせに遅れた仲間が来た。安心したけど、心配したことも伝えたい。')],when={'wordsTraveler':False},effects=[dict(type='choice',id='words_traveler')],once=False)
event('ch4_neighbor_repeat',[text('町人','同じ気持ちでも、言葉の選び方で伝わり方が変わるんだね。')],when={'wordsNeighbor':True},once=False)
event('ch4_traveler_repeat',[text('旅人','言葉を選ぶと、自分が何を伝えたかったかも分かる。')],when={'wordsTraveler':True},once=False)
d['interactions']['words_neighbor']=dict(id='words_neighbor',name='町人',prompt='会えずに寂しい気持ちを、どう伝える？',choices=['また会えたらうれしい','忙しそうだけど、少し寂しい','落ち着いたら話したい'],flags={'wordsNeighbor':True},outcomes=[dict(pages=[text('町人','次に会うのを楽しみにしている、と伝わるね。')]),dict(pages=[text('町人','相手の事情も、自分の寂しさも、両方言っていいんだね。')]),dict(pages=[text('町人','急がせずに、話したい気持ちを残せるね。')])])
d['interactions']['words_traveler']=dict(id='words_traveler',name='旅人',prompt='待っていた仲間に、最初に何を伝える？',choices=['無事でよかった','心配したよ。何かあった？','来てくれて安心した'],flags={'wordsTraveler':True},outcomes=[dict(pages=[text('旅人','まず無事を喜べば、話しやすくなりそうだ。')]),dict(pages=[text('旅人','心配したことを言って、相手の事情も聞ける。')]),dict(pages=[text('旅人','安心した気持ちを、そのまま伝えればいいんだな。')])])
event('ch4_memory_arrival',[text('','開かれたノートと古い紙が、二つの記憶に重なる。'),text('','まず西側のノート、次に東側の紙を調べよう。')],{'ch4MemoryVisited':True})
event('ch4_memory_b',[text('','ノートを開くと、夕焼けの教室がよみがえる。')],when={'memoryBRead':False},effects=[travel('ch4_school_b',9,9,'left')],once=False)
event('ch4_memory_b_scene',sc['27'][:13],effects=[travel('ch4_memory_garden',8,9),dict(type='flags',values={'memoryBRead':True})])
event('ch4_memory_b_return',sc['27'][13:]+[text('','東側の紙に、もう一つの記憶が残っている。')],{'memoryBReturned':True},{'memoryBRead':True})
a['entryEvents'].append('ch4_memory_b_return')
event('ch4_memory_b_repeat',[text('主人公','掃除当番のことだけじゃなかった。あの時、ちゃんと聞けばよかった。')],when={'memoryBRead':True},once=False)
event('ch4_memory_c', [text('','紙に触れると、転校を聞いた日の教室に戻る。')],when={'memoryBRead':True,'memoryCRead':False},effects=[travel('ch4_school_c',9,9,'left')],once=False)
event('ch4_memory_c_scene',sc['28'][:12],effects=[travel('ch4_memory_garden',18,12),dict(type='flags',values={'memoryCRead':True})])
event('ch4_memory_c_return',sc['28'][12:]+[text('','北東の門から、次の道へ。')],{'memoryCReturned':True},{'memoryCRead':True})
a['entryEvents'].append('ch4_memory_c_return')
event('ch4_memory_c_wait',[text('レン','先に、西側のノートを読もう。')],when={'memoryBRead':False},once=False)
event('ch4_memory_c_repeat',[text('主人公','「そっか」だけで終わらせた。言いたかったことは、別にあった。')],when={'memoryCRead':True},once=False)
event('ch4_argument',sc['29'][:8],when={'memoryCRead':True},effects=[dict(type='npcRoute',npc='follower',destination=[22,4],finishFlags={'renSeparated':True},afterEvent='ch4_after_argument')])
event('ch4_after_argument',[text('','レンは北東の門を抜け、先へ行った。'),text('主人公','……追いかけよう。')],{'renArgumentFinished':True})
event('ch4_passage_intro',[text('','中央の石畳に、魔物が現れた。レンはその向こうにいる。'),text('','中央の通路からレンのところへ。')],{'ch4PassageVisited':True})
event('ch4_rescue_start',[text('レン','こっちにも来る！'),text('主人公','分かった。そっちは頼む！')],effects=[dict(type='battle',encounter='ch4-rescue-shadow')])
event('ch4_reunion',sc['29'][8:]+[text('','北東の門から、言換の騎士の間へ。')],{'renSeparated':False,'renReconciled':True})
event('ch4_knight_room',[text('','通路の中央に、言換の騎士が待っている。')],{'ch4KnightEntered':True})
event('ch4_knight_appears',sc['30'][:2],effects=[dict(type='battle',encounter='paraphrase-knight')])
event('ch4_knight_freed',sc['30'][2:]+[text('','北の扉が開いた。自分の言葉への道へ進もう。')],{'paraphraseKnightFreed':True})
event('chapter4_clear',[text('','第4章　選べなかった言葉　CLEAR')],{'chapter4Complete':True},{'paraphraseKnightFreed':True})
event('chapter5_not_ready',[text('','第5章は次工程で実装します。町に戻って装備を整えたり、記録を保存できます。')],once=False)
d['chapters'][4]=dict(id=4,name='選べなかった言葉',implemented=True,scenes=list(range(26,31)))
d['enemies']['S4_WISP']=dict(id='S4_WISP',name='すれ違いの灯',hp=110,attack=10,attackSeconds=14,exp=45,gold=55,asset='archive_wisp',questionCategories=['類義語','対義語'])
d['enemies']['S4_SHADOW']=dict(id='S4_SHADOW',name='途切れた言葉の影',hp=160,attack=11,attackSeconds=14,exp=85,gold=110,asset='archive_wisp',questionCategories=['類義語','対義語'])
d['enemies']['S4_KNIGHT']=dict(id='S4_KNIGHT',name='言換の騎士',hp=320,attack=15,attackSeconds=14,exp=180,gold=240,asset='paraphrase_knight',questionCategories=['類義語','対義語','熟語の読み方'])
d['shops']['branch-shop']=dict(name='分岐する町の道具屋',products=[dict(id='I001',type='item',price=35),dict(id='A002',type='gear',price=180),dict(id='W005',type='gear',price=600)])
d['inns']['branch-inn']=dict(name='分岐する町の宿',price=20)
objectives=[({'chapter4Complete':True},'第4章CLEAR。町へ戻って準備・保存できる。第5章は次工程。'),({'paraphraseKnightFreed':True},'騎士の間の北の扉から、自分の言葉への道へ。'),({'ch4KnightEntered':True},'中央の言換の騎士に近づこう。'),({'renReconciled':True},'途切れた石畳の北東の門から、言換の騎士の間へ。'),({'renSeparated':True},'北東の門へ。次の石畳の中央通路からレンを追おう。'),({'memoryCRead':True},'記憶の庭の北東の門から、次の道へ。'),({'memoryBRead':True},'記憶の庭の東側にある紙を調べよう。'),({'ch4MemoryVisited':True},'記憶の庭の西側のノートを調べよう。'),({'wordsNeighbor':True,'wordsTraveler':True},'町の北東の門から、記憶の庭へ。'),({'ch4TownVisited':True},'西の町人と東の旅人に話し、届けたい言葉を選ぼう。'),({'chapter4Started':True},'道の北東の門から、分岐する町へ。')]
keys=set(k for a,_ in objectives for k in a)
d['objectives']=[dict(when=a,text=b) for a,b in objectives]+[o for o in d['objectives'] if not keys.intersection(o.get('when',{}))]
for o in d['objectives']:
 if o.get('when')=={'chapter3Complete':True}:o['text']='第3章CLEAR。外廊の北の門から第4章「選べなかった言葉」へ。'
for m in maps.values():
 for p in m['portals']:
  p['label']=maps[p['target']]['name'].split('・')[-1]+'へ';p['interactionLabel']=p['label']+'移動'
for n,v in [('maps.json',maps),('game-data.json',d),('chapter4-events.json',events)]: (R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
raw=R.parent/'assets_raw/Dungeon Crawl Stone Soup Supplemental/Dungeon Crawl Stone Soup Supplemental/monster/death_knight.png'
shutil.copy2(raw,R/'assets/paraphrase_knight.png')
print('Chapter4: 10 maps, scenes26–30, existing question bank unchanged')
