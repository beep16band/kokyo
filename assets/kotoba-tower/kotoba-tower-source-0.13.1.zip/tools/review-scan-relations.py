"""Build a reversible runtime review layer. Raw question banks are never modified.
Base text: user-supplied Epson scan PDF4, printed pages236–237, visually reviewed.
"""
from pathlib import Path
import json,re,hashlib,collections
R=Path(__file__).resolve().parents[1]
source=R/'reference/test-scope/scan-relations-reviewed.txt'
rows=[];category=None
for line in source.read_text().splitlines():
 if not line or line.startswith('#'):continue
 if line.startswith('['):category=line[1:-1];continue
 a=line.split();assert len(a)==5,a
 assert all(re.fullmatch('[一-龯]{2}',w) for w in a),a
 assert len(set([a[1],*a[2:]]))==4,a
 rows.append(dict(category=category,word=a[0],target=a[1],distractors=a[2:],pdfPage=4,printedPage=236 if category=='類義語' else 237))
# Opposite/similar relations work in both directions. Reverse wording gets its own authored distractors.
reverse_distractors={
'類義語':{'冷静':['冷淡','冷却','静養'],'容易':['容器','美容','易者'],'承認':['承継','認知','認識'],'永遠':['永眠','遠方','永別'],'著名':['姓名','署名','名誉'],'貢献':['献立','献血','貢物'],'迅速':['速度','速達','速読']},
'対義語':{'主観':['主義','主人','主張'],'保守':['保護','保存','保証'],'冷静':['沈着','冷却','静養'],'利益':['利用','利点','利息'],'前進':['進行','進級','進歩'],'収入':['所得','収穫','収容'],'増加':['増大','増額','増員'],'平等':['均等','平凡','平均'],'慎重':['注意','用心','慎重'],'抽象':['抽選','抽出','抽象'],'楽観':['観察','楽曲','快楽'],'理想':['思想','夢想','空想'],'秩序':['順序','法則','規則'],'積極':['積立','積算','積分'],'義務':['任務','職務','責任']}}
lookups={(x['category'],x['word']):x for x in rows}
for row in rows:
 c,w,t=row['category'],row['word'],row['target']
 if t in reverse_distractors[c] and (c,t)not in lookups:
  lookups[c,t]={**row,'word':t,'target':w,'distractors':reverse_distractors[c][t],'direction':'reverse'}
# Retain source pairing graph to ensure another scan-listed answer never appears as a wrong choice.
graph=collections.defaultdict(set)
for row in rows:
 c,w,t=row['category'],row['word'],row['target'];graph[c,w].add(t);graph[c,t].add(w)
for row in lookups.values():
 assert all(w not in graph[row['category'],row['word']] for w in row['distractors']),row
 assert len(set([row['target'],*row['distractors']]))==4,row
 assert all(re.fullmatch('[一-龯]{2}',w) for w in row['distractors']),row
review={'id':'scan-relations-20261007-v2','source':'Epson_20261007075142(2).pdf','pdfPage':4,'printedPages':[236,237],'basis':'user-supplied scan, visually verified; no dictionary substitutions','pairFileSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'pairs':rows,'overrides':{},'excluded':{},'statistics':{}}
counts=collections.Counter()
for q in json.loads((R/'data/questions.json').read_text())+json.loads((R/'data/exam-questions.json').read_text()):
 cat=q['category']
 if cat not in ['類義語','対義語']:continue
 row=lookups.get((cat,q['word']))
 if not row:
  review['excluded'][q['id']]='二字熟語ではない、またはスキャンの掲載組み合わせにない';counts['excluded:'+cat]+=1;continue
 choices=row['distractors'].copy();choices.insert(q['answer'],row['target'])
 prompt='「'+q['word']+'」の'+cat+'として、資料に載っている二字熟語を選ぼう。'
 if q['word']=='権威' and cat=='類義語':prompt='ある分野で優れた専門家を指す「権威」。資料に載っている類義語を選ぼう。'
 meaning=q['word']+(' ≒ 'if cat=='類義語'else' ⇔ ')+row['target']
 explanation='テスト範囲の資料では「'+q['word']+'」と「'+row['target']+'」を'+('意味が近い語'if cat=='類義語'else'対になる語')+'として示している。'+('類義語は、すべての場面で置き換えられるとは限らない。'if cat=='類義語'else'どの点で対になっているかを意識して覚えよう。')
 review['overrides'][q['id']]={'prompt':prompt,'choices':choices,'answer':q['answer'],'correctAnswer':row['target'],'meaning':meaning,'explanation':explanation,'example':'','hints':[],'preserveChoiceOrder':True,'reviewSource':{'source':review['source'],'pdfPage':4,'printedPage':row['printedPage'],'word':row['word'],'target':row['target'],'direction':row.get('direction','forward'),'verified':True}}
 counts['active:'+cat]+=1
 if q['choices'][q['answer']]!=row['target']:counts['correctedAnswers']+=1
review['statistics']=dict(counts);(R/'data/question-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(review['statistics'],ensure_ascii=False))
# Correct the older transcription only where the printed glyph was previously misread.
p=R/'reference/test-scope/final-transcription.json';v=json.loads(p.read_text())
for x in v['entries']:
 if x['category']=='類義語' and x['word']=='実直':x['target']='律儀'
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
