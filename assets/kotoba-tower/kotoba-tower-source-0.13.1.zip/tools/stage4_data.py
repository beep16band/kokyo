from pathlib import Path
import json,shutil
from PIL import Image
import numpy as np
from scipy import ndimage
R=Path(__file__).resolve().parents[1]; raw=R.parent/'assets_raw'; A=R/'assets';ref=R/'reference/stage4-art';ref.mkdir(exist_ok=True)
art=[('ren_prone','exec-88cbacf2-6fb0-4f86-88a0-bc30a568895a.png',32),('school_stair_inset','exec-4306060e-64c6-40e7-8201-c8d21c1ee747.png',64)]
meta=[]
for name,file,size in art:
 src=R.parent/'generated_images'/file;shutil.copy(src,ref/file);im=Image.open(src).convert('RGBA');arr=np.array(im);lab,n=ndimage.label(arr[:,:,3]>180,structure=np.ones((3,3)));sizes=np.bincount(lab.ravel());sizes[0]=0;mask=lab==sizes.argmax();yy,xx=np.where(mask);arr[:,:,3]=np.where(mask,255,0);im=Image.fromarray(arr).crop((xx.min(),yy.min(),xx.max()+1,yy.max()+1));factor=min((size-2)/im.width,(size-2)/im.height);w,h=round(im.width*factor),round(im.height*factor);im=im.resize((w,h),Image.Resampling.NEAREST);out=Image.new('RGBA',(size,size));out.paste(im,((size-w)//2,30-h if size==32 else (size-h)//2));out.save(A/(name+'.png'));meta.append({'asset':name,'source':'imagegen '+file,'size':[size,size],'processing':'alpha component crop; uniform nearest-neighbour'})
for name,file in [('context_beast','warg.png'),('old_book','light_brown_old.png'),('scroll','scroll.png')]:
 hits=list(raw.rglob(file))
 if not hits:
  hits=list(raw.rglob('hound.png' if name=='context_beast' else 'manual_1.png'))
 p=hits[0];im=Image.open(p).convert('RGBA');im.save(A/(name+'.png'));meta.append({'asset':name,'source':str(p),'size':list(im.size),'processing':'original PNG'})
(R/'docs/stage4-assets.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
maps=json.loads((R/'data/maps.json').read_text());d=json.loads((R/'data/game-data.json').read_text());events={}
# Broaden the existing grassland entry and retain its original coordinates for old saves.
p=maps['ch1_meadow']['portals'][1];p.update(rect={'x':26*32,'y':13*32,'w':64,'h':96},label='名のない村へ →',interactionLabel='村へ入る');
for y in range(13,16):
 for x in range(25,29):maps['ch1_meadow']['tiles'][y*30+x]='path'
n=maps['ch1_underground']['npcs'][0];n.update(asset='ren_prone',awakeAsset='ren_school',standDuring={'event':'meet_ren','page':3});n['collider']={'x':9*32+2,'y':14*32+13,'w':28,'h':17}
maps['school_library']['objects'][-4 if False else 5]['asset']='school_stair_inset' # stable id selection below
for o in maps['school_library']['objects']:
 if o['id']=='mystery_stair':o['asset']='school_stair_inset'
def E(id,pages,flags=None,when=None,effects=None,once=True):
 events[id]={'id':id,'pages':[{'speaker':s,'text':t} for s,t in pages],'when':when or {},'effects':([{'type':'flags','values':flags}] if flags else [])+(effects or []),'once':once}
def travel(id,x,y,dir='up'):return {'type':'travel','map':id,'spawn':{'x':x,'y':y,'dir':dir}}
def M(id,name,w,h,inside=False):
 m={'id':id,'name':name,'chapter':2,'width':w,'height':h,'tiles':['floor' if inside else 'grass']*(w*h),'collision':[int(x==0 or y==0 or x==w-1 or y==h-1) for y in range(h) for x in range(w)],'wallAsset':'wall' if inside else 'rock_wall','objects':[],'npcs':[],'portals':[],'enemies':[],'triggers':[],'entryEvents':[]};maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,kind='decor',events=None,solid=True):
 o={'id':id,'kind':kind,'x':x,'y':y,'asset':asset,'width':w,'height':h,'anchorX':w//2,'anchorY':h,'collider':{'x':x*32+16-w//2,'y':y*32+12,'w':w,'h':20} if solid else None}
 if events:o.update(events=events,interactionRect={'x':x*32+16-w//2,'y':y*32+32-h,'w':w,'h':h},interactionLabel='調べる')
 m['objects'].append(o);return o
def npc(m,id,name,x,y,asset,ev=None,pages=None,service=None):
 n={'id':id,'name':name,'x':x,'y':y,'asset':asset,'dir':'down','collider':{'x':x*32+7,'y':y*32+20,'w':18,'h':11},'events':ev or [],'pages':pages or ['気をつけて行っておいで。']}
 if service:n.update(service=service[0],serviceId=service[1])
 m['npcs'].append(n)
def portal(m,id,x,y,target,sx,sy,kind='path',requires=None,dir='up'):
 p={'id':id,'kind':kind,'asset':'path' if kind=='path' else 'gate_door','x':x,'y':y,'target':target,'spawn':{'x':sx,'y':sy,'dir':dir}}
 if requires:p.update(requires=requires,lockedPages=['まだ先へ進めない。画面の案内を確認しよう。'])
 m['portals'].append(p);return p
def path(m,points):
 for x,y in points:
  for dx,dy in [(0,0),(1,0),(-1,0),(0,1),(0,-1)]:
   a,b=x+dx,y+dy
   if 0<a<m['width']-1 and 0<b<m['height']-1:m['tiles'][b*m['width']+a]='path'
def chest(m,id,x,y,gold,items=None,gear=None):
 o=obj(m,id,x,y,'chest',kind='chest');o['loot']={'gold':gold,'items':items or {},'gear':gear or []}
def trees(m,points):
 for i,(x,y) in enumerate(points):
  o=obj(m,m['id']+'tree'+str(i),x,y,'tree',64,64,kind='tree');o['collider']={'x':x*32+10,'y':y*32+16,'w':12,'h':16}
# Chapter transition is also walkable from the lookout; clear window provides the same route.
portal(maps['ch1_lookout'],'lookout-chapter2',18,5,'ch2_trail',3,14,requires={'chapter1Complete':True})['label']='声を失った集落へ →'
t=M('ch2_trail','第2章・声の途切れる森道',24,18);t['entryEvents']=['ch2_trail_intro'];path(t,[(x,14) for x in range(2,22)]+[(21,y) for y in range(4,15)]);trees(t,[(4,5),(8,6),(12,4),(16,7),(4,10),(7,16),(17,16),(21,2)])
portal(t,'trail-lookout',2,14,'ch1_lookout',17,5,dir='left');portal(t,'trail-settlement',21,4,'ch2_settlement',3,16);t['enemies']=[{'id':'ch2-trail-shadow','enemy':'S2_SHADOW','x':12,'y':14,'respawn':True}];chest(t,'ch2-trail-cache',9,9,45,{'I001':2})
v=M('ch2_settlement','第2章・声を失った集落',32,22);v['entryEvents']=['ch2_arrival'];v['safeSpawn']={'x':15,'y':17,'dir':'up'};path(v,[(x,16) for x in range(2,30)]+[(16,y) for y in range(9,19)]+[(29,y) for y in range(5,17)])
for id,x,y in [('ch2-inn-home',7,8),('ch2-archive-home',16,8),('ch2-family-home',25,9)]:
 o=obj(v,id,x,y,'stone_house',128,128,kind='building');o['collider']={'x':x*32-48,'y':y*32-32,'w':128,'h':64}
portal(v,'settlement-trail',2,16,'ch2_trail',20,4,dir='left');portal(v,'settlement-inn',7,9,'ch2_inn',7,11,kind='door');portal(v,'settlement-archive',16,9,'ch2_archive',8,11,kind='door');portal(v,'settlement-ruins',29,5,'ch2_ruins',3,16,requires={'familyWordsReturned':True})['label']='空文の遺構へ ↑'
trees(v,[(3,4),(29,3),(3,19),(11,20),(28,20)])
npc(v,'mira','家族を待つ住民',10,13,'elderwoman',['help_family','family_reply','family_repeat']);npc(v,'builder','大工',20,14,'merchant',['help_builder','builder_repeat']);npc(v,'messenger','使いの子',25,16,'villager',['help_messenger','messenger_repeat']);npc(v,'ch2_shop','旅道具の店',16,18,'merchant',service=('shop','voiceless-shop'));chest(v,'ch2-town-cache',5,17,35,{'I001':2})
a=M('ch2_archive','第2章・集落の古文書室',18,15,True);portal(a,'archive-return',8,12,'ch2_settlement',16,10,kind='door',dir='down');obj(a,'ancient_document',8,4,'old_book',events=['ancient_idea','ancient_repeat']);obj(a,'notebook_table',11,9,'old_book',events=['memory_A_again','notebook_margin','notebook_repeat']);obj(a,'ordinary_paper',5,9,'scroll',events=['ordinary_paper']);npc(a,'archivist','古文書の世話人',7,6,'npc',pages=['困っている三人の話を聞いてきておくれ。こちらの古文書と、君のノートも読み比べてみよう。']);chest(a,'ch2-archive-cache',13,5,0,{'I001':1},['W003']);a['safeSpawn']={'x':8,'y':11,'dir':'up'}
i=M('ch2_inn','第2章・集落の宿',18,15,True);portal(i,'ch2-inn-return',7,12,'ch2_settlement',7,10,kind='door',dir='down');npc(i,'ch2_innkeeper','宿の人',7,7,'elderwoman',service=('inn','voiceless-inn'));i['safeSpawn']={'x':7,'y':11,'dir':'up'}
r=M('ch2_ruins','第2章・空文の遺構',28,20,True);r['entryEvents']=['hollow_ruins'];path(r,[])
for y in range(1,19):
 if y!=12:r['collision'][y*28+13]=1
portal(r,'ruins-settlement',2,16,'ch2_settlement',28,5,dir='down');portal(r,'ruins-forward',23,4,'ch2_gate',10,12,kind='door',requires={'hollowBeastDefeated':True});r['enemies']=[{'id':'ch2-ruins-shadow','enemy':'S2_SHADOW','x':10,'y':12,'respawn':True},{'id':'hollow-beast','enemy':'S2_HOLLOW','x':23,'y':7,'introEvent':'hollow_beast_appears','afterEvent':'hollow_beast_freed'}];chest(r,'ch2-ruins-cache',19,15,70,{'I001':3})
g=M('ch2_gate','第2章・書庫へ続く門',22,16);g['entryEvents']=['chapter2_clear'];path(g,[(10,y) for y in range(4,14)]);portal(g,'gate-ruins',10,13,'ch2_ruins',23,5,kind='door',dir='down');obj(g,'future_archive_gate',10,4,'stone_arch',events=['chapter3_not_ready'],solid=False)
# Canonical scenes15-19; dialogue expansions preserve their purpose, without later revelations.
E('chapter2_departure',[('レン','次の集落へ行こう。道は、あの森の向こうだ。'),('主人公','ああ。塔へ向かう前に、何が起きているか確かめたい。')],{'chapter2Started':True},effects=[{'type':'chapter','value':2},travel('ch2_trail',3,14)])
E('ch2_trail_intro',[('','第2章　声にならない文'),('','森を抜ける風に、人の声がまじっている。聞き取れる単語はあるのに、文のつながりが途切れていた。'),('レン','声は出てる。なのに、何を言いたいのか分からない。'),('主人公','森道を北東へ進もう。人のいる集落が見える。')],{'chapter2Started':True},effects=[{'type':'chapter','value':2}])
E('ch2_arrival',[('','集落には人がいた。挨拶もできる。けれど、頼みたいことや大切な気持ちを言うときだけ、肝心な語が抜けてしまう。'),('家族を待つ住民','迎えに行く子に、まだ……言えていないんです。'),('大工','高い枝に布が引っかかった。道具が……。'),('レン','前後の話を聞けば、抜けた言葉が分かるかもしれない。'),('主人公','広場の三人に話そう。それから中央の古文書室を訪ねてみよう。')],{'ch2Visited':True})
# Resident choices are exploration interactions, not battles. Feedback explains the intent, and permits retries.
d.setdefault('interactions',{})
helps=[('family','家族を待つ住民','帰ってきた娘は、昨日も私の看病をしてくれました。「世話をしてくれて、……」と伝えたいのに。',['ありがとう','急いで','おやすみ','どこへ行くの'],0,'miraHelped','看病してくれた行為に感謝を伝える文脈なので、「ありがとう」が合います。','相手がしてくれたことを思って、気持ちを届ける言葉だ。'),('builder','大工','枝にかかった布を取りたい。届かないから、隣の家のはしごを使わせてもらいたい。「はしごを……」',['直してください','貸してください','捨ててください','片づけました'],1,'builderHelped','届かない場所へ登るため、相手の道具を借りたい場面です。依頼する「貸してください」が合います。','大工は隣へ声をかけ、はしごを借りることができた。'),('messenger','使いの子','川が増水して、いつもの橋は通れない。北の橋なら安全だって聞いた。「今日は北の橋へ……」',['戻ってきた','近づかないで','回って行こう','泳いで渡った'],2,'messengerHelped','いつもの橋を避けて安全な別の橋を使う場面です。「回って行こう」が進路を提案する言葉になります。','使いの子は届け先までの道を決め、手紙を鞄にしまった。')]
for id,name,prompt,choices,answer,flag,explanation,after in helps:
 d['interactions']['help_'+id]={'id':'help_'+id,'name':name,'prompt':prompt,'choices':choices,'answer':answer,'flags':{flag:True},'meaning':'前後の状況から、相手が伝えたいことを補う。','explanation':explanation,'example':prompt.replace('……',choices[answer]),'successPages':[{'speaker':name,'text':choices[answer]+'。……言えた。ありがとう。'},{'speaker':'','text':explanation},{'speaker':'','text':after}],'retryPages':[{'speaker':'レン','text':'誰が、何のために言おうとしているか、もう一度考えよう。'}],'gold':10}
 E('help_'+id,[(name,prompt),('主人公','前後の話から、言いたいことを確かめよう。')],when={flag:False},effects=[{'type':'choice','id':'help_'+id}],once=False)
 E(id+'_repeat',[(name,'言葉を届けられたよ。ありがとう。')],when={flag:True},once=False)
E('ancient_idea',[('','古文書には、欠けずに残った一文がある。'),('','「記録は器。意味は人に宿る」'),('レン','記録に入るものと、人の中にあるものは、同じじゃないのか。'),('主人公','まだ、分からない。ノートにも、何か残っているかもしれない。')],{'ancientRead':True})
E('ancient_repeat',[('','「記録は器。意味は人に宿る」')],when={'ancientRead':True},once=False)
ready={'miraHelped':True,'builderHelped':True,'messengerHelped':True,'ancientRead':True}
E('memory_A_again',[('','ノートの授業ページを開いた瞬間、白い教室が目の前に重なった。'),('アオイ','ほら。どうせまた写し忘れるでしょ。'),('主人公','そんなことないって。'),('アオイ','ちゃんと授業受けてたかテストするから。'),('','授業の終わりの音。ノートを差し出した、アオイの手。'),('主人公','……貸してくれた日のことだ。'),('レン','いま、誰かの声を聞いてた？'),('主人公','覚えていたはずなのに。目の前に戻ってきたみたいだった。もう一度、余白を確かめよう。')],{'memoryAReplayed':True},when=ready)
E('notebook_margin',[('','余白に、小さな人物の落書きがある。髪の形も、眠そうな目も、少し自分に似ていた。'),('主人公','これ、俺か……？'),('','指で触れると、文字が一瞬だけ淡く光った。'),('レン','隣の紙でも、試してみよう。')],{'marginSeen':True},when={'memoryAReplayed':True})
E('ordinary_paper',[('','同じように普通の紙を触っても、何も起こらない。'),('主人公','このノートだけだ。文字が残るのも、いま光ったのも。'),('レン','違いは、何だろう。'),('主人公','分からない。……広場の人は、家族に言葉を届けられただろうか。')],{'ordinaryPaperChecked':True},when={'marginSeen':True})
E('notebook_repeat',[('','アオイの字も、自分の余白のメモも残っている。今は、ノートを大事にしまっておこう。')],when={'marginSeen':True},once=False)
E('family_reply',[('家族を待つ住民','娘に言いました。「世話をしてくれて、ありがとう」って。'),('家族を待つ住民','いつでも言えると思って、ずっと言わずにいたんです。今度は、帰ってきたらすぐ伝えます。'),('','主人公は、転校すると聞いた日の「そっか」を思い出した。'),('主人公','……言えばよかった。'),('レン','何を？'),('主人公','まだ、うまく言えない。でも、言わずにいたことがある。'),('家族を待つ住民','集落の北東の遺構には、文をちぎる獣がいます。言葉を取り戻せば、先へ続く門も開くはずです。')],{'familyWordsReturned':True},when={'miraHelped':True,'memoryAReplayed':True,'marginSeen':True,'ordinaryPaperChecked':True})
E('family_repeat',[('家族を待つ住民','言えるうちに、言いたい相手へ。……北東の道は開いています。')],when={'familyWordsReturned':True},once=False)
E('hollow_ruins',[('','遺構では、文の始まりと終わりが別々の壁に残っていた。その間をつなぐ言葉だけが、抜け落ちている。'),('レン','同じ言葉でも、前後が変われば、意味も変わる。'),('主人公','奥の獣が、つながりを切ってるんだな。')],{'hollowRuinsEntered':True})
E('hollow_beast_appears',[('','空文の獣が、道の先をふさいだ。口元から切れ切れの文がこぼれ、音になる前に消えていく。'),('主人公','前後のつながりを取り戻す。言葉が、相手に届くように。')],effects=[{'type':'battle','encounter':'hollow-beast'}])
E('hollow_beast_freed',[('','途切れていた文が、ゆっくりつながっていく。集落の方から、誰かを呼ぶ声が聞こえた。'),('主人公','言葉があるだけじゃ足りない。何を伝えたいかがないと。'),('レン','アオイに何を伝えたい？'),('主人公','……。'),('','主人公はノートを握り直した。言葉はまだ出てこない。奥の門が、静かに開いた。')],{'hollowBeastDefeated':True})
E('chapter2_clear',[('','第2章　声にならない文　CLEAR'),('','門の向こうには、古い書庫の町へ続く道があった。'),('主人公','アオイ。……帰ったら、ノートを返すだけじゃ、足りないんだよな。'),('レン','答えは、まだ探せる。')],{'chapter2Complete':True})
E('chapter3_not_ready',[('','この先は、第3章「記憶の書庫」。次の制作工程で進めるようになります。')],once=False)
# Original context questions, kept distinct from the master workbook.
q=json.loads((R/'data/questions.json').read_text());q=[x for x in q if not x['id'].startswith('C2Q')]
questions=[('逆接','雨は強かった。（　）、約束の場所へ向かった。',['しかし','だから','つまり','たとえば'],0,'雨が強いことから予想される行動と、実際に向かった行動が反対なので逆接を使います。'),('順接','橋は危険だ。（　）、別の道を使おう。',['ところが','だから','または','それでも'],1,'橋が危険であることを理由に、別の道を使う結論を示します。'),('指示語','レンは扉の模様を指した。それは留め具と同じ形だった。「それ」の指すものは？',['レン','扉の模様','留め具を付ける動作','扉の向こう'],1,'直前に示された「扉の模様」を指します。'),('意図','「窓を閉めてもらえる？」と寒そうに言った。主な意図は？',['相手の能力を試す','窓の数を尋ねる','窓を閉めるよう頼む','窓の歴史を聞く'],2,'疑問の形でも、寒い場面では相手に閉める行動を依頼しています。'),('理由','二人は地図を広げた。道が二つに分かれ、目的地への道が分からなかったからだ。地図を広げた理由は？',['休むため','進む道を確認するため','地図を売るため','紙の色を見るため'],1,'後の文が、地図を広げた行動の理由を説明しています。'),('対比','兄はすぐ決める。一方、妹は何度も確かめる。「一方」の働きは？',['兄妹の行動の違いを示す','同じ行動を言い換える','原因を示す','具体例を一つ加える'],0,'二人の決め方を対照させています。'),('補足','道は細い。しかも、足元は滑りやすい。「しかも」の働きは？',['前の内容を否定する','新しい話題に変える','注意点を付け加える','二つから一つを選ぶ'],2,'細いことに加えて、滑りやすいという注意点を重ねます。'),('例示','記録にはさまざまな形がある。たとえば、日記や手紙だ。後の文は？',['具体例','反対意見','原因','結論の否定'],0,'日記や手紙は、記録の具体的な種類です。'),('言外の意味','重い荷物を持つ友達が「手がもう一本あればな」と言った。求めていることは？',['体を増やしたい','荷物運びを手伝ってほしい','数え方を教えてほしい','荷物を捨てたい'],1,'場面から、運ぶ負担を軽くする手助けを求めていると読めます。'),('言換','「急がなくていい。足元を見て進もう」と言った。近い意味は？',['速さを優先しよう','安全を確かめながら進もう','立ち止まったままでいよう','相手を置いて行こう'],1,'急ぐことより、足元の安全を重視しています。'),('接続','「宿で休む。（　）、先へ進む。」順番を明確にする語は？',['まず','その後','なぜなら','むしろ'],1,'休んでから進むという時間の順序を示します。'),('主語','「少年は本を開き、老人に読んで聞かせた。」読んだのは誰？',['老人','本','少年','文中には示されない'],2,'本を開くことと読むことの主語は、どちらも少年です。')]
for i,(word,prompt,choices,answer,explain) in enumerate(questions,1):q.append({'id':f'C2Q{i:03}','word':word,'meaning':explain,'prompt':prompt,'choices':choices,'answer':answer,'explanation':explain,'example':prompt.replace('（　）',choices[answer]),'category':'文脈・意図','source':'第2章用オリジナル問題。元Excelとは別データ'})
for id,name,asset,hp,attack,secs,exp,gold in [('S2_SHADOW','途切れ文の影','goblin',64,7,13,25,30),('S2_HOLLOW','空文の獣','context_beast',200,10,14,110,140)]:d['enemies'][id]={'id':id,'name':name,'asset':asset,'hp':hp,'attack':attack,'attackSeconds':secs,'exp':exp,'gold':gold,'questionCategories':['文脈・意図']}
d['shops']['voiceless-shop']={'name':'集落の旅道具店','products':[{'id':'I001','type':'item','price':35},{'id':'W003','type':'gear','price':260},{'id':'A001','type':'gear','price':70}]};d['inns']['voiceless-inn']={'name':'集落の宿','price':12}
d['chapters'][2].update(name='声にならない文',implemented=True,scenes=list(range(15,20)))
new=[({'chapter2Complete':True},'第2章CLEAR。第3章「記憶の書庫」は次工程。'),({'hollowBeastDefeated':True},'獣の奥の門を越え、書庫へ続く道へ。'),({'hollowRuinsEntered':True},'遺構の回廊を進み、右奥の空文の獣を倒す。'),({'familyWordsReturned':True},'店・宿で支度し、集落の北東から空文の遺構へ。'),({'ordinaryPaperChecked':True},'広場の家族を待つ住民に、もう一度話そう。'),({'marginSeen':True},'古文書室の左側にある普通の紙を調べよう。'),({'memoryAReplayed':True},'古文書室の右側で、ノートをもう一度調べよう。'),(ready,'古文書室の右側で、アオイのノートを開こう。'),({'miraHelped':True,'builderHelped':True,'messengerHelped':True},'中央の古文書室で、奥の古文書を読もう。'),({'ch2Visited':True},'広場の三人に話し、途切れた言葉を補おう。'),({'chapter2Started':True},'森道を北東へ。声を失った集落へ向かおう。')]
d['objectives']=[{'when':when,'text':text} for when,text in new]+d['objectives'];d['objectives'][len(new)+9]['text']='草原の右下の道を進み、「名のない村へ」の入口へ。Spaceでも入れる。'
(R/'data/maps.json').write_text(json.dumps(maps,ensure_ascii=False,indent=2));(R/'data/game-data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));(R/'data/questions.json').write_text(json.dumps(q,ensure_ascii=False,indent=2));(R/'data/chapter2-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
