"""Chapter5 scenes31–35; canonical dialogue and existing question bank/assets."""
from pathlib import Path
import json,copy,shutil
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
maps=read('maps.json');d=read('game-data.json');sc=read('canonical-scenes.json');events={}
def event(id,pages,flags=None,when=None,effects=None,once=True):
 events[id]=dict(id=id,pages=pages,when=when or {},effects=([dict(type='flags',values=flags)] if flags else [])+(effects or []),once=once)
def text(s,t):return dict(speaker=s,text=t)
def travel(id,x,y,dir='up'):return dict(type='travel',map=id,spawn=dict(x=x,y=y,dir=dir))
def room(id,name,w=26,h=18,inside=False):
 m=dict(id=id,name='第5章・'+name,chapter=5,width=w,height=h,tiles=['floor' if inside else 'grass']*(w*h),collision=[int(x==0 or y==0 or x==w-1 or y==h-1) for y in range(h) for x in range(w)],wallAsset='wall' if inside else 'rock_wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=3,y=h-4,dir='up'));maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,solid=True,ev=None):
 o=dict(id=id,x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,kind='decor',footprint=[dict(x=0,y=0,w=w,h=h)] if solid else [])
 if ev:o.update(events=ev,interactionRect=dict(x=x*32+16-w//2,y=y*32+32-h,w=w,h=h),interactionLabel='記憶を調べる')
 m['objects'].append(o);return o
def portal(m,id,x,y,target,sx,sy,requires=None,kind='path',dir='up'):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir=dir),kind=kind,asset={'path':'stone_arch','door':'gate_door','stairs':'stairs_down'}[kind]);m['portals'].append(p)
 if requires:p.update(requires=requires,lockedPages=['先に、この場所に残る記憶と言葉を確かめよう。'])
 return p
def road(m):
 for y in range(2,m['height']-2):
  for x in range(2,m['width']-2):
   if y in [4,m['height']-4] or x in [3,m['width']-4]:m['tiles'][y*m['width']+x]='path'
def npc(m,id,name,x,y,asset,ev=None,pages=None,when=None,service=None):
 n=dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),events=ev or [],pages=pages or ['相手の話も、自分の気持ちも、ゆっくり考えてみよう。'])
 if when:n['when']=when
 if service:n.update(service=service[0],serviceId=service[1])
 m['npcs'].append(n);return n

# Keep the fourth chapter's terrace; replace only the nonfunctional preview arch.
g=maps['ch4_terrace'];g['objects']=[o for o in g['objects'] if o['id']!='chapter5_route'];g['portals']=[p for p in g['portals'] if p['id']!='gate-chapter5'];portal(g,'gate-chapter5',10,4,'ch5_road',3,14,{'chapter4Complete':True})
r=room('ch5_road','手紙の町への並木道');road(r);r['entryEvents']=['ch5_road_intro'];portal(r,'ch5-road-back',2,14,'ch4_terrace',10,5,dir='down');portal(r,'ch5-road-town',22,4,'ch5_town',3,18)
for k,(x,y) in enumerate([(7,5),(12,6),(17,8),(7,11),(19,14)]):
 o=obj(r,'ch5-tree-'+str(k),x,y,'tree',64,64);o.update(kind='tree',footprint=[dict(x=26,y=48,w=12,h=16)])
roam=dict(type='patrol_chase',chaseRadius=4,leash=6,stepSeconds=.42)
r['enemies']=[dict(id='ch5-road-shadow',enemy='S5_LETTER',x=14,y=13,respawn=True,behavior=roam)]
t=room('ch5_town','手紙の町',32,22);road(t);t['entryEvents']=['ch5_town_intro'];portal(t,'ch5-town-back',2,18,'ch5_road',21,4,dir='left');portal(t,'ch5-town-court',28,4,'ch5_courtyard',3,14,{'ch5NightWritten':True})
def house(m,id,x,y,target,asset='stone_house'):
 size=96 if asset=='building' else 128;side=(size-32)//2;o=obj(m,id,x,y,asset,size,size);o.update(kind='building',footprint=[dict(x=0,y=0,w=size,h=size-32),dict(x=0,y=size-32,w=side,h=32),dict(x=side+32,y=size-32,w=side,h=32)],entrance=dict(x=side,y=size-32,w=32,h=32));portal(m,id+'-door',x,y,target,7,11,kind='door');return o
house(t,'ch5-post-house',9,7,'ch5_post');house(t,'ch5-inn-house',22,7,'ch5_inn','building')
npc(t,'ch5-baker','パン屋',7,13,'villager',pages=['毎朝、窯で丸いパンを焼く。焼き立ての香りを喜んでくれる人がいてね。'],ev=['ch5_baker_received'])
npc(t,'ch5-tailor','仕立屋',17,13,'elderwoman',pages=['針と糸で服を直している。破れた袖も、縫えばまた着られるよ。'],ev=['ch5_tailor_received'])
npc(t,'ch5-ferryman','渡し守',25,16,'merchant',pages=['川向こうへ小舟を出す仕事だ。荷物も、人も、無事に渡す。'],ev=['ch5_ferryman_received'])
npc(t,'ch5-shop','手紙の町の道具屋',12,18,'merchant',service=('shop','letter-shop'))
for y in [8,13]:
 for x in range(3,29):t['tiles'][y*t['width']+x]='path'
for x in [9,22]:
 for y in range(7,19):t['tiles'][y*t['width']+x]='path'
obj(t,'ch5-bench',20,18,'bench',64,32);obj(t,'ch5-plant',4,9,'plant')
post=room('ch5_post','郵便局',18,15,True);post['safeSpawn']=dict(x=7,y=11,dir='up');post['entryEvents']=['ch5_post_intro'];portal(post,'ch5-post-back',7,12,'ch5_town',9,8,kind='door',dir='down')
npc(post,'ch5-postman','郵便人',7,5,'villager',['ch5_letters_report','ch5_post_reminder','ch5_post_ready','ch5_post_delivered'])
for k,x in enumerate([4,8,12]):obj(post,'ch5-letter-'+str(k),x,8,'scroll',ev=['ch5_letter_'+str(k),'ch5_letter_'+str(k)+'_repeat'])['interactionLabel']='宛名の消えた手紙'+str(k+1)+'を調べる'
inn=room('ch5_inn','手紙の町の宿',18,15,True);inn['safeSpawn']=dict(x=7,y=11,dir='up');portal(inn,'ch5-inn-back',7,12,'ch5_town',22,8,kind='door',dir='down');npc(inn,'ch5-innkeeper','宿の人',4,6,'elderwoman',service=('inn','letter-inn'))
obj(inn,'ch5-night-notebook',10,8,'old_book',ev=['ch5_night','ch5_night_wait','ch5_night_repeat'])['interactionLabel']='国語ノートを開く'
c=room('ch5_courtyard','三つの記録の中庭');road(c);c['entryEvents']=['ch5_experiment_intro','ch5_experiment_result'];portal(c,'ch5-court-back',2,14,'ch5_town',27,4,dir='left');portal(c,'ch5-court-archive',22,4,'ch5_archive',7,11,{'ch5ExperimentDone':True},kind='door')
for key,x,y,asset in [('Paper',7,8,'scroll'),('Stone',13,8,'stone_gate'),('Notebook',19,8,'old_book')]:
 obj(c,'ch5-test-'+key,x,y,asset,ev=['ch5_test_'+key,'ch5_test_'+key+'_repeat'])['interactionLabel']={'Paper':'紙','Stone':'石','Notebook':'ノート'}[key]+'の文字を調べる'
ch=obj(c,'ch5-court-chest',8,13,'chest');ch.update(kind='chest',loot=dict(items={'I001':3},gold=80))
a=room('ch5_archive','紋章の記録室',18,15,True);a['safeSpawn']=dict(x=7,y=11,dir='up');a['entryEvents']=['ch5_archive_intro'];portal(a,'ch5-archive-back',7,12,'ch5_courtyard',21,4,kind='door',dir='down');portal(a,'ch5-archive-down',14,4,'ch5_passage',12,15,{'ch5RenMemory':True},kind='stairs')
obj(a,'ch5-emblem',7,6,'stone_gate',ev=['ch5_ren_memory','ch5_ren_memory_repeat'])['interactionLabel']='紋章に触れる'
p=room('ch5_passage','未達の使者の回廊',26,20,True);p['safeSpawn']=dict(x=12,y=15,dir='up');p['entryEvents']=['ch5_passage_intro'];portal(p,'ch5-passage-up',12,17,'ch5_archive',14,5,kind='stairs',dir='down')['asset']='stairs_up';portal(p,'ch5-passage-exit',12,3,'ch5_terrace',10,12,{'ch5LettersDelivered':True},kind='door')
for x in range(1,25):
 if x!=12:p['collision'][8*26+x]=1
p['enemies']=[dict(id='ch5-undelivered-messenger',enemy='S5_MESSENGER',x=12,y=9,introEvent='ch5_messenger_appears',afterEvent='ch5_messenger_freed')]
obj(p,'ch5-side-chest',5,14,'chest').update(kind='chest',loot=dict(items={'I001':2},gold=120))
z=room('ch5_terrace','忘却の街を望む道',22,16);road(z);z['entryEvents']=['chapter5_clear'];portal(z,'ch5-terrace-back',10,13,'ch5_passage',12,4,dir='down');obj(z,'chapter6_route',10,4,'stone_arch',solid=False,ev=['chapter6_not_ready'])['interactionLabel']='次の道を確認する'
for m in [c,a]:
 for o in m['objects']:
  if o['asset']=='stone_gate':o.update(width=96,height=96,anchorX=48,anchorY=96,footprint=[dict(x=32,y=64,w=32,h=32)],interactionRect=dict(x=o['x']*32-32,y=o['y']*32-64,w=96,h=96))
# Clear instructions accompany canonical dialogue; no future truth is revealed.
event('chapter5_departure',[text('','第5章　届かなかった手紙'),text('レン','手紙の町へ行こう。北東の門が、町への入口だ。')],{'chapter5Started':True},{'chapter4Complete':True},[dict(type='chapter',value=5),travel('ch5_road',3,14)])
event('ch5_road_intro',[text('','第5章　届かなかった手紙'),text('','北東の門から手紙の町へ。町の左上の建物が郵便局。')],{'chapter5Started':True},effects=[dict(type='chapter',value=5)])
event('ch5_town_intro',[text('主人公','宛名のない手紙が、町に残っている。'),text('レン','左上の郵便局で、話を聞こう。右上は宿だ。')],{'ch5TownVisited':True})
event('ch5_post_intro',sc['31'][:4]+[text('郵便人','差出人から、届け先を調べるために読んでよいと頼まれた3通なんだ。下の3枚を調べてほしい。'),text('郵便人','町にはパン屋、仕立屋、渡し守がいる。仕事と手紙の内容を照らし合わせて、宛先を選んでくれ。')],{'ch5PostVisited':True})
letters=[('朝早くから窯を温め、焼き立ての丸いパンを分けてくれてありがとう。あの香りが、家族の朝を明るくしました。',0,'パン屋','窯・焼き立て・パンが手掛かり。'),('破れた袖を針と糸で直してくれてありがとう。大切な服を、また着られるようになりました。',1,'仕立屋','袖・針と糸・服を直す仕事が手掛かり。'),('大雨の翌日、私と荷物を小舟で川向こうへ運んでくれてありがとう。無事に家族に会えました。',2,'渡し守','小舟・川向こうへ運ぶ仕事が手掛かり。')]
for k,(body,answer,who,meaning) in enumerate(letters):
 flag='ch5Letter'+str(k);id='ch5_address_'+str(k)
 event('ch5_letter_'+str(k),[text('手紙'+str(k+1),body)],when={flag:False},effects=[dict(type='choice',id=id)],once=False)
 event('ch5_letter_'+str(k)+'_repeat',[text('主人公',who+'宛てだ。'+meaning)],when={flag:True},once=False)
 d['interactions'][id]=dict(id=id,name='手紙'+str(k+1),prompt=body+'\nこの手紙は誰に宛てたもの？',choices=['パン屋','仕立屋','渡し守'],answer=answer,flags={flag:True},meaning=meaning,explanation=meaning,example='',gold=20,successPages=[text('レン',meaning),text('主人公',who+'宛てとして、郵便人に伝えよう。')],retryPages=[text('レン','手紙に書かれた道具と、相手の仕事をもう一度比べよう。')])
ready={'ch5Letter0':True,'ch5Letter1':True,'ch5Letter2':True}
event('ch5_letters_report',[text('郵便人','3通とも宛先が分かった。ありがとう。ただ、北の回廊にいる未達の使者が、手紙を閉じ込めている。'),text('郵便人','今夜は宿で休んでくれ。右上の建物だ。机にノートを置けるよ。')]+sc['31'][5:],{'ch5LettersSorted':True},ready)
event('ch5_post_reminder',[text('郵便人','下の3枚の手紙を調べよう。全部の宛先が分かったら、もう一度私に話しかけて。')],when={'ch5LettersSorted':False},once=False)
event('ch5_post_ready',[text('郵便人','北の回廊の未達の使者を倒せば、3通の手紙を届けられる。右上の宿でノートを開いてから、町の北東の門へ。')],when={'ch5LettersSorted':True,'ch5LettersDelivered':False},once=False)
event('ch5_post_delivered',[text('郵便人','手紙は3人に届いた。ありがとう。町の北東から先へ進めるよ。')],when={'ch5LettersDelivered':True},once=False)
event('ch5_night',sc['32']+[text('','朝になった。町の北東の門から中庭へ。紙・石・ノートに同じ文を書き、残り方を確かめよう。')],{'ch5NightWritten':True}, {'ch5LettersSorted':True},[dict(type='heal')])
event('ch5_night_wait',[text('レン','先に郵便局で3通の宛先を確かめて、郵便人へ報告しよう。')],when={'ch5LettersSorted':False},once=False)
event('ch5_night_repeat',[text('主人公','続きは、まだ書けない。でも、消さない。'),text('レン','町の北東の門から中庭へ。三つの記録を比べよう。')],when={'ch5NightWritten':True},once=False)
event('ch5_experiment_intro',sc['33'][:4]+[text('','西の紙、中央の石、東のノートに「また明日」と書いた。3か所を調べて、異変の後の文字を比べよう。')],{'ch5ExperimentStarted':True})
for key,result in [('Paper','紙の「また明日」は、文字が欠けて読めない。'),('Stone','石には「また」だけが残り、「明日」は欠けている。'),('Notebook','ノートの「また明日」は、一字も欠けていない。')]:
 flag='ch5Checked'+key;event('ch5_test_'+key,[text('主人公',result)],{flag:True});event('ch5_test_'+key+'_repeat',[text('主人公',result)],when={flag:True},once=False)
event('ch5_experiment_result',sc['33'][5:]+[text('レン','北東の扉の先に記録室がある。俺の留め具と同じ紋章を調べたい。')],{'ch5ExperimentDone':True},{'ch5CheckedPaper':True,'ch5CheckedStone':True,'ch5CheckedNotebook':True})
event('ch5_archive_intro',[text('','中央の紋章に、レンの留め具と同じ模様がある。紋章を向いて調べよう。')],{'ch5ArchiveVisited':True})
event('ch5_ren_memory',sc['34']+[text('レン','まだ断片だけだ。奥へ進もう。右上の階段が、未達の使者の回廊につながってる。')],{'ch5RenMemory':True})
event('ch5_ren_memory_repeat',[text('レン','全部は思い出せない。でも、今は手紙を届けよう。右上の階段へ。')],when={'ch5RenMemory':True},once=False)
event('ch5_passage_intro',[text('','中央の道に、未達の使者がいる。倒して、町の手紙を届けよう。北の扉は、その先にある。')],{'ch5PassageVisited':True})
event('ch5_messenger_appears',sc['35'][:2],effects=[dict(type='battle',encounter='ch5-undelivered-messenger')])
event('ch5_messenger_freed',[text('','閉じ込められていた3通の手紙が光になり、パン屋・仕立屋・渡し守へ飛んでいく。')]+sc['35'][3:]+[text('','3通の配達が完了した。北の扉から、忘却の街を望む道へ。町へ戻れば、受け取った人の話も聞ける。')],{'ch5LettersDelivered':True})
for key,who in [('baker','パン屋'),('tailor','仕立屋'),('ferryman','渡し守')]:event('ch5_'+key+'_received',[text(who,'ありがとう、の手紙が届いた。誰かに届くと、言葉はこんなに温かいんだね。')],when={'ch5LettersDelivered':True},once=False)
event('chapter5_clear',[text('','第5章　届かなかった手紙　CLEAR'),text('レン','ここから先は、忘却の街につながっている。')],{'chapter5Complete':True},{'ch5LettersDelivered':True})
event('chapter6_not_ready',[text('','第6章「忘却の街」は次工程で実装します。町で準備したり、冒険の記録を保存できます。')],once=False)
d['chapters'][5]=dict(id=5,name='届かなかった手紙',implemented=True,scenes=list(range(31,36)))
for chapter,mapid,x,y in [(2,'ch2_trail',3,15),(3,'ch3_approach',3,14),(4,'ch4_road',3,14),(5,'ch5_road',3,14)]:d['chapters'][chapter]['entry']=dict(map=mapid,spawn=dict(x=x,y=y,dir='up'))
d['enemies']['S5_LETTER']=dict(id='S5_LETTER',name='迷いの封書',hp=140,attack=11,attackSeconds=14,exp=65,gold=80,asset='archive_wisp',questionCategories=['故事成語','ことわざ','類義語'])
d['enemies']['S5_MESSENGER']=dict(id='S5_MESSENGER',name='未達の使者',hp=380,attack=16,attackSeconds=14,exp=220,gold=300,asset='paraphrase_knight',questionCategories=['故事成語','ことわざ','類義語','対義語'])
d['shops']['letter-shop']=dict(name='手紙の町の道具屋',products=[dict(id='I001',type='item',price=35),dict(id='A002',type='gear',price=180),dict(id='W005',type='gear',price=600)])
d['inns']['letter-inn']=dict(name='手紙の町の宿',price=20)
objectives=[({'chapter5Complete':True},'第5章CLEAR。町で準備・保存できる。第6章は次工程。'),({'ch5LettersDelivered':True},'使者の回廊の北の扉へ。町では手紙を受け取った人に話せる。'),({'ch5RenMemory':True},'記録室の右上の階段から回廊へ。中央の未達の使者を倒そう。'),({'ch5ExperimentDone':True},'中庭の北東の扉から記録室へ。中央の紋章を調べよう。'),({'ch5ExperimentStarted':True},'中庭の西の紙・中央の石・東のノートを3か所とも調べよう。'),({'ch5NightWritten':True},'町の北東の門から中庭へ。三つの記録を比べよう。'),({'ch5LettersSorted':True},'町の右上の宿へ。机の国語ノートを調べよう。'),(ready,'郵便局の郵便人に話しかけ、3通の宛先を報告しよう。'),({'ch5PostVisited':True},'郵便局の下側の手紙3枚を調べ、宛先を選ぼう。'),({'ch5TownVisited':True},'町の左上の郵便局へ。扉は建物の正面中央。'),({'chapter5Started':True},'並木道の北東の門から手紙の町へ。')]
d['objectives']=[dict(when=a,text=b) for a,b in objectives]+[o for o in d['objectives'] if not any(k.startswith('ch5') or k=='chapter5Started' or k=='chapter5Complete' for k in o.get('when',{}))]
for o in d['objectives']:
 if o.get('when')=={'chapter4Complete':True}:o['text']='第4章CLEAR。北の門、またはCLEAR画面のボタンから第5章へ。'
for m in maps.values():
 if m['id'].startswith('ch5') or m['id']=='ch4_terrace':
  for p in m['portals']:
   p['label']=maps[p['target']]['name'].split('・')[-1]+'へ';p['interactionLabel']=p['label']+'移動'
   if p.get('requires'):p['lockedPages']=[{'ch5NightWritten':'郵便局で3通の宛先を報告してから、右上の宿の国語ノートを調べよう。','ch5ExperimentDone':'西の紙・中央の石・東のノートを全部調べよう。','ch5RenMemory':'中央の紋章を調べ、レンの記憶を確かめよう。','ch5LettersDelivered':'中央の未達の使者を倒して、手紙を届けよう。','chapter4Complete':'言換の騎士を倒し、北の道で第4章を終えよう。'}.get(next(iter(p['requires'])),'先に目的を確認しよう。')]
# Optional recovery extends the unchanged KT1 grammar without removing old checkpoints.
d['recovery']['checkpoints']=[cp for cp in d['recovery']['checkpoints'] if cp['chapter']!=5]+[dict(id='C5',label='第5章・並木道',chapter=5,map='ch5_road',x=3,y=14),dict(id='C5E',label='第5章クリア',chapter=5,map='ch5_terrace',x=3,y=12)]
completed={'chapter5Started':True,'chapter5Complete':True,'ch5Letter0':True,'ch5Letter1':True,'ch5Letter2':True}
for ev in events.values():
 if ev.get('once') is not False and ev['id']!='chapter6_not_ready':
  completed['event:'+ev['id']]=True
  for effect in ev['effects']:
   if effect['type']=='flags':completed.update(effect['values'])
d['recovery']['completedFlags']['5']=completed
for name,v in [('maps.json',maps),('game-data.json',d),('chapter5-events.json',events)]: (R/'data'/name).write_text(json.dumps(v,ensure_ascii=False,indent=2))
print('Chapter5: 8 maps, 3 letter missions, scenes31–35; original assets and bank kept')
