"""Regenerate the original 32x32 school clock. Requires Pillow."""
from pathlib import Path
import json
from PIL import Image
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'data/finale-clock.json').read_text())
im=Image.new('RGBA',tuple(d['size']))
im.putdata([tuple(d['palette'][i]) for row in d['rows'] for i in row])
im.save(root/'assets/school_clock_final.png')
