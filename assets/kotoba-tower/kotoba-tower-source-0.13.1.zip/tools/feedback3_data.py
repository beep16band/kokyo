"""Non-destructive question presentation, balance and mandatory patrol data."""
from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
d=read('game-data.json');maps=read('maps.json')
# One authored answer per blank. No borrowed distractors are displayed.
forms={}
variants={'明日':['あす','あした','みょうにち'],'今日':['きょう','こんにち'],'昨日':['きのう','さくじつ'],'博士':['はかせ','はくし'],'一日':['ついたち','いちにち'],'紅葉':['もみじ','こうよう'],'大人':['おとな','だいにん'],'二十歳':['はたち','にじゅっさい','にじっさい']}
for q in read('exam-questions.json'):
 if q['category'] in ['類義語','対義語']:continue
 word=q['word']
 if q['category']=='熟語の読み方':
  answer=q['correctAnswer'];prompt='「'+word+'」の読みを、ひらがなで入力しよう。';accepted=variants.get(word,[answer]);kind='読み入力'
 else:
  # Preserve visible context on both sides when possible; one unambiguous source expression.
  blocks=list(re.finditer(r'[一-龯]+',word))
  block=max(blocks,key=lambda m:len(m.group()),default=None)
  if block:
   start=block.start();end=min(block.end(),start+2)
  else:
   start=max(0,len(word)//2-1);end=min(len(word),start+2)
  answer=word[start:end];cloze=word[:start]+'□'*(end-start)+word[end:]
  prompt='意味：'+q['meaning']+'\n「'+cloze+'」の□に入る文字だけを入力しよう。';accepted=[answer];kind='語句穴埋め'
 forms[q['id']]={'answerFormat':'text','format':kind,'prompt':prompt,'choices':[answer],'answer':0,'correctAnswer':answer,'acceptedAnswers':list(dict.fromkeys([answer,*accepted])),'fullAnswer':word,'preserveChoiceOrder':True}
(R/'data/question-formats.json').write_text(json.dumps(forms,ensure_ascii=False,indent=2)+'\n')
# These values apply to the runtime only. Raw master records remain unchanged.
d['combatBalance']={'S1_BAKRO':dict(hp=70,attack=7,guard=0),'S1_BLOOM':dict(hp=210,attack=12,guard=2),
 'S2_SHADOW':dict(hp=90,attack=12,guard=3),'S2_HOLLOW':dict(hp=300,attack=18,guard=5),
 'S3_WISP':dict(hp=140,attack=17,guard=6),'S3_GUARDIAN':dict(hp=420,attack=26,guard=8),
 'S4_WISP':dict(hp=180,attack=22,guard=8),'S4_SHADOW':dict(hp=240,attack=24,guard=9),'S4_KNIGHT':dict(hp=530,attack=34,guard=12),
 'S5_LETTER':dict(hp=240,attack=27,guard=10),'S5_MESSENGER':dict(hp=650,attack=42,guard=16)}
for id in ['archive-shop','branch-shop','letter-shop']:
 if not any(p['id']=='A003'for p in d['shops'][id]['products']):d['shops'][id]['products'].append(dict(id='A003',type='gear',price=420))
# One fixed, visible sentry at a natural stone divider per approach. It cannot be bypassed.
for mid,enemy in [('ch2_trail','S2_SHADOW'),('ch3_approach','S3_WISP'),('ch4_road','S4_WISP'),('ch5_road','S5_LETTER')]:
 m=maps[mid];x=m['width']//2;y=9
 for xx in range(1,m['width']-1):m['collision'][y*m['width']+xx]=int(xx!=x)
 # Keep the gateway visible and do not place trees across the passage.
 for o in m['objects']:
  if o['kind']=='tree' and abs(o['x']-x)<=1 and abs(o['y']-y)<=2:o['x']=4
 id=mid+'-sentry';m['enemies']=[e for e in m['enemies']if e['id']!=id]
 m['enemies'].append(dict(id=id,enemy=enemy,x=x,y=y,respawn=True))
 for yy in [y-1,y,y+1]:m['tiles'][yy*m['width']+x]='path'
d['maps']=maps
for n in ['maps.json','game-data.json']:(R/'data'/n).write_text(json.dumps(maps if n=='maps.json'else d,ensure_ascii=False,indent=2)+'\n')
print('Input questions:',len(forms),'visible mandatory sentries: 4')
