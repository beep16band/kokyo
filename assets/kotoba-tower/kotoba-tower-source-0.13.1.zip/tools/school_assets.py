from pathlib import Path
from PIL import Image
import numpy as np
from scipy import ndimage
import shutil,json
R=Path(__file__).resolve().parents[1]; A=R/'assets'; ref=R/'reference/school-art';ref.mkdir(parents=True,exist_ok=True)
source=ref
if not list(source.glob('*.png')):
 for p in (R.parent/'generated_images').glob('*.png'):shutil.copy2(p,ref/p.name)
im=Image.open(source/'exec-fbd56053-1fad-4eaa-b751-bc65888b1b6d.png').convert('RGBA')
a=np.array(im);labels,n=ndimage.label(a[:,:,3]>180,structure=np.ones((3,3)));boxes=[]
for sl in ndimage.find_objects(labels):
 y,x=sl
 if x.stop-x.start>40 and y.stop-y.start>100:boxes.append((x.start,y.start,x.stop,y.stop))
assert len(boxes)==36
rows=[sorted([b for b in boxes if ((b[1]+b[3])/2)//209==r]) for r in range(4)]
scale=28/max(b[3]-b[1] for b in boxes)
for ci,name in enumerate(['hero_school','aoi_school','ren_school']):
 out=Image.new('RGBA',(96,128))
 for r in range(4):
  for f in range(3):
   b=rows[r][ci*3+f];crop=im.crop(b);arr=np.array(crop);arr[:,:,3]=np.where(arr[:,:,3]>180,255,0);crop=Image.fromarray(arr)
   w,h=round(crop.width*scale),round(crop.height*scale);crop=crop.resize((w,h),Image.Resampling.NEAREST);out.paste(crop,(f*32+(32-w)//2,r*32+30-h))
 out.save(A/(name+'.png'))
im=Image.open(source/'exec-1bb471ff-b00a-4bbe-9d46-3c51840091f4.png').convert('RGBA')
names=['school_floor','school_hall_floor','school_wall','school_board','school_desk','school_teacher_desk','school_window','school_door','school_shelf','school_reading_table','school_poster','school_lockers','school_bin','school_plant','school_stair','school_teacher']
legacy=R/'reference/legacy-school-assets';legacy.mkdir(exist_ok=True)
for i,name in enumerate(names):
 if (A/(name+'.png')).exists() and not (legacy/(name+'.png')).exists():shutil.copy2(A/(name+'.png'),legacy/(name+'.png'))
 x=i%4;y=i//4;cell=im.crop((round(x*im.width/4),round(y*im.height/4),round((x+1)*im.width/4),round((y+1)*im.height/4)))
 if i<3:
  cell=cell.crop((55,55,285,285)).resize((32,32),Image.Resampling.NEAREST).convert('RGB').convert('RGBA');cell.save(A/(name+'.png'));continue
 arr=np.array(cell);lab,num=ndimage.label(arr[:,:,3]>180,structure=np.ones((3,3)));sizes=np.bincount(lab.ravel());sizes[0]=0;mask=lab==sizes.argmax();yy,xx=np.where(mask);box=(xx.min(),yy.min(),xx.max()+1,yy.max()+1);arr[:,:,3]=np.where(mask,255,0);crop=Image.fromarray(arr).crop(box)
 size=64 if i in [3,8,9,10,14] else 32
 ratio=min((size-2)/crop.width,(size-2)/crop.height);w,h=round(crop.width*ratio),round(crop.height*ratio);crop=crop.resize((w,h),Image.Resampling.NEAREST);out=Image.new('RGBA',(size,size));out.paste(crop,((size-w)//2,size-2-h));out.save(A/(name+'.png'))
# Broad blackboard: repeat the native centre, preserve border and pixel density.
p=Image.open(A/'school_board.png');p=p.crop(p.getbbox());w,h=p.size;out=Image.new('RGBA',(192,64))
for y in range(h):
 for x in range(192):
  sx=x if x<6 else w-(192-x) if x>=186 else 6+(x-6)%(w-12)
  out.putpixel((x,64-h+y),p.getpixel((sx,y)))
out.save(A/'school_board.png')
# Contact sheet at integer pixel scale for visual review.
preview=Image.new('RGBA',(640,512),(37,43,49,255))
for j,name in enumerate(names):
 p=Image.open(A/(name+'.png'));preview.paste(p.resize((128,128),Image.Resampling.NEAREST),((j%5)*128,(j//5)*128),p.resize((128,128),Image.Resampling.NEAREST))
preview.save(R/'docs/school-assets-preview.png')
manifest={'source':'imagegen; original atlases preserved in reference/school-art','tileSize':32,'sprite':{'frame':[32,32],'sheet':[96,128],'rows':['down','left','right','up'],'frames':3,'feetBaseline':30},'exports':[{ 'file':p.name,'size':list(Image.open(p).size)} for p in A.glob('*school*.png')],'scaling':'uniform aspect-preserving nearest neighbour; opacity mask; original sheets retained'}
(R/'docs/school-assets.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
