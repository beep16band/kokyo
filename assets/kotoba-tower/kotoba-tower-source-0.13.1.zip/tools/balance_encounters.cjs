const fs=require('fs'),{Engine}=require('../src/core.js'),d=JSON.parse(fs.readFileSync(__dirname+'/../data/game-data.json')),maps=JSON.parse(fs.readFileSync(__dirname+'/../data/maps.json'));d.maps=maps;const e=new Engine(d,{enemyAI:false});
// No portal/NPC/object changes. Supplemental roaming enemies remove 5-minute grinding waits.
for(const [mid,count,id]of [['ch2_trail',3,'S2_SWIFT'],['ch3_approach',3,'S3_COIN'],['ch4_road',4,'S4_WISP'],['ch4_crossroad',5,'S4_WISP'],['ch5_road',6,'S5_ARMORED'],['ch5_passage',4,'S5_LETTER'],['ch6_road',6,'S6_TANK'],['ch6_overlook',4,'S6_WISP'],['ch7_archive',7,'S7_FRAGMENT'],['ch7_seals',4,'S7_ELITE']]){
 const m=maps[mid];m.enemies=m.enemies.filter(n=>!n.balanceAdded);let added=0;
 for(let y=3;y<m.height-3&&added<count;y+=3)for(let x=3;x<m.width-3&&added<count;x+=3){if(!e.canStand(mid,x,y))continue;if(m.portals.some(p=>Math.abs(p.x-x)+Math.abs(p.y-y)<4)||m.enemies.some(p=>Math.abs(p.x-x)+Math.abs(p.y-y)<4)||m.objects.some(p=>Math.abs(p.x-x)+Math.abs(p.y-y)<3)||m.safeSpawn&&Math.abs(m.safeSpawn.x-x)+Math.abs(m.safeSpawn.y-y)<5)continue;m.enemies.push({id:mid+'-balance-'+added,enemy:id,x,y,respawn:true,balanceAdded:true,behavior:{type:'patrol_chase',chaseRadius:3,leash:3,stepSeconds:.45}});added++;}
 console.log(mid,added+'/'+count);if(added<count)throw Error('Not enough space '+mid);
}
fs.writeFileSync(__dirname+'/../data/maps.json',JSON.stringify(maps,null,2));d.maps=maps;fs.writeFileSync(__dirname+'/../data/game-data.json',JSON.stringify(d,null,2));
