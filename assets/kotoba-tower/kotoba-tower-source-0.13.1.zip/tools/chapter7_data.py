"""Chapter 7: SCENE41–46, existing tile/sprite assets, stable save IDs."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
maps=read('maps.json');d=read('game-data.json');sc=read('canonical-scenes.json');events={}
def text(s,t):return dict(speaker=s,text=t)
def event(id,pages,flags=None,when=None,effects=None,once=True):
 events[id]=dict(id=id,pages=pages,when=when or {},effects=([dict(type='flags',values=flags)]if flags else [])+(effects or []),once=once)
def travel(mid,x,y):return dict(type='travel',map=mid,spawn=dict(x=x,y=y,dir='up'))
def room(id,name,w=26,h=20):
 m=dict(id=id,name='第7章・'+name,chapter=7,width=w,height=h,tiles=['floor']*(w*h),collision=[int(x==0 or y==0 or x==w-1 or y==h-1)for y in range(h)for x in range(w)],wallAsset='wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=12,y=h-4,dir='up'));maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,ev=None,solid=True):
 o=dict(id=id,x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,kind='decor',footprint=[dict(x=0,y=0,w=w,h=h)]if solid else [])
 if ev:o.update(events=ev,interactionRect=dict(x=x*32+16-w//2,y=y*32+32-h,w=w,h=h),interactionLabel='塔に残された記録を読む')
 m['objects'].append(o);return o
def portal(m,id,x,y,target,sx,sy,requires=None,kind='stairs',dir='up',label=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir=dir),kind=kind,asset='stairs_up' if kind=='stairs'and dir=='up'else 'stairs_down'if kind=='stairs'else 'stone_arch',label=label or maps[target]['name'],interactionLabel=(label or maps[target]['name'])+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['まだ封鎖されている。「目的」で未確認の記録を確かめよう。'])
 m['portals'].append(p);return p
def npc(m,id,name,x,y,asset,service=None,pages=None):
 n=dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),pages=pages or ['記録は器。意味は人に宿る。'])
 if service:n.update(service=service[0],serviceId=service[1])
 m['npcs'].append(n);return n
def divider(m,y,gap):
 for x in range(1,m['width']-1):m['collision'][y*m['width']+x]=int(x!=gap)
# Each floor has a clear north stair / south return stair. Records are off the walking aisle.
a=room('ch7_archive','保存された言葉の広間');a['entryEvents']=['ch7_archive_intro']
r=room('ch7_refuge','継承者の休憩室',20,16);r['safeSpawn']=dict(x=9,y=12,dir='up')
c=room('ch7_control','管理記録の間');c['entryEvents']=['ch7_control_intro']
s=room('ch7_seals','封鎖された回廊',30,22);s['safeSpawn']=dict(x=14,y=18,dir='up');s['entryEvents']=['ch7_seals_intro']
n=room('ch7_ren_record','レンの記録領域');n['entryEvents']=['ch7_ren_intro']
p=room('ch7_ren_projection','切り離された昨日',20,16);p.update(memory=True,hideHero=True,entryEvents=['ch7_ren_scene']);p['safeSpawn']=dict(x=9,y=12,dir='up')
aoi=room('ch7_aoi_record','共有されたノートの記録');aoi['entryEvents']=['ch7_aoi_intro']
u=room('ch7_final_door','最終階への扉');u['entryEvents']=['ch7_final_scene']
old=maps['ch6_terrace'];old['objects']=[o for o in old['objects']if o['id']!='chapter7_route'];old['portals']=[p for p in old['portals']if p['id']!='gate-chapter7'];portal(old,'gate-chapter7',10,4,'ch7_archive',12,16,{'chapter6Complete':True},kind='path',label='塔の内部へ')
portal(a,'ch7-archive-back',12,17,'ch6_terrace',10,5,kind='path',dir='down',label='塔の外へ戻る')
portal(a,'ch7-archive-refuge',4,14,'ch7_refuge',9,12,kind='path',label='休憩室へ')
portal(a,'ch7-archive-control',12,3,'ch7_control',12,16,{'ch7ArchiveKnown':True},label='管理記録の間へ')
for x in [5,9,17,21]:
 for y in [5,9]:obj(a,'ch7-stack-'+str(x)+'-'+str(y),x,y,'old_book',ev=['ch7_saved_words'])
obj(a,'ch7-optional-paper',20,13,'scroll',ev=['ch7_side_source','ch7_side_source_repeat'])['interactionLabel']='保存された手紙の控えを読む'
portal(r,'ch7-refuge-back',9,13,'ch7_archive',4,15,kind='path',dir='down',label='言葉の広間へ戻る')
npc(r,'ch7-rest','記録を守る係',4,6,'elderwoman',('inn','tower-refuge'),['上の階には封鎖を守る魔物がいる。ここで休んでから行きなさい。'])
npc(r,'ch7-shop','継承者の道具係',14,6,'merchant',('shop','tower-shop'))
obj(r,'ch7-copy-desk',10,7,'old_book',ev=['ch7_side_copy','ch7_side_copy_repeat'])['interactionLabel']='手紙の控えを返却箱へ残す'
portal(c,'ch7-control-back',12,17,'ch7_archive',12,4,dir='down',label='言葉の広間へ戻る')
portal(c,'ch7-control-seals',12,3,'ch7_seals',14,18,{'ch7LogosHeard':True},label='封鎖された回廊へ')['lockedPages']=['中央の管理記録を読み、その北の紋章で管理者の応答を確かめよう。']
obj(c,'ch7-purpose-record',8,10,'stone_tablet_v2',64,64,['ch7_purpose','ch7_purpose_repeat'])['interactionLabel']='塔が作られた目的を読む'
obj(c,'ch7-logos-wall',17,6,'emblem_wall_v2',128,128,['ch7_logos','ch7_logos_repeat','ch7_logos_locked'])['interactionLabel']='ロゴスの応答を読む'
obj(c,'ch7-control-cache',20,14,'chest').update(kind='chest',loot=dict(items={'I001':4},gold=220))
portal(s,'ch7-seals-back',14,19,'ch7_control',12,4,dir='down',label='管理記録の間へ戻る')
portal(s,'ch7-seals-ren',14,3,'ch7_ren_record',12,16,{'ch7SealReturn':True,'ch7SealMeaning':True,'ch7SealGuardDefeated':True},label='レンの記録領域へ')['lockedPages']=['西と東の封鎖記録を読み、中央の守衛を倒すと北の階段が開く。']
obj(s,'ch7-seal-west',7,14,'stone_tablet_v2',64,64,['ch7_seal_return','ch7_seal_return_repeat'])['interactionLabel']='西の封鎖：記録を返す目的を確かめる'
obj(s,'ch7-seal-east',22,14,'stone_tablet_v2',64,64,['ch7_seal_meaning','ch7_seal_meaning_repeat'])['interactionLabel']='東の封鎖：意味の在りかを確かめる'
divider(s,9,14)
s['enemies']=[dict(id='ch7-seal-guardian',enemy='S7_GUARD',x=14,y=10,introEvent='ch7_guard_appears',afterEvent='ch7_guard_freed'),dict(id='ch7-seal-roamer',enemy='S7_FRAGMENT',x=24,y=17,respawn=True,behavior=dict(type='patrol_chase',chaseRadius=3,leash=4,stepSeconds=.45))]
portal(n,'ch7-ren-back',12,17,'ch7_seals',14,4,dir='down',label='封鎖された回廊へ戻る')
portal(n,'ch7-ren-aoi',12,3,'ch7_aoi_record',12,16,{'ch7RenRemembered':True},label='ノートの記録へ')['lockedPages']=['中央の古い記録を調べ、レンの昨日を確かめよう。']
obj(n,'ch7-ren-memory',12,9,'old_book',ev=['ch7_ren_projection','ch7_ren_repeat'])['interactionLabel']='切り離されたレンの記録を見る'
npc(p,'ch7-memory-ren','レン（記憶）',9,6,'ren_pipoya_student');obj(p,'ch7-memory-emblem',9,4,'emblem_wall_v2',128,128)
portal(aoi,'ch7-aoi-back',12,17,'ch7_ren_record',12,4,dir='down',label='レンの記録領域へ戻る')
portal(aoi,'ch7-aoi-upper',12,3,'ch7_final_door',12,16,{'ch7NotebookKnown':True},label='最終階への扉へ')['lockedPages']=['中央のノートを調べ、アオイの記録状態を確かめよう。']
obj(aoi,'ch7-aoi-notebook',12,10,'old_book',ev=['ch7_aoi','ch7_aoi_repeat'])['interactionLabel']='アオイと共有したノートを調べる'
npc(aoi,'ch7-aoi-image','アオイ（記録映像）',18,7,'aoi_pipoya_student',pages=['記録映像には、主人公の名を思い出せないアオイが映っている。'])
obj(aoi,'ch7-aoi-cache',5,13,'chest').update(kind='chest',loot=dict(items={'I001':5},gold=320))
portal(u,'ch7-upper-back',12,17,'ch7_aoi_record',12,4,dir='down',label='ノートの記録へ戻る')
obj(u,'chapter8_route',12,4,'stone_arch',64,64,['chapter8_not_ready'])['interactionLabel']='最終階への扉を確認する'
event('chapter7_departure',[text('','第7章　ことばの継承者'),text('レン','塔の中に入ろう。残っている言葉を、自分たちの目で確かめる。')],{'chapter7Started':True},{'chapter6Complete':True},[dict(type='chapter',value=7),travel('ch7_archive',12,16)])
event('ch7_archive_intro',sc['41']+[text('レン','北の階段から管理記録へ。左下には休憩室がある。')],{'chapter7Started':True,'ch7ArchiveKnown':True},effects=[dict(type='chapter',value=7)])
event('ch7_saved_words',[text('記録','村の名前、届かなかった手紙、言い回し。失われたと思っていた言葉が、読める形で並んでいる。'),text('主人公','残っている。でも、持ち主には届いていない。')],once=False)
event('ch7_control_intro',[text('レン','西の石碑に塔の目的、北東の紋章に管理者の応答が残っている。順に読もう。')])
event('ch7_purpose',sc['42']+[text('レン','北東の紋章から、ロゴスの応答を確かめよう。')],{'ch7PurposeRead':True})
event('ch7_purpose_repeat',[text('記録','失われゆく言葉を記録し、次代へ返す。記録は器。意味は人に宿る。')],when={'ch7PurposeRead':True},once=False)
event('ch7_logos',sc['43']+[text('レン','北の回廊に二つの封鎖記録がある。記録に残る言葉から、塔の役割を確かめよう。')],{'ch7LogosHeard':True},{'ch7PurposeRead':True})
event('ch7_logos_repeat',[text('ロゴス','最終管理層へのアクセスを拒否する。'),text('レン','西と東の封鎖、それから中央の守衛だ。休憩室へ戻って準備もできる。')],when={'ch7LogosHeard':True},once=False)
event('ch7_logos_locked',[text('レン','応答がない。先に西の管理記録で、塔の目的を確かめよう。')],when={'ch7PurposeRead':False},once=False)
event('ch7_seals_intro',[text('記録','西の石碑は「返す目的」。東の石碑は「意味の在りか」。'),text('レン','二つを確認して、中央の守衛を越えよう。北の階段はレンの記録領域へ続く。')])
for key,flag,xname,prompt,choices,answer,meaning in [
 ('return','ch7SealReturn','西の封鎖記録','塔の本来の役割は？ 管理記録には「失われゆく言葉を記録し、次代へ返す」とある。',['人から奪って閉じ込める','失われる言葉を記録し、次代へ返す','間違った言葉をすべて壊す'],1,'保存だけでなく、次代へ返すために作られた。'),
 ('meaning','ch7SealMeaning','東の封鎖記録','「記録は器。意味は人に宿る。」 意味が宿るのはどこ？',['塔の石壁だけ','記録の文字だけ','その言葉を使い、受け取る人'],2,'意味は、言葉を使う人と受け取る人の間で生まれる。')]:
 event('ch7_seal_'+key,[text('記録',prompt)],when={flag:False},effects=[dict(type='choice',id='ch7_seal_'+key+'_choice')],once=False)
 event('ch7_seal_'+key+'_repeat',[text('記録','確認済み。'+meaning)],when={flag:True},once=False)
 d['interactions']['ch7_seal_'+key+'_choice']=dict(id='ch7_seal_'+key+'_choice',name=xname,prompt=prompt,choices=choices,answer=answer,flags={flag:True},successPages=[text('記録',meaning),text('','石碑に刻まれた封鎖の文字が消えた。')],retryPages=[text('レン','管理記録の言葉と、もう一度照らし合わせよう。')],meaning=meaning,explanation=meaning,example='',gold=0)
event('ch7_guard_appears',[text('封鎖の守衛','未認証の記録閲覧を拒否する。'),text('レン','記録は壊すな。封鎖だけを解く。')],effects=[dict(type='battle',encounter='ch7-seal-guardian')])
event('ch7_guard_freed',[text('','守衛の封鎖が解除された。記録そのものは残っている。'),text('レン','西と東の確認が済んだら、北の階段へ。')],{'ch7SealGuardDefeated':True})
event('ch7_ren_intro',[text('レン','……この部屋、見覚えがある。中央の記録を見せてくれ。')])
event('ch7_ren_projection',[text('','紋章がレンの留め具に反応し、切り離された記録が開く。')],when={'ch7RenRemembered':False},effects=[travel('ch7_ren_projection',9,12)],once=False)
event('ch7_ren_scene',sc['44'],{'ch7RenRemembered':True},effects=[travel('ch7_ren_record',12,10)])
event('ch7_ren_repeat',[text('レン','昨日を取り戻しても、お前とここまで来たことは消えない。次は、アオイの記録を確かめよう。')],when={'ch7RenRemembered':True},once=False)
event('ch7_aoi_intro',[text('','ノートの向こうに、アオイの記録映像が映る。中央のノートを調べよう。')])
event('ch7_aoi',sc['45']+[text('レン','北の階段が開いた。最終階への扉へ行こう。')],{'ch7NotebookKnown':True},{'ch7RenRemembered':True})
event('ch7_aoi_repeat',[text('主人公','アオイが書いて、俺が受け取って、俺も書いた。返しに行く。')],when={'ch7NotebookKnown':True},once=False)
event('ch7_final_scene',sc['46']+[text('','第7章　ことばの継承者　CLEAR')],{'chapter7Complete':True},{'ch7NotebookKnown':True})
event('chapter8_not_ready',[text('','第8章「最終階 ― 言葉とは何だ ―」は次工程です。ここまでの記録を保存してください。')],once=False)
event('ch7_side_source',[text('手紙の控え','村で名前を忘れた夫婦が、互いの名を書き直した手紙。宛先と差出人がそろっている。'),text('レン','休憩室の返却箱へ控えを残せば、あとから来る人も読める。')],{'ch7SideSourceRead':True})
event('ch7_side_source_repeat',[text('手紙の控え','休憩室の返却箱へ、宛先と差出人を残そう。')],when={'ch7SideSourceRead':True},once=False)
event('ch7_side_copy',[text('','手紙の控えを返却箱に残した。持ち主へ返すための記録が一つ増えた。'),text('記録係','ありがとう。冒険の足しにしておくれ。')],{'ch7SideCopyDone':True},{'ch7SideSourceRead':True},[dict(type='gold',amount=200)])
event('ch7_side_copy_repeat',[text('記録係','控えは残っている。もう写し直す必要はないよ。')],when={'ch7SideCopyDone':True},once=False)
# Dormant previous next-stage notice retained for old event IDs, no longer wired to the map.
d['enemies']['S7_FRAGMENT']=dict(id='S7_FRAGMENT',name='閉じた言葉の影',hp=330,attack=35,guard=14,attackSeconds=14,exp=130,gold=150,asset='archive_wisp',questionCategories=['慣用句','ことわざ','故事成語','類義語','対義語'])
d['enemies']['S7_GUARD']=dict(id='S7_GUARD',name='封鎖の守衛',hp=680,attack=46,guard=17,attackSeconds=14,exp=380,gold=480,asset='archive_guardian',questionCategories=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語'])
d['shops']['tower-shop']=dict(name='継承者の道具係',products=[dict(id='I001',type='item',price=35),dict(id='W005',type='gear',price=650),dict(id='A004',type='gear',price=850)])
d['inns']['tower-refuge']=dict(name='継承者の休憩室',price=30)
d['chapters'][7]=dict(id=7,implemented=True,name='ことばの継承者',scenes=list(range(41,47)),entry=dict(map='ch7_archive',spawn=dict(x=12,y=16,dir='up')))
# Earlier CLEAR objectives must stop taking precedence once a later chapter starts.
for o in d['objectives']:
 if o.get('when',{}).get('chapter6Complete'):o['when']['chapter7Started']=False
objectives=[({'chapter7Started':True,'ch7ArchiveKnown':False},'塔に残された言葉を確認し、北の管理記録の間へ。'),({'ch7ArchiveKnown':True,'ch7PurposeRead':False},'北の階段へ。管理記録の間の西の石碑で、塔の本来の目的を読もう。'),({'ch7PurposeRead':True,'ch7LogosHeard':False},'管理記録の間の北東の紋章を調べ、ロゴスの応答を読む。'),({'ch7LogosHeard':True,'ch7RenRemembered':False},'北の回廊へ。西・東の封鎖記録を確認し、中央の守衛を倒してレンの記録領域へ。'),({'ch7RenRemembered':True,'ch7NotebookKnown':False},'レンの記録領域の北階段から、共有されたノートを調べよう。'),({'ch7NotebookKnown':True,'chapter7Complete':False},'ノートの記録の北階段から、最終階への扉へ。'),({'chapter7Complete':True},'第7章CLEAR。記録ファイルを保存し、第8章の公開を待とう。')]
d['objectives']=[o for o in d['objectives']if not any(k.startswith('ch7')or k=='chapter7Started'for k in o.get('when',{}))]
d['objectives'][:0]=[dict(when=w,text=t)for w,t in objectives]
d['recovery']['checkpoints']=[cp for cp in d['recovery']['checkpoints']if cp['chapter']!=7]+[dict(id='C7',label='第7章・塔の言葉の広間',chapter=7,map='ch7_archive',x=12,y=16),dict(id='C7E',label='第7章クリア',chapter=7,map='ch7_final_door',x=12,y=16)]
completed={'chapter7Started':True,'chapter7Complete':True,'ch7SealReturn':True,'ch7SealMeaning':True}
for e in events.values():
 if e['once'] is not False:
  completed['event:'+e['id']]=True
  for f in e['effects']:
   if f['type']=='flags':completed.update(f['values'])
d['recovery']['completedFlags']['7']=completed
d['maps']=maps
for name,v in [('maps.json',maps),('game-data.json',d),('chapter7-events.json',events)]:(R/'data'/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print('Chapter7: 8 maps, SCENE41–46, two seals, guardian, memories, save-compatible')
