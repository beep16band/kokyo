from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];p=R/'data/maps.json';maps=json.loads(p.read_text())
# The original dividing wall has exactly one opening: tile15,10.
maps['ch1_underground']['enemies'][0].update(x=15,y=10)
extra={'ch1_meadow':[('meadow-bat-patrol','S1_BAT',11,10),('meadow-hound-patrol','S1_HOUND',24,11)],'ch1_garden':[('garden-hound-patrol','S1_HOUND',11,18)],'ch2_trail':[('ch2-trail-shadow-patrol','S2_SHADOW',16,11)],'ch2_ruins':[('ch2-ruins-shadow-patrol','S2_SHADOW',15,15)],'ch3_approach':[('ch3-road-wisp-patrol','S3_WISP',17,11)],'ch3_vault':[('ch3-vault-wisp-patrol','S3_WISP',23,14)],'ch4_road':[('ch4-road-wisp-patrol','S4_WISP',12,11)]}
for id,entries in extra.items():
 for eid,enemy,x,y in entries:
  if not any(e['id']==eid for e in maps[id]['enemies']):maps[id]['enemies'].append(dict(id=eid,enemy=enemy,x=x,y=y,respawn=True))
for m in maps.values():
 for e in m['enemies']:
  if e.get('respawn') and not e.get('afterEvent'):e['behavior']=dict(type='patrol_chase',stepSeconds=.42,chaseRadius=4,leash=6)
p.write_text(json.dumps(maps,ensure_ascii=False,indent=2));print('8 regular enemies added; patrol/chase for respawning enemies; Bakro15,10')
