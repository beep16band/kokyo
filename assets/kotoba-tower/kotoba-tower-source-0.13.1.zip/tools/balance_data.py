"""Independent RPG growth and economy, derived from correct-answer targets."""
import json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1]
d=json.loads((R/'data/game-data.json').read_text());maps=json.loads((R/'data/maps.json').read_text());old=json.loads((R/'reference/before_balance/game-data.json').read_text())
growth=[]
for L in range(1,100):
 n=L-1;growth.append(dict(level=L,hp=round(48+6*n+.5*n*n),strength=round(10+3*n+.15*n*n),defense=round(3+1.5*n+.06*n*n),nextExp=20+8*L+3*L*L))
weapons=[('W001',4,1,60),('W002',8,2,100),('W003',14,4,210),('W004',22,6,400),('W005',32,8,850),('W007',44,10,1350),('W009',60,12,2050),('W010',75,14,2800)]
armors=[('A001',6,0,1,65),('A002',12,5,4,170),('A003',20,8,6,360),('A004',30,12,8,750),('A006',42,16,10,1150),('A007',56,20,12,1750),('A008',72,25,14,2400)]
for k,attack,L,price in weapons:d['equipment'][k].update(attack=attack,攻撃=attack,requiredLevel=L,必要Lv=L,買値=price)
for k,defense,hp,L,price in armors:d['equipment'][k].update(defense=defense,防御=defense,HP=hp,requiredLevel=L,必要Lv=L,買値=price)
# Keep alternative equipment meaningful without promising dormant special effects.
for k,attack,L in [('W006',30,8),('W008',40,10)]:d['equipment'][k].update(attack=attack,攻撃=attack,requiredLevel=L,必要Lv=L)
d['equipment']['A005'].update(defense=38,防御=38,requiredLevel=10,必要Lv=10)
chapters=[]
gear=[('W002','A001'),('W003','A002'),('W004','A003'),('W005','A004'),('W007','A006'),('W009','A007'),('W010','A008')]
normalXP=[16,25,40,35,55,75,95];bossXP=[50,60,120,180,240,350,500];gold=[18,28,50,110,160,230,310]
for c in range(1,9):
 start=1 if c==1 else 2*c;end=4 if c==1 else 2*c+2;w,a=gear[min(c-1,6)]
 chapters.append(dict(chapter=c,startLevel=start,endLevel=end,bossLevel=end-1,weapon=w,armor=a,normalBattles=6 if c==1 else 8 if c<4 else 12,bossBattles=2 if c==1 else 1,requiredExp=sum(growth[l-1]['nextExp']for l in range(start,end)),normalExp=normalXP[min(c-1,6)],bossExp=bossXP[min(c-1,6)],implemented=c<=7))
def meanD(atk,df):return max(2,1.25*atk-.5*df)
balance={}
def enemy(id,c,hits=3,role='balanced',boss=False,damageRatio=.15,seconds=12):
 ref=chapters[c-1];L=ref['bossLevel']if boss else (2 if c==1 else ref['startLevel']+1);g=growth[L-1];w=ref['weapon'];a=ref['armor'];defense=round(4+3*c+(8 if role=='armored'else 0));strength=g['strength']+d['equipment'][w]['attack']+2
 hp=round(meanD(strength,defense)*(hits-.25 if not boss and hits<=4 else hits-.15));pdef=g['defense']+d['equipment'][a]['防御'];maxhp=g['hp']+d['equipment'][a]['HP'];attack=round((maxhp*damageRatio+.5*pdef)/1.25)
 balance[id]=dict(hp=hp,attack=attack,defense=defense,guard=defense,attackSeconds=seconds,exp=bossXP[c-1]if boss else normalXP[c-1],gold=gold[c-1]*(4 if boss else 1),role=role,recommendedLevel=L,rank='boss'if boss else 'strong'if hits>4 else 'normal',enrageAt=.5 if boss and c>=2 else 0,enrageAttack=1.08,enrageSpeed=.82)
# No adaptive scaling: fixed enemies reward preparation and revisiting earlier chapters.
enemy('E001',1,2,damageRatio=.10,seconds=13)
enemy('S1_BAT',1,2,'swift',damageRatio=.11,seconds=9)
enemy('S1_HOUND',1,3,'striker',damageRatio=.18,seconds=12)
enemy('S1_GOBLIN',1,4,'armored',damageRatio=.13,seconds=15)
enemy('S1_BAKRO',1,6,'miniboss',damageRatio=.12,seconds=16);balance['S1_BAKRO'].update(exp=22,gold=30,rank='miniboss')
enemy('S1_BLOOM',1,11,'chapter-boss',True,.13,16)
for c,normal,boss in [(2,'S2_SHADOW','S2_HOLLOW'),(3,'S3_WISP','S3_GUARDIAN'),(4,'S4_WISP','S4_KNIGHT'),(5,'S5_LETTER','S5_MESSENGER'),(6,'S6_WISP','S6_KING'),(7,'S7_FRAGMENT','S7_GUARD')]:
 enemy(normal,c,3,'swift'if c in [3,6]else 'balanced',damageRatio=.15,seconds=10 if c in [3,6]else 13)
 enemy(boss,c,12 if c<4 else 14,'chapter-boss',True,.105 if c<4 else .09,16 if c<4 else 17)
enemy('S4_SHADOW',4,6,'elite',damageRatio=.16,seconds=14);balance['S4_SHADOW'].update(exp=90,gold=105)
# Distinct optional roles use existing images and question categories.
for base,id,c,role,hits,ratio,sec in [('S2_SHADOW','S2_SWIFT',2,'swift',2,.19,9),('S3_WISP','S3_COIN',3,'gold',3,.12,15),('S5_LETTER','S5_ARMORED',5,'armored',4,.14,15),('S6_WISP','S6_TANK',6,'tank',4,.11,17),('S7_FRAGMENT','S7_ELITE',7,'elite',6,.16,13)]:
 d['enemies'][id]={**d['enemies'][base],'id':id,'name':{'swift':'早口の影','gold':'金文字の灯','armored':'封じられた手紙','tank':'重なる名の影','elite':'継承を閉ざす影'}[role]};enemy(id,c,hits,role,damageRatio=ratio,seconds=sec)
 if role=='gold':balance[id]['gold']*=3;balance[id]['exp']=30
 if role=='elite':balance[id]['exp']=130;balance[id]['gold']=200
for k,v in balance.items():d['enemies'][k].update(v)
d['combatBalance']=balance
shops=['nameless-shop','voiceless-shop','archive-shop','branch-shop','letter-shop','forgotten-shop','tower-shop']
for c,shop in enumerate(shops,1):
 w,a=gear[c-1];ids=list(dict.fromkeys([w,a]+([gear[c-2][0],gear[c-2][1]]if c>1 else [])))
 d['shops'][shop]['products']=[dict(id='I001',type='item',price=20+5*(c-1))]+[dict(id=k,type='gear',price=d['equipment'][k]['買値'])for k in ids]
d['items']['I001'].update(healBase=40,healRatio=.15,効果='HPを40＋最大HPの15%回復',買値=20)
d['balance']=dict(revision=1,version='0.10.0',growth=growth,chapters=chapters,damage=dict(attackFactor=1.25,defenseFactor=.5,variance=.06,minimum=2),potion=dict(base=40,ratio=.15),sources=[dict(title='Daniel Achterman: The Craft of Game Systems',url='https://www.gamedeveloper.com/design/the-craft-of-game-systems-powerful-flexible-systems'),dict(title='Official RPG Maker: Ways to Make Luck Matter',url='https://www.rpgmakerweb.com/blog/ways-to-make-luck-matter'),dict(title='Official RPG Maker MZ: Class Settings / EXP & Parameter Curves',url='https://rpgmakerofficial.com/product/MZ_help-en/01_08_02.html')])
# Audit preserves all original data, including dormant source parameters.
audit=dict(version='0.9.0',hp='60+5*(Lv-1)',strength='12+2*(Lv-1)',playerDamage='max(1,strength+weapon.attack+(Ren?2:0)-enemy.guard)',enemyDamage='max(1,enemy.attack-armor.防御)',exp='floor(22+13*Lv+3*Lv^1.55)',potion=30,attack='countdown; wrong counterattack; correct keeps remaining; explanation pause',unused=['装備HP補正','武器以外の攻撃補正','防具以外の防御補正','MP','素早さ','会心/回避','特殊効果のテキスト（自動発動なし）'],enemies={k:{**v,**old.get('combatBalance',{}).get(k,{})}for k,v in old['enemies'].items()if k in balance},shops=old['shops'],placements={m['id']:m['enemies']for m in old['maps'].values()},equipment=old['equipment'])
(R/'docs/balance-current-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
(R/'data/game-data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(R/'data/balance.json').write_text(json.dumps(d['balance'],ensure_ascii=False,indent=2)+'\n')
print('Growth1–99; final target18; seven equipment tiers; fixed role-based enemies')
