"""Prepare Part 2 data without activating scenes, maps, shops, or equipment.
Requires python-docx/openpyxl only for source auditing; runtime/build are stdlib.
"""
from pathlib import Path
import json,re,hashlib,math
from docx import Document
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parents[1]
UPLOAD=ROOT.parent/'upload'
def save(path,value):
    (ROOT/path).write_text(json.dumps(value,ensure_ascii=False,indent=2))
data=json.loads((ROOT/'data/game-data.json').read_text())
source=UPLOAD/'コトバの塔_第2部_失われた明日_全会話シナリオ正本(1).docx'
doc=Document(source)
scenes={};scene=None;chapter=None;chapter_scenes={};titles={}
for line,p in enumerate(doc.paragraphs):
    t=p.text.strip()
    m=re.fullmatch(r'第(\d+)章\s+(.+)',t)
    if m:chapter=int(m[1]);titles[chapter]=m[2]
    m=re.fullmatch(r'SCENE\s+(\d+)\s+(.+)',t)
    if m:
        scene=int(m[1]);scenes[str(scene)]={'title':m[2],'chapter':chapter,'entries':[]}
        if chapter:chapter_scenes.setdefault(chapter,[]).append(scene)
        continue
    if scene and t:
        spoken=re.fullmatch(r'([^「]+)「(.*)」',t)
        scenes[str(scene)]['entries'].append({'sourceLine':line,'text':spoken[2] if spoken else t,'speaker':spoken[1] if spoken else None})
assert set(map(int,scenes))==set(range(61,93))
save('data/part2-canonical-scenes.json',{'source':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scenes':scenes,'activation':'not implemented'})
defaults={'revision':1,'part':1,'phase':'part1','controlledActor':'hero','afterStory':{'started':False,'completed':False},'cores':{'name':False,'promise':False,'memory':False,'tomorrow':False},'absorption':{'count':0,'stage':0},'aoiJoined':False,'trueEnd':False}
bounds=[(9,18,20,12,1,500),(10,20,28,52,4,800),(11,28,30,12,1,1200),(12,30,32,16,1,1800),(13,32,33,8,1,1600),(14,33,35,12,1,2400)]
levels=data['balance']['growth'];plans=[]
for c,start,end,n,b,bexp in bounds:
    required=sum(levels[l-1]['nextExp'] for l in range(start,end))
    plans.append({'chapter':c,'title':titles[c],'scenes':chapter_scenes[c],'implemented':False,'startLevel':start,'endLevel':end,'normalBattles':n,'majorBattles':b,'requiredExp':required,'majorExp':bexp,'normalExp':math.ceil((required-b*bexp)/n),'note':'Planning budget only. No enemies spawned or XP granted. Actual entry Lv is inherited.'})
growth=[dict(x) for x in levels[17:35]]
config={'revision':1,'version':'0.12.0','title':'失われた明日 ― レンを取り戻す旅 ―','maxChapter':14,'targetFinalLevel':35,'forceEntryLevel':False,'implemented':False,'afterStory':{'implemented':False,'scenes':[61,62,63,64],'entryMap':None,'nextStage':3},'defaults':defaults,'chapters':plans,'growth':growth,'visualPlan':{'method':'purple light/shadow/particles, not a global tint','stages':[0,1,2,3,4],'trueEndRestoresPalette':True},'savePolicy':{'key':'kotoba-tower-complete-stage6-v1','formatVersion':1,'inherit':['level','exp','hp','maxHP','gold','inventory','equipment','ownedEquipment','lexicon','asked','examStudy','chests','defeated','kills','flags','unlocks'],'maxSupportedLevel':99}}
save('data/continuation.json',config)
data['continuation']=config
data['chapters']=[c for c in data['chapters'] if c['id']<=8]+[{'id':p['chapter'],'name':p['title'],'part':2,'implemented':False,'scenes':p['scenes']}for p in plans]
save('data/game-data.json',data)
# Master workbook is the authority for names, original values and special effects.
workbook=UPLOAD/'コトバの塔_ゲームマスターバンク_Ver1.xlsx'
book=load_workbook(workbook,read_only=True,data_only=True);master={}
for name in ['武器','防具','アクセサリー']:
    rows=list(book[name].values);header=rows[2]
    for row in rows[3:]:
        if row and row[0]:master[row[0]]=dict(zip(header,row))
used=set()
for shop in data['shops'].values():used.update(p['id']for p in shop['products']if p['type']=='gear')
for event in data['events'].values():used.update(e['id']for e in event.get('effects',[])if e['type']=='gear')
for m in data['maps'].values():
    for o in m['objects']:used.update(o.get('loot',{}).get('gear',[]))
selected=[(9,'W027',19,98,0,0,4200),(9,'A016',20,0,91,30,3900),(10,'W028',21,118,0,0,5200),(10,'A017',23,0,114,35,4800),(10,'W030',25,147,0,0,6500),(10,'A018',26,0,137,40,5900),(11,'W013',28,179,0,0,8100),(11,'A019',29,0,159,45,7200),(12,'W014',32,211,0,0,10200),(12,'A020',32,0,180,50,8800),(13,'W034',33,230,0,0,11400),(14,'W015',35,250,4,40,0),(14,'A021',35,0,202,55,10600)]
gearplans=[]
for chapter,id,lv,atk,df,hp,price in selected:
    assert id in master and id not in used,id
    item=data['equipment'][id];assert item['name']==master[id]['名称']
    gearplans.append({'id':id,'name':item['name'],'chapter':chapter,'requiredLevel':lv,'attack':atk,'defense':df,'HP':hp,'price':price,'source':'existing master bank','implemented':False,'specialEffect':master[id]['特殊効果'],'effectImplemented':False,'placement':'quest reward'if price==0 else 'shop or chest','note':'Inactive planned overrides. Current equipment remains unchanged.'})
audit=[]
for id,item in data['equipment'].items():
    assert id in master and item['name']==master[id]['名称'],id
    audit.append({'id':id,'name':item['name'],'requiredLevel':item['requiredLevel'],'usedInPart1':id in used,'candidateForPart2':id not in used and item['requiredLevel']<=35,'currentAttack':item['attack'],'currentDefense':item.get('defense',item.get('防御',0)),'original':master[id],'implementedFields':['attack','defense','HP'],'deferredFields':['MP','素早さ','会心/回避','特殊効果'],'note':'Special-effect text is descriptive; no effect parser in current engine.'})
save('data/part2-equipment-plan.json',{'revision':1,'implemented':False,'tiers':gearplans,'accessoryCandidates':[id for id in ['C005','C006','C007','C011','C012','C014','C016']if id not in used],'activation':'Explicit future stage only; do not auto-equip or add to existing shops.'})
save('docs/part2-equipment-audit.json',{'source':workbook.name,'sha256':hashlib.sha256(workbook.read_bytes()).hexdigest(),'count':len(audit),'usedInPart1':len(used),'records':audit})
print('Part 2 preparation:',len(scenes),'canonical scenes,',len(audit),'equipment records,',len(plans),'planned chapters')
