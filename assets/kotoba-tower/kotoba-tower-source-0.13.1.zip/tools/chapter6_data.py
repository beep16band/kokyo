"""Chapter6 scenes36–40. Preserve chapter1–5 data and canonical spoken lines."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((R/'data'/n).read_text())
maps=read('maps.json');d=read('game-data.json');sc=read('canonical-scenes.json');events={}
def text(s,t):return dict(speaker=s,text=t)
def event(id,pages,flags=None,when=None,effects=None,once=True):
 events[id]=dict(id=id,pages=pages,when=when or {},effects=([dict(type='flags',values=flags)]if flags else [])+(effects or []),once=once)
def travel(mid,x,y):return dict(type='travel',map=mid,spawn=dict(x=x,y=y,dir='up'))
def room(id,name,w=26,h=18,inside=False):
 m=dict(id=id,name='第6章・'+name,chapter=6,width=w,height=h,tiles=['floor'if inside else 'grass']*(w*h),collision=[int(x==0 or y==0 or x==w-1 or y==h-1)for y in range(h)for x in range(w)],wallAsset='wall'if inside else 'rock_wall',objects=[],npcs=[],portals=[],enemies=[],triggers=[],entryEvents=[],safeSpawn=dict(x=3,y=h-4,dir='up'));maps[id]=m;return m
def obj(m,id,x,y,asset,w=32,h=32,ev=None,solid=True):
 o=dict(id=id,x=x,y=y,asset=asset,width=w,height=h,anchorX=w//2,anchorY=h,kind='decor',footprint=[dict(x=0,y=0,w=w,h=h)]if solid else [])
 if ev:o.update(events=ev,interactionRect=dict(x=x*32+16-w//2,y=y*32+32-h,w=w,h=h),interactionLabel='残された記録を調べる')
 m['objects'].append(o);return o
def portal(m,id,x,y,target,sx,sy,requires=None,kind='path',dir='up',label=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir=dir),kind=kind,asset={'path':'stone_arch','door':'gate_door','stairs':'stairs_down'}[kind],label=label or maps.get(target,{}).get('name','道へ'))
 if requires:p.update(requires=requires,lockedPages=['まだ進めない。「目的」で、確認していない記録を見よう。'])
 p['interactionLabel']=p['label']+'へ移動';m['portals'].append(p);return p
def roads(m):
 for y in range(2,m['height']-2):
  for x in range(2,m['width']-2):
   if y in [4,m['height']-4]or x in [3,m['width']-4]:m['tiles'][y*m['width']+x]='path'
def npc(m,id,name,x,y,asset,ev=None,pages=None,service=None):
 n=dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),events=ev or [],pages=pages or ['名を紙に書いておこう。呼び方を忘れてしまわないように。'])
 if service:n.update(service=service[0],serviceId=service[1])
 m['npcs'].append(n);return n

r=room('ch6_road','忘却の街への石道');roads(r);r['entryEvents']=['ch6_road_intro']
t=room('ch6_town','忘却の街',36,26);roads(t);t['entryEvents']=['ch6_town_intro','ch6_urgency']
i=room('ch6_inn','名前を残す宿',18,15,True);i['safeSpawn']=dict(x=7,y=11,dir='up')
a=room('ch6_name_garden','名前を守る石碑の庭',26,20);roads(a);a['entryEvents']=['ch6_garden_intro']
v=room('ch6_overlook','塔を望む丘');roads(v);v['entryEvents']=['ch6_words_stream']
b=room('ch6_king','忘名王の門',26,20,True);b['safeSpawn']=dict(x=12,y=15,dir='up');b['entryEvents']=['ch6_king_room']
z=room('ch6_terrace','塔へ急ぐ道',22,16);roads(z);z['entryEvents']=['chapter6_clear']
school=copy.deepcopy(maps['school_class']);school.update(id='ch6_school_projection',name='共鳴に映った現実の教室',chapter=6,school=False,memory=True,hideHero=True,portals=[],npcs=[],enemies=[],triggers=[],entryEvents=['ch6_school_scene'],safeSpawn=dict(x=9,y=12,dir='up'))
for o in school['objects']:o.pop('events',None);o.pop('when',None)
npc(school,'ch6-real-aoi','アオイ',8,9,'aoi_pipoya_student');npc(school,'ch6-real-friend','友人',7,9,'student_pipoya')
maps[school['id']]=school
# Reuse the actual existing school friend's chip if its asset name differs.
school['npcs'][1]['asset']=maps['school_hall']['npcs'][0]['asset']
old=maps['ch5_terrace'];old['objects']=[o for o in old['objects']if o['id']!='chapter6_route'];old['portals']=[p for p in old['portals']if p['id']!='gate-chapter6'];portal(old,'gate-chapter6',10,4,'ch6_road',3,14,{'chapter5Complete':True},label='忘却の街へ')
portal(r,'ch6-road-back',2,14,'ch5_terrace',10,5,dir='down',label='手紙の町へ戻る');portal(r,'ch6-road-town',22,4,'ch6_town',3,22,label='忘却の街へ')
for x in range(1,25):r['collision'][9*26+x]=int(x!=13)
r['enemies']=[dict(id='ch6-road-sentry',enemy='S6_WISP',x=13,y=9,respawn=True),dict(id='ch6-road-roamer',enemy='S6_WISP',x=18,y=13,respawn=True,behavior=dict(type='patrol_chase',chaseRadius=4,leash=5,stepSeconds=.42))]
for k,(x,y)in enumerate([(7,6),(20,7),(7,12)]):obj(r,'ch6-tree-'+str(k),x,y,'tree',64,64)['footprint']=[dict(x=26,y=48,w=12,h=16)]
portal(t,'ch6-town-back',2,22,'ch6_road',21,4,dir='left',label='石道へ戻る');portal(t,'ch6-town-inn',25,8,'ch6_inn',7,11,kind='door',label='名前を残す宿')
house=obj(t,'ch6-inn-house',25,8,'inn_house_v2',128,128);house.update(kind='building',footprint=[dict(x=0,y=0,w=128,h=96),dict(x=0,y=96,w=48,h=32),dict(x=80,y=96,w=48,h=32)],entrance=dict(x=48,y=96,w=32,h=32))
portal(t,'ch6-town-garden',32,4,'ch6_name_garden',3,16,{'ch6RealitySeen':True},label='名前の石碑の庭へ')['lockedPages']=['西の古いノートで、共鳴に映る学校を確かめよう。']
obj(t,'ch6-reality-book',8,14,'old_book',ev=['ch6_projection','ch6_projection_repeat'])['interactionLabel']='学校の映像が映るノートを調べる'
npc(t,'ch6-namekeeper','名を記す人',13,17,'elderwoman',pages=['右上の門の先に、忘れたくない名を一つだけ刻む石碑がある。西のノートを見てから行ってごらん。'])
npc(t,'ch6-shop','忘却の街の道具屋',24,19,'merchant',service=('shop','forgotten-shop'))
npc(t,'ch6-side-npc','届け先を忘れた旅人',17,21,'villager',['ch6_side_letter','ch6_side_letter_repeat'])
obj(t,'ch6-returned-letter',12,20,'scroll',ev=['ch6_side_paper','ch6_side_paper_repeat'])['interactionLabel']='旅人の宛名を調べる'
for y in [9,15,21]:
 for x in range(3,33):t['tiles'][y*36+x]='path'
for y in range(8,22):t['tiles'][y*36+25]='path'
portal(i,'ch6-inn-back',7,12,'ch6_town',25,9,kind='door',dir='down',label='忘却の街へ');npc(i,'ch6-innkeeper','宿の人',4,6,'elderwoman',service=('inn','forgotten-inn'));obj(i,'ch6-rest-book',10,8,'old_book',ev=['ch6_rest_notebook'])
portal(a,'ch6-garden-back',2,16,'ch6_town',31,4,dir='left',label='忘却の街へ');portal(a,'ch6-garden-view',22,4,'ch6_overlook',3,10,{'ch6NameInscribed':True},label='塔を望む丘へ')['lockedPages']=['中央の石碑で、忘れたくない名を刻もう。']
obj(a,'ch6-name-stone',13,9,'stone_tablet_v2',64,64,['ch6_name','ch6_name_repeat'])['interactionLabel']='忘れたくない名を刻む'
obj(a,'ch6-garden-cache',7,14,'chest').update(kind='chest',loot=dict(items={'I001':4},gold=180))
portal(v,'ch6-view-back',2,14,'ch6_name_garden',21,4,dir='left',label='石碑の庭へ戻る');portal(v,'ch6-view-king',22,4,'ch6_king',12,15,{'ch6TowerSuspected':True},kind='door',label='忘名王の門へ')
obj(v,'ch6-tower-vista',14,10,'tower_generated',96,192,solid=False).update(kind='vista',depthOffset=-400)
v['wordStream']=dict(target=dict(x=14,y=8),words=['言葉','名前','記憶'])
npc(v,'ch6-witness','町人',8,10,'villager',pages=['あの光は、街の言葉だった。塔へ向かっている……。'])
portal(b,'ch6-king-back',12,17,'ch6_overlook',21,4,kind='door',dir='down',label='丘へ戻る');portal(b,'ch6-king-exit',12,3,'ch6_terrace',10,12,{'ch6KingDefeated':True},kind='door',label='塔へ急ぐ道')
for x in range(1,25):b['collision'][8*26+x]=int(x!=12)
b['enemies']=[dict(id='ch6-forgotten-king',enemy='S6_KING',x=12,y=9,introEvent='ch6_king_appears',afterEvent='ch6_king_freed')]
obj(b,'ch6-king-cache',5,14,'chest').update(kind='chest',loot=dict(items={'I001':3},gold=220))
portal(z,'ch6-terrace-back',10,13,'ch6_king',12,4,dir='down',label='忘名王の門へ戻る')
obj(z,'chapter7_route',10,4,'stone_arch',ev=['chapter7_not_ready'],solid=False)['interactionLabel']='塔の入口を確認する'
event('chapter6_departure',[text('','第6章　忘却の街'),text('レン','北の門から忘却の街へ。まず、街に残る記録を調べよう。')],{'chapter6Started':True},{'chapter5Complete':True},[dict(type='chapter',value=6),travel('ch6_road',3,14)])
event('ch6_road_intro',[text('','第6章　忘却の街'),text('レン','石道の中央に魔物がいる。道を開きながら、北東の街へ進もう。')],{'chapter6Started':True},effects=[dict(type='chapter',value=6)])
event('ch6_town_intro',[text('町人','名前が、口から出てこない。覚えていたはずなのに。'),text('レン','西の古いノートが光ってる。あそこを調べよう。宿と道具屋は東だ。')],{'ch6TownVisited':True})
event('ch6_projection',[text('','ノートの文字と塔の光が共鳴し、学校の映像が広がる。')],when={'ch6RealitySeen':False},effects=[travel('ch6_school_projection',9,12)],once=False)
event('ch6_school_scene',sc['36'],{'ch6RealitySeen':True},effects=[travel('ch6_town',8,15)])
event('ch6_projection_repeat',[text('主人公','アオイの言葉が、まだ耳に残っている。今は、北東の石碑へ急ごう。')],when={'ch6RealitySeen':True},once=False)
event('ch6_urgency',sc['37']+[text('レン','北東の門から、名前を守る石碑へ行こう。')],{'ch6UrgencyHeard':True},{'ch6RealitySeen':True})
event('ch6_garden_intro',[text('','中央の石碑には、一つだけ名を刻める。')])
event('ch6_name',sc['38'][:2],when={'ch6NameInscribed':False},effects=[dict(type='choice',id='ch6_name_action')],once=False)
d['interactions']['ch6_name_action']=dict(id='ch6_name_action',name='名前を守る石碑',prompt='忘れたくない名を、一つ。',choices=['アオイを刻む'],flags={'ch6NameInscribed':True},outcomes=[dict(pages=[text('','主人公は迷わず「アオイ」と刻んだ。')]+sc['38'][3:]+[text('レン','名は刻んだ。右上の門から、塔を望む丘へ。')])])
event('ch6_name_repeat',[text('石碑','アオイ'),text('主人公','この名を、忘れない。')],when={'ch6NameInscribed':True},once=False)
view=copy.deepcopy(sc['39']);view[-1]['visualOnly']=True
event('ch6_words_stream',view+[text('','光は消えず、文字の列になって塔へ入っていく。'),text('レン','丘の右上の門を通ろう。忘名王が塔への道を塞いでいる。')],{'ch6TowerSuspected':True})
event('ch6_king_room',[text('','中央の通路に忘名王がいる。南の階段から丘へ戻れ、宿で休める。')])
event('ch6_king_appears',sc['40'][:2],effects=[dict(type='battle',encounter='ch6-forgotten-king')])
event('ch6_king_freed',sc['40'][3:]+[text('レン','門は開いた。北の扉から、塔へ急ごう。')],{'ch6KingDefeated':True})
event('chapter6_clear',[text('','第6章　忘却の街　CLEAR'),text('主人公','アオイの名は守った。でも、記憶はまだ戻っていない。塔の中へ行く。')],{'chapter6Complete':True},{'ch6KingDefeated':True})
event('chapter7_not_ready',[text('','第7章「ことばの継承者」は次工程です。冒険の記録を保存してください。')],once=False)
event('ch6_side_paper',[text('手紙','差出人は「ナギ」。宛先には、旅人の名前「ハル」と書かれている。')],{'ch6SidePaperRead':True})
event('ch6_side_paper_repeat',[text('手紙','宛先は「ハル」。南東の旅人に伝えよう。')],when={'ch6SidePaperRead':True},once=False)
event('ch6_side_letter',[text('主人公','ここに、ハルって書いてある。'),text('旅人','そうだ。私の名だ。紙に残っていて、よかった。')],{'ch6SideDelivered':True},{'ch6SidePaperRead':True},[dict(type='gold',amount=120)])
event('ch6_side_letter_repeat',[text('旅人','ハル。もう一度、書いておくよ。ありがとう。')],when={'ch6SideDelivered':True},once=False)
event('ch6_rest_notebook',[text('主人公','アオイの文字は消えていない。俺も、この名前を呼び続ける。')],once=False)
d['enemies']['S6_WISP']=dict(id='S6_WISP',name='薄れる名の影',hp=290,attack=31,guard=12,attackSeconds=14,exp=110,gold=125,asset='archive_wisp',questionCategories=['熟語の読み方','類義語','対義語'])
d['enemies']['S6_KING']=dict(id='S6_KING',name='忘名王',hp=820,attack=48,guard=18,attackSeconds=14,exp=330,gold=400,asset='archive_guardian',questionCategories=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語'])
d['shops']['forgotten-shop']=dict(name='忘却の街の道具屋',products=[dict(id='I001',type='item',price=35),dict(id='W005',type='gear',price=600),dict(id='A003',type='gear',price=420),dict(id='A004',type='gear',price=850)])
d['inns']['forgotten-inn']=dict(name='名前を残す宿',price=25)
d['chapters'][6]=dict(id=6,implemented=True,name='忘却の街',scenes=list(range(36,41)),entry=dict(map='ch6_road',spawn=dict(x=3,y=14,dir='up')))
d['objectives']=[o for o in d['objectives']if not any(k.startswith('ch6')or k=='chapter6Started'for k in o.get('when',{}))]
d['objectives'][:0]=[dict(when=when,text=t)for when,t in [({'chapter6Started':True,'ch6TownVisited':False},'石道の魔物を倒し、北東の門から忘却の街へ。'),({'ch6TownVisited':True,'ch6RealitySeen':False},'街の西のノートを調べて、学校の映像を確かめよう。東に宿と道具屋。'),({'ch6RealitySeen':True,'ch6NameInscribed':False},'街の北東の門から石碑の庭へ。中央の石碑にアオイの名を刻もう。'),({'ch6NameInscribed':True,'ch6TowerSuspected':False},'石碑の庭の右上の門から、塔を望む丘へ。'),({'ch6TowerSuspected':True,'ch6KingDefeated':False},'丘の右上の門から忘名王へ。宿で回復し、装備を更新して挑もう。'),({'ch6KingDefeated':True,'chapter6Complete':False},'忘名王の間の北の扉から、塔へ急ぐ道へ。'),({'chapter6Complete':True},'第6章CLEAR。記録ファイルを保存して、第7章の公開を待とう。')]]
d['recovery']['checkpoints']=[cp for cp in d['recovery']['checkpoints']if cp['chapter']!=6]+[dict(id='C6',label='第6章・石道',chapter=6,map='ch6_road',x=3,y=14),dict(id='C6E',label='第6章クリア',chapter=6,map='ch6_terrace',x=3,y=12)]
completed={'chapter6Started':True,'chapter6Complete':True}
for e in events.values():
 if e['once']is not False:
  completed['event:'+e['id']]=True
  for f in e['effects']:
   if f['type']=='flags':completed.update(f['values'])
completed['ch6NameInscribed']=True;d['recovery']['completedFlags']['6']=completed
for m in [r,t,i,a,v,b,z,school]:
 for p in m['portals']:p['label']=p['label'].replace('第6章・','')
d['maps']=maps
for name,vv in [('maps.json',maps),('game-data.json',d),('chapter6-events.json',events)]:(R/'data'/name).write_text(json.dumps(vv,ensure_ascii=False,indent=2)+'\n')
print('Chapter6: 8 maps, scenes36–40, name monument, optional letter, mandatory king, old save support')
