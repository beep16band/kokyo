/* Part 1 finale effects. Bounded particles; no audio or external dependencies. */
(function(root){'use strict';
function draw(g,E,images,assets,cam,w,h){
 // Local light only; the town and people's skin retain their original palette.
 if(E.map.afterStory&&E.state.flags.asMoreMonsters&&!E.map.night){g.save();g.fillStyle='#9368b724';g.fillRect(0,0,w,4);g.restore();}
 const fx=E.sequence?.fx;if(!fx)return;const age=fx.age,p=Math.min(1,age/fx.duration);g.save();g.imageSmoothingEnabled=false;
 if(fx.kind==='absorb'||fx.kind==='absorb-ring'||fx.kind==='absorb-glyph'){
  const hp=E.position,x=hp.x-cam.x,y=hp.y-cam.y-19;
  if(fx.kind==='absorb'){
   const im=images[fx.enemy],n=Math.min(44,20+(fx.count||1)*6),startX=x+52,startY=y-12;
   if(im){g.globalAlpha=Math.max(0,1-p*2.3);g.drawImage(im,startX-16,startY-16,32,32);}
   g.font='10px serif';for(let k=0;k<n;k++){const t=Math.max(0,Math.min(1,(p-k/n*.3)/.7)),a=k*2.399+t*5,r=(1-t)*(10+k%5*3);g.globalAlpha=Math.min(1,p*5)*Math.max(0,1-t*t);g.fillStyle=k%3?'#c9a4f1':'#fff4ff';g.fillText(['言','記','名','喰'][k%4],Math.round(startX+(x-startX)*t+Math.cos(a)*r),Math.round(startY+(y-startY)*t+Math.sin(a)*r));}
  }else if(fx.kind==='absorb-ring'){
   g.globalAlpha=Math.sin(p*Math.PI)*.8;g.strokeStyle='#c294e3';g.lineWidth=1;g.beginPath();g.ellipse(x,y+16,9+p*18,3+p*7,0,0,Math.PI*2);g.stroke();g.globalAlpha=1;g.font='11px sans-serif';g.textAlign='center';g.fillStyle='#ead9ff';g.fillText('最大HP＋2　ちから＋1',x,y-20);
  }else{g.globalAlpha=Math.sin(p*Math.PI);g.fillStyle='#dbb7ef';g.font='16px serif';g.textAlign='center';g.fillText('喰',x+28,y+20);}
 }
 else if(fx.kind==='days'){g.fillStyle='#080e1bea';g.fillRect(0,0,w,h);g.globalAlpha=Math.sin(p*Math.PI);g.font='18px serif';g.textAlign='center';g.fillStyle='#f1e2b7';g.fillText('数日後',w/2,h/2);}
 else if(fx.kind==='water-ripple'){
  const o=E.map.objects.find(o=>o.id==='as-cup');if(o){const x=o.x*32+16-cam.x,y=o.y*32+10-cam.y;g.strokeStyle='#c69ae7';g.lineWidth=1;g.globalAlpha=Math.sin(p*Math.PI);g.beginPath();g.ellipse(x,y,1+p*4,1+p*1.3,0,0,Math.PI*2);g.stroke();}
 }
 else if(fx.kind==='night-window'){const o=E.map.objects.find(o=>o.id==='as-window');if(o){g.fillStyle='#eed399';g.globalAlpha=.08+Math.sin(p*Math.PI)*.04;g.fillRect(o.x*32-cam.x,o.y*32+32-cam.y,32,48);}}
 else if(fx.kind==='logos-break'){const im=images.logos_final,origin={x:12*32+16-cam.x,y:6*32+32-cam.y},size=128,split=Math.max(0,(age-1.1)/2.6);g.globalAlpha=Math.max(0,1-split);for(let y=0;y<4;y++)for(let x=0;x<4;x++){const dx=(x-1.5)*split*48,dy=(y-1.5)*split*36;g.drawImage(im,x*assets.logos_final.width/4,y*assets.logos_final.height/4,assets.logos_final.width/4,assets.logos_final.height/4,Math.round(origin.x-size/2+x*32+dx),Math.round(origin.y-size+y*32+dy),32,32);}g.globalAlpha=1;g.strokeStyle='#a9eaf5';g.lineWidth=1;for(let k=0;k<3;k++){const r=12+age*14+k*13;g.globalAlpha=Math.max(0,.65-p);g.beginPath();g.arc(origin.x,origin.y-64,r,0,Math.PI*2);g.stroke();}g.globalAlpha=1;const letters=['名','記','明','言','心','返'];g.font='12px sans-serif';for(let k=0;k<36;k++){const a=k*2.4,r=Math.max(0,age-1)*18+(k%5)*6;g.fillStyle=k%2?'#e9dba0':'#b5eaf1';g.globalAlpha=Math.min(1,Math.max(0,(age-1)*2))*Math.max(0,1-p*.7);g.fillText(letters[k%6],Math.round(origin.x+Math.cos(a)*r),Math.round(origin.y-64+Math.sin(a)*r));}g.globalAlpha=.12*Math.sin(p*Math.PI);g.fillStyle='#f7f0d1';g.fillRect(0,0,w,h);}
 else if(fx.kind==='release'||fx.kind==='phase'){g.font='12px sans-serif';for(let k=0;k<(fx.kind==='release'?64:20);k++){const a=k*2.399+age*.3,r=10+(age*22)*(1+k%4*.12),x=w/2+Math.cos(a)*r,y=h/2+Math.sin(a)*r*.7;g.globalAlpha=Math.min(1,age)*Math.min(1,(fx.duration-age));g.fillStyle=k%3?'#e9dda9':'#b4ebee';g.fillText(['名前','手紙','明日','言葉','昨日','記録'][k%6],Math.round(x),Math.round(y));}g.globalAlpha=1;g.textAlign='center';g.fillStyle='#fff7d5';g.fillText(fx.kind==='release'?'保存されていた言葉が、世界へ帰っていく。':'ロゴスの記録領域が切り替わる。',w/2,h-22);}
 else if(fx.kind==='notebook'){const im=images.notebook_final,hp=E.sequenceActorPosition('hero'),ap=E.sequenceActorPosition('aoi');if(im&&hp&&ap)g.drawImage(im,Math.round(hp.x+(ap.x-hp.x)*p-cam.x-16),Math.round(hp.y+(ap.y-hp.y)*p-cam.y-40-Math.sin(p*Math.PI)*12),32,32);}
 else if(fx.kind==='memory'){g.globalAlpha=Math.sin(p*Math.PI)*.12;g.fillStyle='#f5d6a0';g.fillRect(0,0,w,h);g.globalAlpha=1;g.textAlign='center';g.fillStyle='#fff2d5';g.font='14px sans-serif';g.fillText({55:'ノートを貸した日',56:'二人の掃除当番',57:'転校を聞いた日',58:'「明日は返してよ」'}[fx.scene]||'',w/2,26);}
 else if(fx.kind==='fade'||fx.kind==='end'){g.globalAlpha=fx.kind==='end'?1:Math.sin(p*Math.PI/2);g.fillStyle='#070c18';g.fillRect(0,0,w,h);if(fx.kind==='end'){g.globalAlpha=Math.min(1,age);g.fillStyle='#f1e2b7';g.textAlign='center';g.font='18px serif';g.fillText('――また明日。',w/2,h/2);}}
 g.restore();}
root.KotobaFinale={draw};
})(typeof globalThis!=='undefined'?globalThis:this);
