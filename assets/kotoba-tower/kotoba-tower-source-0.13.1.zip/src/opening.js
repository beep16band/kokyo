/* Opening montage: visual-only; never touches Engine or saved records. */
(function(root){'use strict';
const scenes=[
 {end:5, map:'school_class',focus:[8.5,8],caption:'冬の放課後。',cast:'school'},
 {end:9, map:'school_library',focus:[7,6],caption:'言葉が、消えていく。',cast:null},
 {end:14,map:'ch1_meadow',focus:[24,3],caption:'その先に、塔があった。',cast:'journey'},
 {end:17.5,map:'ch1_garden',focus:[10,12],caption:'言葉を、取り戻せ。',cast:'battle'},
 {end:23,map:'ch1_meadow',focus:[24,3],caption:'',cast:'title'}
];
function create({overlay,canvas,caption,title,skip,sound,replay,images,data,onEnd,hero=()=>'hero_pipoya_student'}){
 const g=canvas.getContext('2d');let active=false,elapsed=0,index=-1,scale=1,audio=null;
 const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
 function resize(){scale=overlay.parentElement.clientWidth>=960&&overlay.parentElement.clientHeight>=480?2:1;canvas.width=Math.max(1,Math.floor(overlay.parentElement.clientWidth/scale));canvas.height=Math.max(1,Math.floor(overlay.parentElement.clientHeight/scale));canvas.style.width=canvas.width*scale+'px';canvas.style.height=canvas.height*scale+'px';g.imageSmoothingEnabled=false;if(active)render();}
 function sprite(asset,x,y,w,h,frame){const im=images[asset];if(!im)return;if(frame)g.drawImage(im,frame[0],frame[1],32,32,Math.round(x),Math.round(y),w,h);else g.drawImage(im,Math.round(x),Math.round(y),w,h);}
 function actor(asset,x,y,dir='right',walking=false){const row={down:0,left:1,right:2,up:3}[dir],frame=walking?[1,0,1,2][Math.floor(elapsed/.14)%4]:1;sprite(asset,x-16,y-32,32,32,[frame*32,row*32]);}
 function drawMap(m,cam){const w=canvas.width,h=canvas.height;
  for(let y=Math.max(0,Math.floor(cam.y/32));y<Math.min(m.height,Math.ceil((cam.y+h)/32));y++)for(let x=Math.max(0,Math.floor(cam.x/32));x<Math.min(m.width,Math.ceil((cam.x+w)/32));x++){sprite(m.tiles[y*m.width+x],x*32-cam.x,y*32-cam.y,32,32);if(m.collision[y*m.width+x])sprite(m.wallAsset||'wall',x*32-cam.x,y*32-cam.y,32,32)}
  const nodes=m.objects.filter(o=>o.kind!=='chest'&&o.id!=='mystery_stair').map(o=>({depth:o.y*32+32,draw:()=>sprite(o.asset,o.x*32+16-o.anchorX-cam.x,o.y*32+32-o.anchorY-cam.y,o.width,o.height)}));return nodes;
 }
 function render(){if(!active)return;const i=scenes.findIndex(s=>elapsed<s.end);if(i<0){stop();return;}const s=scenes[i],start=i?scenes[i-1].end:0,t=elapsed-start,duration=s.end-start,p=clamp(t/duration),w=canvas.width,h=canvas.height;
  if(index!==i){index=i;caption.textContent=s.caption;title.classList.toggle('hidden',s.cast!=='title');overlay.dataset.scene=String(i);}
  g.clearRect(0,0,w,h);g.fillStyle='#080c12';g.fillRect(0,0,w,h);
  const m=data.maps[s.map],cx=s.focus[0]*32+16+Math.round((p-.5)*(i===0?56:32)),cy=s.focus[1]*32+24+Math.round((.5-p)*(i===2?40:12)),cam={x:Math.round(clamp(cx-w/2,0,Math.max(0,m.width*32-w))),y:Math.round(clamp(cy-h/2,0,Math.max(0,m.height*32-h)))};
  if(m.id==='ch1_meadow')cam.y-=Math.min(28,Math.floor(h*.07));
  const nodes=drawMap(m,cam),cast=(asset,x,y,dir,walk)=>nodes.push({depth:y,draw:()=>actor(asset,x-cam.x,y-cam.y,dir,walk)});
  if(s.cast==='school'){cast(hero(),8*32+16,10*32+30,'up',false);cast('aoi_pipoya_student',8*32+16,9*32+30,'down',false);}
  if(s.cast==='journey'){cast(hero(),22*32+16,7*32+30-Math.round(p*24),'up',true);cast('ren_pipoya_student',21*32+16,8*32+30-Math.round(p*24),'up',true);}
  if(s.cast==='battle'){const x=cx-64+Math.round(p*32),y=cy+12;cast(hero(),x,y,'right',true);cast('ren_pipoya_student',x-32,y+32,'right',true);nodes.push({depth:y,draw:()=>{if(!(t>1.3&&t<1.85&&Math.floor(t*10)%2))sprite('hound',cx+64-cam.x,cy-20-cam.y,32,32);}});}
  nodes.sort((a,b)=>a.depth-b.depth);nodes.forEach(n=>n.draw());
  if(s.cast==='battle'&&t>1.15&&t<1.7){const a=t-1.15,im=images.attack_wave_right;if(im&&a<.3){const f=Math.min(2,Math.floor(a/.1));g.drawImage(im,f*64,0,64,64,Math.round(cx-70-cam.x+a*240),Math.round(cy-32-cam.y),64,64)}if(a>.2){const impact=images.attack_impact,f=Math.min(5,Math.floor((a-.2)/.06));if(impact)g.drawImage(impact,f*48,0,48,48,Math.round(cx+48-cam.x),Math.round(cy-28-cam.y),48,48);}}
  // Color grade, dust and letter fragments are effects, not replacement scenery.
  g.fillStyle=i<2?'#15274245':'#080f2040';g.fillRect(0,0,w,h);
  g.save();g.fillStyle='#e6d5a0';for(let k=0;k<22;k++){const x=(k*79+Math.floor(elapsed*(4+k%3)))%w,y=(k*47-Math.floor(elapsed*(5+k%4))+h*20)%h;g.globalAlpha=.08+(Math.sin(elapsed+k)+1)*.08;g.fillRect(x,y,1+k%2,1+k%2)}
  if(i===1||s.cast==='title'){g.font='14px serif';const chars=['言','葉','記','憶'];for(let k=0;k<9;k++){g.globalAlpha=.08+(k%3)*.04;g.fillText(chars[k%4],(k*97+17)%w,Math.round((k*43+elapsed*-8+h*20)%h))}}g.restore();
  const bars=Math.min(28,Math.floor(h*.07));g.fillStyle='#060a12';g.fillRect(0,0,w,bars);g.fillRect(0,h-bars,w,bars);
  const fade=Math.min(clamp(t/.6),clamp((duration-t)/.65));g.fillStyle='rgba(3,6,12,'+(1-fade)+')';g.fillRect(0,0,w,h);
  const line=i===0&&t>1.8?'「そのノート、明日は返してよ。」':s.caption;if(caption.textContent!==line)caption.textContent=line;
  g.save();g.textAlign='center';g.globalAlpha=fade;g.shadowColor='#000';g.shadowBlur=6;g.shadowOffsetY=2;g.fillStyle='#fff2d4';let font=18;g.font=font+'px serif';while(g.measureText(line).width>w-32&&font>12){font--;g.font=font+'px serif';}if(line)g.fillText(line,w/2,Math.min(h*.78,h-65));
  if(s.cast==='title'){g.globalAlpha=fade*clamp(t/1.3);g.shadowBlur=0;g.fillStyle='#07152acc';g.fillRect(0,0,w,h);const logo=images.title_logo;if(logo){const lw=Math.floor(Math.min(w*.9,(h-70)*3)/3)*3,lh=lw/3;g.drawImage(logo,Math.round((w-lw)/2),Math.round((h-lh)/2+(1-clamp(t/1.3))*12),lw,lh);}else{g.font='bold '+Math.min(48,Math.floor(w/7))+'px serif';g.fillStyle='#f4e5b9';g.fillText('コトバの塔',w/2,h*.54);}}

  g.restore();caption.style.opacity=String(fade);caption.style.transform='translateY('+Math.round((1-clamp(t/1.3))*12)+'px)';title.style.opacity=String(s.cast==='title'?clamp(t/1.3):0);title.style.transform='translateY('+Math.round((1-clamp(t/1.3))*18)+'px)';
 }
 function stopAudio(){if(audio){const old=audio;audio=null;old.close().catch(()=>{});}sound.textContent='音楽：OFF';}
 function music(){if(audio){stopAudio();return;}const Audio=root.AudioContext||root.webkitAudioContext;if(!Audio){sound.textContent='音楽：この端末では使えません';return;}try{audio=new Audio();audio.resume().catch(()=>{});const bus=audio.createGain();bus.gain.value=.075;bus.connect(audio.destination);const melody=[64,67,71,74,71,67,62,66,69,74,69,66,60,64,67,72,71,67,62,66,69,71,74,76,74,71,67,64,62,66,69,71],start=audio.currentTime+.08;for(let bar=0;bar<2;bar++)for(let k=0;k<melody.length;k++){const time=start+(bar*32+k)*.34;if(time-start>23-elapsed)break;const note=audio.createOscillator(),gain=audio.createGain();note.type='triangle';note.frequency.value=440*Math.pow(2,(melody[k]-69)/12);gain.gain.setValueAtTime(0,time);gain.gain.linearRampToValueAtTime(.5,time+.035);gain.gain.exponentialRampToValueAtTime(.001,time+.32);note.connect(gain);gain.connect(bus);note.start(time);note.stop(time+.34);}sound.textContent='音楽：ON';}catch(e){stopAudio();sound.textContent='音楽：この端末では使えません';}}
 function start(){if(active)return;elapsed=0;index=-1;active=true;overlay.classList.remove('hidden');replay.disabled=true;resize();skip.focus();render();}
 function stop(){if(!active)return;active=false;stopAudio();overlay.classList.add('hidden');replay.disabled=false;onEnd();}
 skip.onclick=stop;sound.onclick=music;overlay.addEventListener('click',e=>{if(!e.target.closest('button'))stop()});replay.onclick=start;
 return {start,stop,resize,tick(dt){if(!active)return;elapsed=Math.min(23,elapsed+Math.max(0,Math.min(.1,dt)));render();},visibility(hidden){if(audio){if(hidden)audio.suspend().catch(()=>{});else audio.resume().catch(()=>{});}},get active(){return active},get elapsed(){return elapsed},get scene(){return index}};
}
root.KotobaOpening={create,scenes};
})(globalThis);
