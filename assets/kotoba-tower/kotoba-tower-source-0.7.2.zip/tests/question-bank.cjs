const fs=require('fs'),assert=require('assert'),{Engine}=require('../src/core.js');
const data=JSON.parse(fs.readFileSync(__dirname+'/../data/game-data.json'));
const results=[];const check=(name,f)=>{try{f();results.push({name,ok:true})}catch(e){results.push({name,ok:false,error:e.message})}};
check('398問・6分野を原本から取り込み、旧追加戦闘問題を除外',()=>{
 assert.equal(data.questions.length,398);
 const counts={};for(const q of data.questions)counts[q.category]=(counts[q.category]||0)+1;
 assert.deepEqual(counts,{'慣用句':100,'ことわざ':96,'故事成語':66,'熟語の読み方':66,'類義語':35,'対義語':35});
 assert.equal(new Set(data.questions.map(q=>q.id)).size,398);
});
check('全398問の本文・選択肢順・正答・解説・ヒントが元セルと一致',()=>{
 for(const q of data.questions){const r=q.sourceRecord;
  assert.equal(q.prompt,r['問題文']);assert.deepEqual(q.choices,['A','B','C','D'].map(k=>r['選択肢'+k]));
  assert.equal(q.answer,'ABCD'.indexOf(r['正解']));assert.equal(q.choices[q.answer],r['正答']);
  assert.equal(q.explanation,r['解説']);assert.deepEqual(q.hints,[r['ヒント1'],r['ヒント2']]);
 }
});
check('確認済みの従来問題を実際に出題し、指定順のボタン・正誤判定・解説停止・残量再開',()=>{
 for(const q of new Engine({...data,examQuestions:[]}).questionPool()){const subset={...data,examQuestions:[],examScope:{enabled:false},questions:[q],enemies:Object.fromEntries(Object.entries(data.enemies).map(([id,e])=>[id,{...e,questionCategories:[q.category]}]))};const e=new Engine(subset);
  e.startBattle({...data.maps.yard.enemies[0]});assert.equal(e.battle.question.id,q.id);
  assert.deepEqual(e.battle.choices.map(c=>c.text),q.choices);assert.equal(e.battle.correct,q.answer);
  e.tick(2);const gauge=e.battle.attack;e.answer(q.answer);assert(e.battle.result.ok);
  assert.equal(e.battle.result.explanation,q.explanation);e.tick(30);assert.equal(e.battle.attack,gauge);
  e.nextQuestion();assert.equal(e.battle.attack,gauge);
  e.answer((q.answer+1)%4);assert(!e.battle.result.ok);assert.equal(e.battle.result.correct,q.correctAnswer);
 }
});
check('出現する全敵に出題候補があり、第2章は既存バンクから出題',()=>{
 for(const m of Object.values(data.maps))for(const n of m.enemies){const e=new Engine(data,{enemyAI:false});
  e.startBattle(n);assert(data.questions.some(q=>q.id===e.battle.question.id));
 }
 for(const id of ['S2_SHADOW','S2_HOLLOW'])assert.deepEqual(data.enemies[id].questionCategories,['類義語','対義語']);
});
check('旧セーブの出題履歴・図鑑を保持し、新IDを未出題として扱う',()=>{
 const e=new Engine(data,{enemyAI:false});e.state.asked=['Q001','C2Q001'];e.state.lexicon.Q001={word:'腹が立つ',meaning:'怒ること。',example:'既存記録'};
 const saved=e.snapshot();e.restore(saved);assert.deepEqual(e.state.asked,saved.asked);assert.deepEqual(e.state.lexicon,saved.lexicon);
 e.startBattle(data.maps.yard.enemies[0]);assert.equal(e.battle.question.id,'Q0001');e.answer(e.battle.correct);
 assert(e.state.lexicon.Q0001);assert(e.state.lexicon.Q001);assert(e.state.asked.includes('Q001'));
});
fs.writeFileSync(__dirname+'/../docs/question-bank-test-results.json',JSON.stringify(results,null,2));
for(const r of results)console.log((r.ok?'PASS ':'FAIL ')+r.name+(r.error?' '+r.error:''));
process.exit(results.some(r=>!r.ok)?1:0);
