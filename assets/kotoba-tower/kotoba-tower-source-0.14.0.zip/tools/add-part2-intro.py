"""Stage 4: canonical SCENE65–68, isolated copies of established 32px maps."""
from pathlib import Path
import copy,json
R=Path(__file__).resolve().parents[1]
def read(n):return json.loads((R/'data'/n).read_text())
def write(n,v):(R/'data'/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
d=read('game-data.json');maps=read('maps.json');canon=read('part2-canonical-scenes.json')['scenes'];events={}
def pages(s,lo=0,hi=999):
 return [dict(speaker=p['speaker'],text=p['text'],sourceScene=s,sourceLine=p['sourceLine'],sourceDocument='part2') for p in canon[str(s)]['entries'] if p['speaker'] and lo<=p['sourceLine']<=hi]
def dialogue(s,lo=0,hi=999):return dict(type='dialogue',pages=pages(s,lo,hi))
def flags(**v):return dict(type='flags',values=v)
def visual(k,t,**v):return dict(type='visual',kind=k,duration=t,**v)
def event(id,seq,when=None):events[id]=dict(name='',pages=[],when=when or {},effects=[dict(type='sequence',id=seq)])
def clone(old,new,name,school=False):
 m=copy.deepcopy(maps[old]);m.update(id=new,name=name,part2=True,chapter=9,npcs=[],enemies=[],portals=[],triggers=[],entryEvents=[])
 m.pop('afterStory',None);m.pop('epilogue',None);m.pop('night',None)
 if school:m['part2School']=True
 m['objects']=[o for o in m['objects'] if o['kind'] not in ['chest','sign','vista']]
 for o in m['objects']:o.pop('events',None);o.pop('when',None)
 maps[new]=m;return m
def portal(id,x,y,target,sx,sy,label,kind='door',asset='school_door',requires=None):
 p=dict(id=id,x=x,y=y,target=target,spawn=dict(x=sx,y=sy,dir='down'),kind=kind,asset=asset,label=label,interactionLabel=label+'へ移動')
 if requires:p.update(requires=requires,lockedPages=['今の目的を終えてから先へ進もう。'])
 return p
def npc(id,name,x,y,asset,ev=None,**extra):
 return dict(id=id,name=name,x=x,y=y,asset=asset,dir='down',collider=dict(x=x*32+7,y=y*32+20,w=18,h=11),pages=[],events=ev or [],**extra)
seq=d['sequences']
seq['p2_note']=[dict(type='actors',values={'hero':dict(x=8,y=10,dir='up'),'aoi':dict(x=8,y=9,dir='down')}),dialogue(65,87,99),visual('note-call',2.2),dialogue(65,101,102),visual('note-word',2.4),dialogue(65,104,109),flags(p2NoteSeen=True,p2AoiJoined=True),dict(type='continuation',values={'aoiJoined':True}),dict(type='finish')]
event('p2_note','p2_note',{'p2NoteSeen':False})
seq['p2_library']=[dialogue(66,114,121),visual('breath',.7),dialogue(66,123,123),flags(p2StairsSeen=True),dict(type='finish')]
event('p2_library','p2_library',{'p2StairsSeen':False})
seq['p2_arrival']=[dialogue(67,130,133),flags(p2TownSeen=True),dict(type='finish')]
event('p2_arrival','p2_arrival',{'p2TownSeen':False})
events['p2_oldman']=dict(name='',pages=pages(67,135,138),effects=[flags(p2OldmanHeard=True)])
seq['p2_child']=[dialogue(67,139,141),visual('breath',.6),dialogue(67,143,143),flags(p2ChildHeard=True),dict(type='finish')]
event('p2_child','p2_child')
events['p2_fusion_intro']=dict(name='',pages=[],effects=[dict(type='sequence',id='p2_fusion_form')])
seq['p2_fusion_form']=[visual('fusion-form',2.4),dialogue(68,148,149),dict(type='finish')]
events['p2_fusion_battle']=dict(name='',pages=[],when={'event:p2_fusion_intro':True,'p2FusionDefeated':False},once=False,effects=[dict(type='battle',encounter='p2-fusion')])
seq['p2_release']=[visual('word-home',2.8,word='母'),dialogue(68,151,151),flags(p2FusionDefeated=True),dict(type='finish')]
event('p2_release','p2_release')
seq['p2_mother']=[dict(type='actors',values={'hero':dict(x=11,y=18,dir='up'),'child':dict(x=11,y=16,dir='up'),'mother':dict(x=12,y=16,dir='left')}),dict(type='move',actor='child',to=[12,17],seconds=.16),dialogue(68,153,158),flags(p2MotherReturned=True,chapter9Complete=True),dict(type='finish')]
event('p2_mother','p2_mother',{'p2FusionDefeated':True,'p2MotherReturned':False})
c=clone('ep_class','p2_class','再出発・放課後の教室',True);c['npcs']=[npc('aoi','アオイ',8,9,'aoi_pipoya_student',when={'p2AoiJoined':False})];c['entryEvents']=['p2_note'];c['safeSpawn']=dict(x=8,y=10,dir='up')
c['portals']=[portal('p2-class-hall',21,12,'p2_hall',3,7,'廊下',requires={'p2NoteSeen':True})]
h=clone('ep_hall','p2_hall','再出発・学校の廊下',True);h['safeSpawn']=dict(x=3,y=7,dir='right');h['portals']=[portal('p2-hall-class',2,7,'p2_class',20,12,'教室'),portal('p2-hall-library',23,7,'p2_library',3,12,'図書室')]
l=clone('school_library','p2_library','再出発・図書室',True);l['safeSpawn']=dict(x=3,y=12,dir='right');l['entryEvents']=['p2_library']
# Keep original inset stair artwork, use a portal at its accessible foot.
st=next(o for o in l['objects'] if o['id']=='mystery_stair');st['interactionLabel']='再び現れた地下への階段';st['events']=[]
l['portals']=[portal('p2-library-hall',2,12,'p2_hall',22,7,'廊下'),portal('p2-library-stairs',17,4,'p2_underground',4,16,'地下の石扉',kind='stairs',asset='school_stair_inset',requires={'p2StairsSeen':True})]
# Portal already paints the stair; do not double paint the object.
l['objects'].remove(st)
u=clone('ch1_underground','p2_underground','再出発・薄紫に光る地下回廊');u['safeSpawn']=dict(x=4,y=16,dir='up')
u['portals']=[portal('p2-under-library',4,17,'p2_library',17,5,'図書室へ戻る',kind='stairs',asset='school_stair_inset'),portal('p2-stone-town',26,4,'p2_village',3,14,'最初の町',asset='gate_door',requires={'p2StairsSeen':True})]
v=clone('ch1_village','p2_village','第9章・紫の町');v['safeSpawn']=dict(x=15,y=15,dir='up');v['entryEvents']=['p2_arrival','p2_mother']
v['npcs']=[npc('oldman','老人',16,11,'npc',['p2_oldman']),npc('child','子ども',11,16,'villager',['p2_child']),npc('mother','母親',12,16,'elderwoman'),npc('merchant','道具屋',16,9,'merchant',service='shop',serviceId='final-shop')]
v['npcs'][1]['when']={'p2MotherReturned':False}
v['npcs'].append(npc('child','子ども',12,17,'villager',when={'p2MotherReturned':True}))
v['portals']=[portal('p2-town-school',2,14,'p2_underground',26,5,'学校への石扉',kind='path',asset='stone_arch'),portal('p2-town-out',29,5,'p2_outskirts',3,14,'紫の痕跡がある町外れ',kind='path',asset='stone_arch',requires={'p2OldmanHeard':True,'p2ChildHeard':True}),portal('p2-town-inn',7,9,'p2_inn',7,11,'宿屋',asset='gate_door')]
# A readable on-map boundary; future chapter stays locked instead of sending to missing maps.
v['objects'].append(dict(id='p2-next-road',kind='sign',x=28,y=4,asset='sign',width=32,height=32,anchorX=16,anchorY=32,interactionLabel='レンの足取りが続く道',events=['p2_next']))
events['p2_next']=dict(name='',once=False,pages=['レンの足取りは、この先へ続いている。第10章は次の工程で公開します。冒険の記録を残してください。'],effects=[])
o=clone('ch1_meadow','p2_outskirts','第9章・こぼれた文字の街道');o['safeSpawn']=dict(x=4,y=14,dir='right');o['portals']=[portal('p2-road-town',3,14,'p2_village',28,5,'紫の町へ戻る',kind='path',asset='stone_arch')];o['entryEvents']=['p2_fusion_battle']
o['objects'].append(dict(id='p2-trace',kind='sign',x=22,y=13,asset='sign',width=32,height=32,anchorX=16,anchorY=32,interactionLabel='黒紫の文字塊を調べる',events=['p2_fusion_intro'],when={'p2FusionDefeated':False}))
o['triggers']=[dict(x=22,y=14,event='p2_fusion_intro',when={'p2FusionDefeated':False})]
o['enemies']=[dict(id='p2-fusion',enemy='P2_FUSION',x=22,y=14,respawn=False,when={'event:p2_fusion_intro':True,'p2FusionDefeated':False},afterEvent='p2_release')]
for n,x,y,enemy in [(1,10,12,'P2_BAT'),(2,16,14,'P2_GUARD'),(3,19,16,'P2_BAT'),(4,12,16,'P2_WORD')]:
 o['enemies'].append(dict(id='p2-roaming-'+str(n),enemy=enemy,x=x,y=y,respawn=True,behavior=dict(type='patrol_chase',stepSeconds=.55,chaseRadius=2,leash=3)))
i=clone('ch1_inn','p2_inn','第9章・町の宿屋');i['safeSpawn']=dict(x=7,y=11,dir='up');i['portals']=[portal('p2-inn-town',7,12,'p2_village',7,10,'紫の町',asset='gate_door')];i['npcs']=[npc('innkeeper','宿の主人',7,6,'merchant',service='inn',serviceId='p2-inn')];d['inns']['p2-inn']=dict(name='紫の町の宿屋',price=80)
for id,name,asset,hp,atk,de,sec,gold,role in [('P2_BAT','こぼれた飛翼','bat',360,98,40,14,150,'速攻型'),('P2_GUARD','こぼれた守り手','goblin',490,103,58,19,175,'防御型'),('P2_WORD','こぼれた文字獣','hound',410,110,44,18,210,'報酬型'),('P2_FUSION','こぼれた融合獣','goblin',1280,115,52,20,850,'中ボス')]:
 d['enemies'][id]=dict(id=id,name=name,asset=asset,hp=hp,attack=atk,defense=de,guard=de,attackSeconds=sec,exp=500 if id=='P2_FUSION' else 158,gold=gold,role=role,questionCategories=['慣用句','ことわざ','故事成語','熟語の読み方','類義語','対義語','文法'])
d['enemies']['P2_FUSION'].update(fusionAssets=['goblin','bat','hound'],enrageAt=.5,enrageAttack=1.05,enrageSpeed=.9)
d['objectives']=[q for q in d['objectives'] if not q.get('part2')]
d['objectives'][:0]=[dict(part2=True,when=w,text=t) for w,t in [({'p2NoteSeen':False,'part2Started':True},'アオイの国語ノートに浮かぶ言葉を確かめよう。'),({'p2NoteSeen':True,'p2StairsSeen':False},'教室右下の扉から廊下へ。右の図書室へ向かおう。'),({'p2StairsSeen':True,'p2TownSeen':False},'図書室右上の階段へ。地下の右上にある大きな石扉を開こう。'),({'p2TownSeen':True,'p2OldmanHeard':False},'町の中央にいる老人に、レンのことを聞こう。'),({'p2OldmanHeard':True,'p2ChildHeard':False},'広場の子どもに、レンのことを聞こう。'),({'p2ChildHeard':True,'p2FusionDefeated':False},'町の右上の石門から町外れへ。東にある黒紫の文字塊を調べよう。'),({'p2FusionDefeated':True,'p2MotherReturned':False},'西の石門から町へ戻ろう。「母」の文字が広場へ飛んでいった。'),({'chapter9Complete':True},'第9章CLEAR。冒険の記録を残そう。第10章は次の工程で公開します。')]]
for ch in d['chapters']:
 if ch['id']==9:ch.update(implemented=True,entry=dict(map='p2_class',spawn=dict(x=8,y=10,dir='up')))
c=read('continuation.json');c.update(version='0.14.0',implemented=True,entry=dict(map='p2_class',spawn=dict(x=8,y=10,dir='up')),implementedScenes=[65,66,67,68])
c['chapters'][0]['implemented']=True;c['chapters'][0]['note']='12 optional normal battles plus fusion encounter; actual entry Lv inherited. No forced grind or level correction.'
canonfile=read('part2-canonical-scenes.json');canonfile['activation']='SCENE61–68 implemented; SCENE69–92 reserved for later stages'
write('part2-canonical-scenes.json',canonfile);write('chapter9-events.json',events);write('maps.json',maps);write('game-data.json',d);write('continuation.json',c)
print('Stage 4 SCENE65–68: seven isolated maps, Aoi journey, word-return mission.')
