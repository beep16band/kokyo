/* A DOM + native canvas integration check, NOT a Chrome/Chromebook test. */
const fs=require('fs'),path=require('path');const {JSDOM}=require('jsdom');const {createCanvas}=require('@napi-rs/canvas');const {loadImage}=require('./native-image.cjs');
const dir=path.resolve(__dirname,'..');let clock=0,raf=[],viewport={w:1100,h:590};let errors=[],observers=[];
const standalone=process.env.STANDALONE==='1';const original=fs.readFileSync(dir+(standalone?'/kotoba_tower_stage6.html':'/index.html'),'utf8');const scripts=Array.from(original.matchAll(/<script>([\s\S]*?)<\/script>/g),m=>m[1]);const html=original.replace(/<script[^>]*src="[^"]+"[^>]*><\/script>/g,'').replace(/<link[^>]*>/g,'');
const dom=new JSDOM(html,{url:'https://kotoba.invalid/',runScripts:'outside-only',pretendToBeVisual:true});const w=dom.window;
w.ResizeObserver=class{constructor(cb){this.cb=cb;observers.push(cb)}observe(){this.cb()}disconnect(){}};
Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return this.id==='stage'?viewport.w:1100}});Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return this.id==='stage'?viewport.h:750}});
Object.defineProperty(w.performance,'now',{value:()=>clock});w.requestAnimationFrame=cb=>raf.push(cb);w.HTMLElement.prototype.setPointerCapture=()=>{};
w.HTMLCanvasElement.prototype.getContext=function(){if(!this._native)this._native=createCanvas(this.width,this.height);return this._native.getContext('2d');};
for(const key of ['width','height']){const d=Object.getOwnPropertyDescriptor(w.HTMLCanvasElement.prototype,key);Object.defineProperty(w.HTMLCanvasElement.prototype,key,{get:d.get,set(value){d.set.call(this,value);if(this._native)this._native[key]=value;}});}
w.Image=class {set src(v){loadImage(v.startsWith('data:')?Buffer.from(v.split(',')[1],'base64'):path.join(dir,v)).then(im=>{Object.setPrototypeOf(im,Object.getPrototypeOf(im));this.real=im;if(this.onload)this.onload();}).catch(e=>this.onerror?.(e));}};
// Renderer receives Image wrappers; unwrap for the real raster context.
const proto=Object.getPrototypeOf(createCanvas(1,1).getContext('2d'));const draw=proto.drawImage;proto.drawImage=function(im,...args){return draw.call(this,im.real||im,...args)};
w.addEventListener('error',e=>errors.push(e.message));const run=()=>{if(standalone){scripts.forEach(code=>w.eval(code.includes("KEY='kotoba-tower")?code.replace('new KotobaCore.Engine(KotobaData)','new KotobaCore.Engine(KotobaData,{enemyAI:false})'):code));}else for(const file of ['src/data.js','src/assets.js','src/core.js','src/opening.js','src/student-tools.js','tests/regression.js','src/app.js'])w.eval(fs.readFileSync(dir+'/'+file,'utf8'));};
const $=id=>w.document.getElementById(id);const frame=(n=1)=>{for(let i=0;i<n;i++){clock+=20;const q=raf;raf=[];q.forEach(f=>f(clock));}};const key=code=>{w.document.body.dispatchEvent(new w.KeyboardEvent('keydown',{code,bubbles:true}));frame();w.document.body.dispatchEvent(new w.KeyboardEvent('keyup',{code,bubbles:true}));frame(8);};const assert=(v,m)=>{if(!v)throw Error(m);};const click=id=>{if(['begin','testStart','resume'].includes(id)&&!$('opening').classList.contains('hidden'))$('openingSkip').click();$(id).click();frame();};const result=[];async function check(name,f){try{await f();result.push({name,ok:true});}catch(e){result.push({name,ok:false,error:e.message});}}
const finishDialog=()=>{let n=600;while((!$('dialog').classList.contains('hidden')||$('foot').textContent.includes('アオイが教室の出口'))&&n--)key('Space');assert(n>0,'dialog hang');};
const saved=()=>JSON.parse(w.localStorage.getItem('kotoba-tower-complete-stage6-v1'));
function go(x,y){click('save');const snapshot=saved(),engine=new w.KotobaCore.Engine(w.KotobaData);engine.restore(snapshot);const m=engine.map,q=[[snapshot.x,snapshot.y]],seen=new Set([q[0].join(',')]),prev={};let found=false;
for(let i=0;i<q.length;i++){const [a,b]=q[i];if(a===x&&b===y){found=true;break}for(const [code,dx,dy]of [['ArrowUp',0,-1],['ArrowDown',0,1],['ArrowLeft',-1,0],['ArrowRight',1,0]]){const nx=a+dx,ny=b+dy,k=nx+','+ny;if(seen.has(k)||!engine.canStand(m.id,nx,ny))continue;if(m.portals.some(p=>p.x===nx&&p.y===ny||p.rect&&engine.collides(engine.rectAt(nx,ny),p.rect))&&!(nx===x&&ny===y))continue;if(m.enemies.some(p=>engine.visible(p)&&!engine.state.defeated[p.id]&&p.x===nx&&p.y===ny)&&!(nx===x&&ny===y))continue;seen.add(k);prev[k]=[a,b,code];q.push([nx,ny]);}}
assert(found,'no path '+m.id+':'+x+','+y);const keys=[];for(let k=x+','+y;k!==q[0].join(',');){const p=prev[k];keys.push(p[2]);k=p[0]+','+p[1]}for(const code of keys.reverse()){if(!$('dialog').classList.contains('hidden'))break;key(code);}
}
const talk=(x,y,dir)=>{go(x,y);key(dir);click('action');finishDialog();};
const spaceOn=b=>{b.focus();b.dispatchEvent(new w.KeyboardEvent('keydown',{code:'Space',bubbles:true,cancelable:true}));frame();b.dispatchEvent(new w.KeyboardEvent('keyup',{code:'Space',bubbles:true}));frame(36);};
function win(){finishDialog();let n=40;while(!$('battle').classList.contains('hidden')&&n--){if(!$('result').classList.contains('hidden')){spaceOn($('next'));continue;}const q=w.KotobaData.questions.find(q=>q.prompt===$('question').textContent),button=[...$('choices').children].find(b=>b.textContent.endsWith(q.choices[q.answer]));assert(button&&!button.disabled,'battle has no choices');spaceOn(button);}assert(n>0,'battle hang');finishDialog();frame();}
async function importRecord(value){click('bag');const input=$('importSave'),payload=JSON.stringify(value);Object.defineProperty(input,'files',{configurable:true,value:[{size:payload.length,text:async()=>payload}]});input.dispatchEvent(new w.Event('change',{bubbles:true}));await new Promise(r=>setTimeout(r,0));frame();finishDialog();}
const storyAnswer=(id,wrong=false)=>{const q=w.KotobaData.interactions[id],i=wrong?(q.answer+1)%4:q.answer,b=$('menuContent').querySelector('[data-story-choice="'+i+'"]');assert(b,'choice unavailable '+id);spaceOn(b);finishDialog();};
(async()=>{run();for(let i=0;i<100&&$('begin').disabled;i++)await new Promise(r=>setTimeout(r,10));frame();
await check('ぴぽや人物の読み込み・アオイが会話後に歩いて退室',()=>{
 for(const id of ['hero_pipoya_student','aoi_pipoya_student','ren_pipoya_student','friend_pipoya_student','librarian_pipoya','teacher_pipoya'])assert(w.KotobaAssets[id].width===96&&w.KotobaAssets[id].height===128,id);
 click('begin');finishDialog();click('action');finishDialog();click('action');let n=100;while(!$('dialog').classList.contains('hidden')&&n--)key('Space');
 assert($('foot').textContent.includes('アオイが教室の出口'));assert(!saved().flags.aoiLeft);const old=JSON.stringify(saved());click('save');assert(JSON.stringify(saved())===old);
 frame(40);fs.writeFileSync(dir+'/docs/aoi-walking-out.png',$('canvas')._native.toBuffer('image/png'));assert($('foot').textContent.includes('アオイが教室の出口'));
 finishDialog();assert(saved().flags.aoiLeft);assert($('hint').textContent.includes('掲示'));assert(!$('canvas').classList.contains('hidden'));
});
await check('旧第2章CLEAR記録から、第3章ボタンで接続・元記録保持',()=>{
 const e=new w.KotobaCore.Engine(w.KotobaData);Object.assign(e.state,{chapter:2,map:'ch2_gate',x:10,y:12,dir:'up',level:6,maxHP:90,hp:90,gold:800,inventory:{I_NOTE:1,I001:8},ownedEquipment:['W003','A002'],equipment:{weapon:'W003',armor:'A002',accessory:null}});
 Object.assign(e.state.flags,{prologueComplete:true,renJoined:true,chapter1Complete:true,chapter2Complete:true,hollowBeastDefeated:true,'event:chapter2_clear':true});const old=JSON.stringify(e.snapshot());w.localStorage.setItem('kotoba-tower-complete-stage4-v1',old);
 w.localStorage.removeItem('kotoba-tower-complete-stage6-v1');click('load');assert($('endTitle').textContent.includes('第2章'),'old chapter2 CLEAR '+$('notice').textContent);assert(!$('endNext').classList.contains('hidden'));
 spaceOn($('endNext'));finishDialog();assert($('place').textContent.includes('石畳'));assert(saved()?.chapter===3,'chapter3 saved '+$('notice').textContent);assert(w.localStorage.getItem('kotoba-tower-complete-stage4-v1')===old);
 go(21,4);finishDialog();assert($('place').textContent.includes('書庫の町'));
});
await check('三人の記録・記憶を比較して書庫へ／近い出口に行き先表示',()=>{
 talk(7,16,'ArrowUp');talk(20,16,'ArrowUp');talk(27,19,'ArrowUp');assert(saved().flags.diaryCompared&&saved().flags.letterCompared&&saved().flags.blankPaperCompared);
 go(16,10);assert($('foot').textContent.includes('出口：記憶の書庫へ'));fs.writeFileSync(dir+'/docs/ch3-town-exit.png',$('canvas')._native.toBuffer('image/png'));
 go(16,9);finishDialog();assert($('place').textContent.includes('記憶の書庫'));
});
await check('レンの記録票・アオイの筆跡・ノートの会いたい・階段',()=>{
 talk(14,9,'ArrowUp');assert(saved().flags.renTicketFound);talk(24,15,'ArrowUp');assert(saved().flags.aoiHandwritingRead);
 fs.writeFileSync(dir+'/docs/ch3-archive.png',$('canvas')._native.toBuffer('image/png'));go(27,5);finishDialog();assert($('place').textContent.includes('地下保存庫'));
});
await check('保存台帳・塔犯人説の矛盾・セーブと再開',()=>{
 talk(9,15,'ArrowUp');assert(saved().flags.preservedRecordRead);talk(23,11,'ArrowUp');assert(saved().flags.storageCompared);
 click('save');click('load');finishDialog();assert(saved().flags.storageCompared&&saved().flags.renJoined);fs.writeFileSync(dir+'/docs/ch3-vault.png',$('canvas')._native.toBuffer('image/png'));
});
await check('書庫と階段の再訪・宿と道具屋を利用',()=>{
 for(let i=0;i<3;i++){go(2,16);finishDialog();go(27,5);finishDialog()}
 go(2,16);finishDialog();go(14,20);finishDialog();go(7,10);finishDialog();talk(7,8,'ArrowUp');assert(!$('menu').classList.contains('hidden'));spaceOn($('menuContent').querySelector('button'));assert(saved().gold===782);
 go(7,12);finishDialog();talk(16,19,'ArrowDown');assert($('menuTitle').textContent.includes('道具屋'));const product=$('menuContent').querySelector('[data-product="I001"]');spaceOn(product);assert(saved().inventory.I001===9);click('closeMenu');
 go(16,9);finishDialog();go(27,5);finishDialog();go(25,4);finishDialog();assert($('place').textContent.includes('守護者の記録室'));
});
await check('守護者戦・連続時間切れ・解説停止・正解後残量再開',()=>{
 go(12,9);finishDialog();assert(!$('battle').classList.contains('hidden'));assert(/故事成語|熟語の読み方/.test($('category').textContent));
 frame(1450);assert($('playerHPText').textContent==='76/90',$('playerHPText').textContent);const q=w.KotobaData.questions.find(q=>q.prompt===$('question').textContent),button=$('choices').children[q.answer];
 const gauge=$('attackBar').style.transform;spaceOn(button);assert($('resultTitle').textContent.includes('正解'));frame(700);assert($('attackBar').style.transform===gauge);
 fs.writeFileSync(dir+'/docs/ch3-guardian-explanation.png',$('canvas')._native.toBuffer('image/png'));spaceOn($('next'));assert($('attackBar').style.transform!==gauge);win();assert(saved().flags.archiveGuardianFreed);
});
await check('第3章CLEAR・保存と再開・第4章へ接続・UIエラーなし',()=>{
 go(12,3);finishDialog();assert($('endTitle').textContent.includes('第3章'));assert(!$('endNext').classList.contains('hidden'));assert(saved().flags.chapter3Complete);
 fs.writeFileSync(dir+'/docs/ch3-clear.png',$('canvas')._native.toBuffer('image/png'));click('endSave');click('resume');assert($('endTitle').textContent.includes('第3章'));click('endExplore');
 go(10,4);finishDialog();assert(w.KotobaData.chapters[4].implemented);assert($('place').textContent.includes('分岐する町への道'));assert(errors.length===0,errors.join('\n'));
});
fs.writeFileSync(dir+'/docs/chapter3-dom-test-results.json',JSON.stringify(result,null,2));for(const r of result)console.log((r.ok?'PASS ':'FAIL ')+r.name+(r.error?' '+r.error:''));w.close();process.exit(result.some(r=>!r.ok)?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
