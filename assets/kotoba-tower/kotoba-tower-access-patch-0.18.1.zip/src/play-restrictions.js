/* Classroom play restrictions v1. Same-origin only; this is not authentication. */
(function(root){'use strict';
const MINUTE=60000,JST=9*60*MINUTE;
function schedule(ms){const d=new Date(ms+JST),h=d.getUTCHours(),m=d.getUTCMinutes();return{date:d.toISOString().slice(0,10),night:h>=21||h<8,warning:h===20&&m>=55};}
function verifiedWrite(storage,key,text){const before=storage.getItem(key);storage.setItem(key,text);if(storage.getItem(key)!==text){try{if(before===null)storage.removeItem(key);else storage.setItem(key,before);}catch(_){}throw Error('保存内容を確認できませんでした。');}}
function create(o){
 const doc=o.document||root.document,storage=o.storage||root.localStorage,wall=o.wall||(()=>Date.now()),mono=o.mono||(()=>performance.now()),fetcher=o.fetch||(root.fetch?root.fetch.bind(root):async()=>{throw Error('通信機能が使えません');});
 let floor=0;try{floor=Number(storage.getItem('kotoba-play-clock-floor'))||0;}catch(_){}
 let anchor=Math.max(wall(),floor),anchorMono=mono(),server=false,allowed=!o.teacher,checked=-Infinity,polling=false,blocked=true,warning=false,saveError=false,saved=false,reason='checking',lastPersist=0,lastWarning='',disposed=false;
 const host=doc.createElement('section');host.id='playRestriction';host.setAttribute('aria-label','冒険の利用時間');host.innerHTML='<div class="play-limit-card" role="dialog" aria-modal="true" aria-labelledby="playLimitTitle"><div class="play-limit-art" aria-hidden="true"></div><h1 id="playLimitTitle"></h1><div id="playLimitWords"></div><p id="playLimitStatus" role="status" aria-live="polite"></p><div class="play-limit-actions"></div></div>';doc.body.append(host);
 const gameRoot=doc.getElementById(o.game==='tower'?'shell':'game');
 const title=host.querySelector('h1'),words=host.querySelector('#playLimitWords'),status=host.querySelector('#playLimitStatus'),actions=host.querySelector('.play-limit-actions'),art=host.querySelector('.play-limit-art');
 if(o.art)art.style.backgroundImage='url("'+o.art+'")';
 function now(){const elapsed=Math.max(0,mono()-anchorMono);return server?anchor+elapsed:Math.max(wall(),anchor+elapsed);}
 function button(label,fn){const b=doc.createElement('button');b.textContent=label;b.onclick=fn;actions.append(b);return b;}
 function render(){host.hidden=!blocked&&!warning;if(gameRoot)gameRoot.inert=!host.hidden;host.dataset.kind=warning?'warning':reason;actions.replaceChildren();host.querySelector('.play-limit-fiction')?.remove();if(host.hidden)return;
 const lines=warning?['まもなく冒険の時間が終わります。','あと5分で、今日の冒険は終了です。','21時になると、自動的に記録を保存してゲームを終了します。','今のうちに冒険を一区切りつけておこう！']:reason==='night'?['今日はここまで！','冒険の続きは、朝8時から。','しっかり休んで、また明日！']:reason==='checking'?['冒険の扉を確認しています。']:['……誰の許しで、塔に入ろうとした？','この塔が開くのは、先生が許可したときだけ。','他の授業ではやったらあかんで。','……約束を破る者を、塔は見ている。','さあ、今は目の前の授業に集中するのだ。'];
 title.textContent=warning?'冒険の時間のお知らせ':reason==='night'?'今日はここまで！':reason==='checking'?'扉を確認中':'塔の扉は封印されている';words.replaceChildren();lines.forEach((line,i)=>{const p=doc.createElement('p');p.textContent=line;p.style.animationDelay=(i*.22)+'s';words.append(p);});
 status.textContent=warning?'':saveError?'記録に失敗しました。操作は停止しています。再試行するか、記録ファイルを保存してください。':saved?(reason==='error'?'冒険の記録を保存しました。許可状態を確認できないため、通信が戻るまで停止します。':'冒険の記録を保存しました。'):reason==='error'?'許可状態を確認できません。通信が戻るまで停止します。':reason==='night'&&o.teacher?'朝8時以降も、先生の許可が必要です。':'現在の記録はそのまま残っています。';
 if(warning)button('確認',()=>{warning=false;o.clearInput();render();o.onResume?.();});
 if(saveError){button('保存を再試行',()=>{attemptSave();evaluate();});button('記録ファイルを保存',()=>o.exportSave?.());}
 if(!warning&&o.teacher){const p=doc.createElement('p');p.className='play-limit-fiction';p.textContent='塔のせりふは物語の演出です。生徒を監視・記録する機能はありません。';host.querySelector('.play-limit-card').append(p);}
 }
 function attemptSave(){try{const result=o.save();if(result!==null&&result!==undefined&&result!==true)throw Error('保存の確認に失敗しました。');saved=result===true;saveError=false;}catch(e){saveError=true;saved=false;status.textContent=e.message;}render();}
 function lock(why){warning=false;const newly=!blocked;blocked=true;reason=why;o.clearInput();if(newly){o.onPause?.();attemptSave();}else render();}
 function evaluate(){if(disposed)return;const n=now(),s=schedule(n);let why=s.night?'night':o.teacher&&(mono()-checked>45000||!allowed)?(checked===-Infinity?'checking':allowed?'error':reason==='error'?'error':'teacher'):null;
 if(why){if(!blocked||reason!==why)lock(why);}else if(saveError){blocked=true;render();}else if(blocked){blocked=false;saved=false;o.clearInput();render();o.onResume?.();}
 if(!blocked&&!warning&&s.warning&&o.playing()&&o.warningSafe()){let seen;try{seen=storage.getItem('kotoba-play-warning:'+o.game);}catch(_){}if(seen!==s.date&&lastWarning!==s.date){lastWarning=s.date;warning=true;o.clearInput();o.onPause?.();try{storage.setItem('kotoba-play-warning:'+o.game,s.date);}catch(_){}render();}}
 if(n-lastPersist>MINUTE){lastPersist=n;try{storage.setItem('kotoba-play-clock-floor',String(n));}catch(_){}}
 }
 async function poll(){if(polling||disposed)return;polling=true;const abort=new AbortController(),timer=root.setTimeout(()=>abort.abort(),5000);try{const base=o.teacher?'play-permission.json':'index.html';const url=new URL(base,o.baseURL||doc.baseURI);url.searchParams.set('_playcheck',wall()+'-'+Math.random().toString(36).slice(2));const r=await fetcher(url.href,{cache:'no-store',credentials:'same-origin',signal:abort.signal,method:o.teacher?'GET':'HEAD'});if(!r.ok)throw Error('HTTP '+r.status);let permit=true;if(o.teacher){const config=await r.json();if(typeof config.playAllowed!=='boolean')throw Error('設定の形式が不正');permit=config.playAllowed;}
 const date=Date.parse(r.headers.get('Date')),age=Number(r.headers.get('Age'))||0;if(Number.isFinite(date)){const remote=date+Math.max(0,age)*1000;anchor=server?Math.max(remote,now()):Math.max(remote,floor);anchorMono=mono();server=true;}allowed=permit;checked=mono();reason='teacher';
 }catch(e){if(o.teacher){allowed=false;checked=mono();reason='error';}}finally{root.clearTimeout(timer);polling=false;evaluate();if(blocked)render();}}
 function capture(e){evaluate();if(!blocked&&!warning)return;if(host.contains(e.target)){if(e.type==='keydown'||e.type==='keyup'){e.stopImmediatePropagation();if(e.type==='keydown'&&['Enter','Space'].includes(e.code)){e.preventDefault();if(!e.repeat)e.target.closest('button')?.click();}}return;}e.preventDefault();e.stopImmediatePropagation();}
 ['keydown','keyup','click','pointerdown','pointerup','touchstart'].forEach(type=>root.addEventListener(type,capture,true));
 function visibility(){evaluate();o.clearInput();if(!doc.hidden)poll();}
 doc.addEventListener('visibilitychange',visibility);root.addEventListener('focus',visibility);root.addEventListener('pageshow',visibility);
 render();evaluate();poll();const tick=root.setInterval(evaluate,250),net=root.setInterval(poll,30000);
 return{get paused(){evaluate();return blocked||warning;},evaluate,poll,now,get state(){return{blocked,warning,saveError,saved,reason,server};},dispose(){disposed=true;root.clearInterval(tick);root.clearInterval(net);host.remove();['keydown','keyup','click','pointerdown','pointerup','touchstart'].forEach(type=>root.removeEventListener(type,capture,true));doc.removeEventListener('visibilitychange',visibility);root.removeEventListener('focus',visibility);root.removeEventListener('pageshow',visibility);}};
}
root.KotobaPlayRestrictions={create,schedule,verifiedWrite};if(typeof module==='object')module.exports=root.KotobaPlayRestrictions;
})(typeof window==='object'?window:globalThis);
