0.18.0 source ZIPに上書きして python build.py を実行してください。
生成HTMLは公開時kotoba-tower.htmlとします。play-permission.jsonはGitHub Pagesのkokyoルートに置きます。
本パッチはマップ、戦闘、物語、アイテム、セーブの版を変更しません。
ローカルfile://での塔は許可確認不可のため停止します。HTTP公開または開発用の模擬通信で検証してください。
