"""Build offline HTML without CDN or build dependencies. Python 3 standard library."""
from pathlib import Path
import base64,json,re,struct
ROOT=Path(__file__).resolve().parent

def build():
 data=json.loads((ROOT/'data/game-data.json').read_text())
 data['maps']=json.loads((ROOT/'data/maps.json').read_text())
 data['questions']=json.loads((ROOT/'data/questions.json').read_text())
 data['examScope']=json.loads((ROOT/'data/exam-scope.json').read_text())
 data['examQuestions']=json.loads((ROOT/'data/exam-questions.json').read_text())
 data['events']={}
 for name in ['prologue-events.json','chapter1-events.json','chapter2-events.json','chapter3-events.json','chapter4-events.json','chapter5-events.json']:
  if (ROOT/'data'/name).exists():data['events'].update(json.loads((ROOT/'data'/name).read_text()))
 (ROOT/'src/data.js').write_text('globalThis.KotobaData='+json.dumps(data,ensure_ascii=False)+';',encoding='utf-8')
 (ROOT/'data/game-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 assets={}
 for p in (ROOT/'assets').glob('*.png'):
  b=p.read_bytes();w,h=struct.unpack('>II',b[16:24]);assets[p.stem]=dict(src='assets/'+p.name,width=w,height=h)
 (ROOT/'src/assets.js').write_text('globalThis.KotobaAssets='+json.dumps(assets)+';')
 embedded={k:{**a,'src':'data:image/png;base64,'+base64.b64encode((ROOT/a['src']).read_bytes()).decode()} for k,a in assets.items()}
 html=(ROOT/'index.html').read_text()
 html=html.replace('<link rel="stylesheet" href="src/style.css">','<style>'+(ROOT/'src/style.css').read_text()+'</style>')
 def inline(m):
  f=m.group(1);code='globalThis.KotobaAssets='+json.dumps(embedded)+';' if f=='src/assets.js' else (ROOT/f).read_text()
  return '<script>'+code.replace('</script','<\\/script')+'</script>'
 html=re.sub(r'<script src="([^"]+)"></script>',inline,html)
 (ROOT/'kotoba-ranking/ranking.js').write_text((ROOT/'src/ranking.js').read_text(),encoding='utf-8')
 out=ROOT/'kotoba_tower_stage6.html';out.write_text(html,encoding='utf-8');print(out,'bytes',out.stat().st_size)
if __name__=='__main__':build()
